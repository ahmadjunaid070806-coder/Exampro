import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import http from 'http';
import crypto from 'crypto';
import { GoogleGenAI, Type } from '@google/genai';
import {
  checkAndRunMonthlyResultRefresh,
  getDb,
  getPublicBootstrap,
  isAdminCredentials,
  saveDb,
  sanitizeUser,
  type UserRecord,
} from './server/store.ts';
import type {
  Coupon,
  DailyQuiz,
  ExamUpdate,
  MockTest,
  PaymentOrder,
  Question,
  ReportedQuestion,
  SupportTicket,
  SyllabusDoc,
  TestBundle,
  TestResultEntry,
} from './src/types.ts';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '25mb' }));

// Real-time SSE clients
interface SseClient {
  id: string;
  res: express.Response;
  userId?: number;
  sessionToken?: string;
}

const sseClients = new Set<SseClient>();

function broadcastEvent(event: string, payload: unknown) {
  const data = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of sseClients) {
    try {
      client.res.write(data);
    } catch {
      sseClients.delete(client);
    }
  }
}

function broadcastDataSync() {
  broadcastEvent('data_updated', { ts: Date.now() });
}

function revokePreviousStudentSessions(user: UserRecord, newToken: string) {
  broadcastEvent('session_revoked', {
    userId: user.id,
    activeToken: newToken,
  });
}

function makeToken(): string {
  return crypto.randomBytes(16).toString('hex');
}

function getAuthUser(req: express.Request): UserRecord | null {
  const db = getDb();
  const userIdRaw = req.headers['x-user-id'];
  const token = req.headers['x-session-token'] as string | undefined;
  if (!userIdRaw) return null;
  const userId = Number(userIdRaw);
  const u = db.users.find((x) => x.id === userId);
  if (!u) return null;
  if (u.role === 'student') {
    if (!token || u.sessionToken !== token) return null;
  }
  return u;
}

function requireAdmin(req: express.Request, res: express.Response): UserRecord | null {
  const u = getAuthUser(req);
  if (!u || u.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required.' });
    return null;
  }
  return u;
}

function formatNowDisplay(): string {
  return new Date().toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

// SSE Stream for real-time sync & single-device logout
app.get('/api/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const client: SseClient = {
    id: makeToken(),
    res,
    userId: req.query.userId ? Number(req.query.userId) : undefined,
    sessionToken: req.query.token ? String(req.query.token) : undefined,
  };
  sseClients.add(client);

  res.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);

  const keepAlive = setInterval(() => {
    try {
      res.write(': ping\n\n');
    } catch {
      clearInterval(keepAlive);
      sseClients.delete(client);
    }
  }, 25000);

  req.on('close', () => {
    clearInterval(keepAlive);
    sseClients.delete(client);
  });
});

// Bootstrap endpoint
app.get('/api/bootstrap', (req, res) => {
  checkAndRunMonthlyResultRefresh();
  const db = getDb();
  const visitorId = req.headers['x-visitor-id'] as string | undefined;
  if (visitorId && !db.visitorIds.includes(visitorId)) {
    db.visitorIds.push(visitorId);
    if (db.visitorIds.length > 5000) db.visitorIds.shift();
    db.totalVisitors += 1;
    saveDb();
  }

  const user = getAuthUser(req);
  const today = new Date().toISOString().slice(0, 10);
  if (user && user.lastActiveDate !== today) {
    user.lastActiveDate = today;
    saveDb();
  }

  const userIdHeader = req.headers['x-user-id'];
  const tokenHeader = req.headers['x-session-token'] as string | undefined;
  let sessionInvalid = false;
  if (userIdHeader) {
    const found = db.users.find((u) => u.id === Number(userIdHeader));
    if (found && found.role === 'student' && (!tokenHeader || found.sessionToken !== tokenHeader)) {
      sessionInvalid = true;
    }
  }

  res.json({
    data: getPublicBootstrap(user?.role === 'admin'),
    user: user ? sanitizeUser(user) : null,
    sessionInvalid,
  });
});

// 1-Tap Google Sign-In
app.post('/api/auth/google', (req, res) => {
  const db = getDb();
  const email = String(req.body.email || '').trim();
  const name = String(req.body.name || '').trim();
  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address.' });
  }

  const existing = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    const today = new Date().toISOString().slice(0, 10);
    existing.lastActiveDate = today;
    if (isAdminCredentials(existing.email, existing.phone, db.settings)) {
      existing.role = 'admin';
      existing.sessionToken = null;
    } else {
      existing.role = 'student';
      const newTok = makeToken();
      existing.sessionToken = newTok;
      revokePreviousStudentSessions(existing, newTok);
    }
    saveDb();
    broadcastDataSync();
    return res.json({ needsProfile: false, user: sanitizeUser(existing) });
  }

  return res.json({
    needsProfile: true,
    email,
    name: name || email.split('@')[0].replace(/[._]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
  });
});

// Email / Password Auth Fallback
app.post('/api/auth/email', (req, res) => {
  const db = getDb();
  const mode = req.body.mode === 'up' ? 'up' : 'in';
  const email = String(req.body.email || '').trim();
  const password = String(req.body.password || '');

  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address.' });
  }
  if (password.length < 5) {
    return res.status(400).json({ error: 'Password must be at least 5 characters.' });
  }

  const existing = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (mode === 'in') {
    if (!existing || existing.password !== password) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }
    const today = new Date().toISOString().slice(0, 10);
    existing.lastActiveDate = today;
    if (isAdminCredentials(existing.email, existing.phone, db.settings)) {
      existing.role = 'admin';
      existing.sessionToken = null;
    } else {
      existing.role = 'student';
      const newTok = makeToken();
      existing.sessionToken = newTok;
      revokePreviousStudentSessions(existing, newTok);
    }
    saveDb();
    broadcastDataSync();
    return res.json({ needsProfile: false, user: sanitizeUser(existing) });
  } else {
    if (existing) {
      return res.status(409).json({ error: '⚠️ This email is already registered. Please sign in instead.' });
    }
    return res.json({
      needsProfile: true,
      email,
      name: '',
      password,
    });
  }
});

// Admin Desktop / #admin direct login
app.post('/api/auth/admin-login', (req, res) => {
  const db = getDb();
  const identifier = String(req.body.identifier || '').trim();
  const password = String(req.body.password || '');
  const adminUser = db.users.find(
    (u) =>
      u.role === 'admin' &&
      (u.email.toLowerCase() === identifier.toLowerCase() || u.phone === identifier) &&
      (u.password || '12345') === password
  );
  if (!adminUser) {
    return res.status(401).json({ error: 'Wrong admin email/mobile or password.' });
  }
  saveDb();
  return res.json({ user: sanitizeUser(adminUser) });
});

// Complete 1-step profile for new users (Mandatory 10-digit mobile + strict unique check)
app.post('/api/auth/complete-profile', (req, res) => {
  const db = getDb();
  const email = String(req.body.email || '').trim();
  const phone = String(req.body.phone || '').replace(/\D/g, '');
  const name = String(req.body.name || '').trim();
  const district = String(req.body.district || '').trim();
  const exam = String(req.body.exam || '').trim();
  const password = String(req.body.password || '');

  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({ error: 'Invalid email address.' });
  }
  if (!/^[6-9]\d{9}$/.test(phone)) {
    return res.status(400).json({ error: '⚠️ Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.' });
  }
  if (db.users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: '⚠️ This email is already registered with another account.' });
  }
  if (db.users.some((u) => u.phone === phone)) {
    return res.status(409).json({
      error: '⚠️ This mobile number is already registered with another account. Please login with your original Google account.',
    });
  }
  if (name.length < 2) {
    return res.status(400).json({ error: 'Enter your full name.' });
  }
  if (!district) {
    return res.status(400).json({ error: 'Select your district.' });
  }
  if (!exam) {
    return res.status(400).json({ error: 'Enter your target exam.' });
  }

  const today = new Date().toISOString().slice(0, 10);
  const admin = isAdminCredentials(email, phone, db.settings);
  const newId = db.users.reduce((m, u) => Math.max(m, u.id), 0) + 1;
  const newUser: UserRecord = {
    id: newId,
    email,
    phone,
    name,
    district,
    exam,
    role: admin ? 'admin' : 'student',
    password: password || undefined,
    sessionToken: admin ? null : makeToken(),
    ownedTestIds: [],
    ownedBundleIds: [],
    mistakes: [],
    bookmarks: [],
    attempts: [],
    dailyStreak: 0,
    joinedAt: today,
    lastActiveDate: today,
  };
  db.users.push(newUser);
  saveDb();
  broadcastDataSync();
  return res.json({ user: sanitizeUser(newUser) });
});

// Update profile
app.put('/api/profile', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const db = getDb();

  const phone = String(req.body.phone || '').replace(/\D/g, '');
  const name = String(req.body.name || '').trim();
  const district = String(req.body.district || '').trim();
  const exam = String(req.body.exam || '').trim();

  if (!/^[6-9]\d{9}$/.test(phone)) {
    return res.status(400).json({ error: '⚠️ Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.' });
  }
  if (db.users.some((u) => u.id !== user.id && u.phone === phone)) {
    return res.status(409).json({
      error: '⚠️ This mobile number is already registered with another account. Please login with your original Google account.',
    });
  }
  if (name.length < 2 || !district || !exam) {
    return res.status(400).json({ error: 'All profile fields are required.' });
  }

  user.phone = phone;
  user.name = name;
  user.district = district;
  user.exam = exam;
  if (isAdminCredentials(user.email, user.phone, db.settings)) {
    user.role = 'admin';
    user.sessionToken = null;
  }
  saveDb();
  broadcastDataSync();
  return res.json({ user: sanitizeUser(user) });
});

// Submit Test
app.post('/api/tests/:id/submit', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const db = getDb();
  const testId = Number(req.params.id);
  const test = db.tests.find((t) => t.id === testId);
  if (!test) return res.status(404).json({ error: 'Test not found.' });

  const answers: Record<number, number> = req.body.answers || {};
  const timeSec = Math.max(1, Number(req.body.timeSec || 60));

  let correct = 0;
  let wrong = 0;
  let skipped = 0;
  const subjectBreakdown: Record<string, { correct: number; total: number }> = {};

  test.qs.forEach((q, idx) => {
    const subj = q.subj || 'General';
    if (!subjectBreakdown[subj]) subjectBreakdown[subj] = { correct: 0, total: 0 };
    subjectBreakdown[subj].total += 1;

    const sel = answers[idx];
    if (sel === undefined || sel === null) {
      skipped += 1;
    } else if (sel === q.c) {
      correct += 1;
      subjectBreakdown[subj].correct += 1;
    } else {
      wrong += 1;
      if (!user.mistakes.some((m) => m.t.toLowerCase() === q.t.toLowerCase())) {
        user.mistakes.unshift({
          id: `m-${Date.now()}-${idx}`,
          t: q.t,
          o: q.o,
          c: q.c,
          sel,
          e: q.e,
          subj: q.subj,
          testTitle: test.title,
          examRef: q.examRef,
          addedAt: formatNowDisplay(),
        });
      }
    }
  });

  const maxScore = test.qs.length * 4;
  const score = Math.max(0, Number((correct * 4 - wrong * test.neg).toFixed(2)));

  const entry: TestResultEntry = {
    id: `res-${Date.now()}`,
    testId: test.id,
    userId: user.id,
    name: user.name,
    district: user.district,
    targetExam: user.exam,
    score,
    maxScore,
    correct,
    wrong,
    skipped,
    timeSec,
    subjectBreakdown,
    date: formatNowDisplay(),
  };

  db.results.push(entry);
  test.attemptCount = (test.attemptCount || 0) + 1;

  // Compute Ranks & Percentile
  const testResults = db.results
    .filter((r) => r.testId === test.id)
    .sort((a, b) => b.score - a.score || a.timeSec - b.timeSec);
  const rank = testResults.findIndex((r) => r.id === entry.id) + 1;
  const totalParticipants = testResults.length;
  const percentile = totalParticipants > 1 ? Math.round(((totalParticipants - rank) / (totalParticipants - 1)) * 100) : 100;

  const distResults = testResults.filter((r) => r.district === user.district);
  const districtRank = distResults.findIndex((r) => r.id === entry.id) + 1;
  const districtTotal = distResults.length;

  const summary = {
    id: entry.id,
    testId: test.id,
    testTitle: test.title,
    score,
    maxScore,
    correct,
    wrong,
    skipped,
    rank,
    totalParticipants,
    districtRank,
    districtTotal,
    percentile,
    date: entry.date,
  };
  user.attempts.unshift(summary);
  saveDb();
  broadcastDataSync();

  return res.json({
    result: entry,
    summary,
    user: sanitizeUser(user),
  });
});

// Submit Daily Quiz
app.post('/api/daily-quiz/submit', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const db = getDb();
  const quizId = String(req.body.quizId || '');
  const answers: Record<number, number> = req.body.answers || {};
  const quiz = db.dailyQuizzes.find((q) => q.id === quizId) || db.dailyQuizzes[0];
  if (!quiz) return res.status(404).json({ error: 'Daily quiz not found.' });

  let correct = 0;
  quiz.questions.forEach((q, idx) => {
    const sel = answers[idx];
    if (sel === q.c) {
      correct += 1;
    } else if (sel !== undefined && sel !== null) {
      if (!user.mistakes.some((m) => m.t.toLowerCase() === q.t.toLowerCase())) {
        user.mistakes.unshift({
          id: `m-dq-${Date.now()}-${idx}`,
          t: q.t,
          o: q.o,
          c: q.c,
          sel,
          e: q.e,
          subj: q.subj,
          testTitle: quiz.title,
          examRef: q.examRef,
          addedAt: formatNowDisplay(),
        });
      }
    }
  });

  const today = new Date().toISOString().slice(0, 10);
  if (user.lastDailyQuizDate !== today) {
    user.dailyStreak = (user.dailyStreak || 0) + 1;
    user.lastDailyQuizDate = today;
  }
  saveDb();
  broadcastDataSync();

  return res.json({
    correct,
    total: quiz.questions.length,
    user: sanitizeUser(user),
  });
});

// Mistake Notebook Re-practice (auto-remove if solved correctly!)
app.post('/api/mistakes/practice', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const mistakeId = String(req.body.mistakeId || '');
  const selected = Number(req.body.selected);

  const idx = user.mistakes.findIndex((m) => m.id === mistakeId);
  if (idx < 0) return res.status(404).json({ error: 'Mistake not found.' });
  const item = user.mistakes[idx];
  const isCorrect = selected === item.c;
  if (isCorrect) {
    user.mistakes.splice(idx, 1);
    saveDb();
  }
  return res.json({
    isCorrect,
    removed: isCorrect,
    user: sanitizeUser(user),
  });
});

app.delete('/api/mistakes/:id', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  user.mistakes = user.mistakes.filter((m) => m.id !== req.params.id);
  saveDb();
  return res.json({ user: sanitizeUser(user) });
});

// Bookmark Toggle
app.post('/api/bookmarks/toggle', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const q: Question = req.body.question;
  const testTitle = String(req.body.testTitle || 'Mock Test');
  if (!q || !q.t) return res.status(400).json({ error: 'Invalid question.' });

  const idx = user.bookmarks.findIndex((b) => b.t.toLowerCase() === q.t.toLowerCase());
  if (idx >= 0) {
    user.bookmarks.splice(idx, 1);
  } else {
    user.bookmarks.unshift({
      id: `bm-${Date.now()}`,
      t: q.t,
      o: q.o,
      c: q.c,
      e: q.e,
      subj: q.subj,
      testTitle,
      examRef: q.examRef,
    });
  }
  saveDb();
  return res.json({ user: sanitizeUser(user) });
});

// Report Question
app.post('/api/reports', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const db = getDb();
  const report: ReportedQuestion = {
    id: `rep-${Date.now()}`,
    testId: Number(req.body.testId || 0),
    testTitle: String(req.body.testTitle || 'Mock Test'),
    questionId: String(req.body.questionId || ''),
    questionText: String(req.body.questionText || ''),
    reporterId: user.id,
    reporterName: user.name,
    reason: String(req.body.reason || '').trim() || 'Needs review',
    status: 'pending',
    createdAt: formatNowDisplay(),
  };
  db.reportedQuestions.unshift(report);
  saveDb();
  broadcastDataSync();
  return res.json({ report });
});

// Submit Support Ticket
app.post('/api/support', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const db = getDb();
  const ticket: SupportTicket = {
    id: `tic-${Date.now()}`,
    userId: user.id,
    userName: user.name,
    userPhone: user.phone,
    userEmail: user.email,
    orderId: req.body.orderId ? String(req.body.orderId).trim() : undefined,
    subject: String(req.body.subject || 'Student Support').trim(),
    message: String(req.body.message || '').trim(),
    status: 'pending',
    createdAt: formatNowDisplay(),
  };
  if (!ticket.message) return res.status(400).json({ error: 'Please write your message.' });
  db.supportTickets.unshift(ticket);
  saveDb();
  broadcastDataSync();
  return res.json({ ticket });
});

// Validate Coupon
app.post('/api/coupons/validate', (req, res) => {
  const db = getDb();
  const code = String(req.body.code || '').trim().toUpperCase();
  const amount = Number(req.body.amount || 0);
  const coupon = db.coupons.find((c) => c.code.toUpperCase() === code && c.active);
  if (!coupon) return res.status(404).json({ error: 'Invalid or inactive coupon code.' });
  if (coupon.usedCount >= coupon.maxUses) return res.status(400).json({ error: 'Coupon usage limit reached.' });
  if (coupon.expiryDate && coupon.expiryDate < new Date().toISOString().slice(0, 10)) {
    return res.status(400).json({ error: 'This coupon has expired.' });
  }
  let discount = 0;
  if (coupon.type === 'free') discount = amount;
  else if (coupon.type === 'percent') discount = Math.round((amount * coupon.value) / 100);
  else discount = Math.min(amount, coupon.value);
  const finalAmount = Math.max(0, amount - discount);
  return res.json({ coupon, discount, finalAmount });
});

// Submit Payment Order (Direct UPI UTR or ₹0 Free Coupon Instant Unlock)
app.post('/api/payments/submit', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'Session expired.' });
  const db = getDb();

  const itemType: 'test' | 'bundle' = req.body.itemType === 'bundle' ? 'bundle' : 'test';
  const itemId = Number(req.body.itemId);
  const couponCode = req.body.couponCode ? String(req.body.couponCode).trim().toUpperCase() : undefined;
  const utrNumber = req.body.utrNumber ? String(req.body.utrNumber).trim() : undefined;
  const screenshotUrl = req.body.screenshotUrl ? String(req.body.screenshotUrl) : undefined;

  let itemTitle = '';
  let originalAmount = 0;
  let bundleTests: number[] = [];

  if (itemType === 'bundle') {
    const bundle = db.bundles.find((b) => b.id === itemId);
    if (!bundle) return res.status(404).json({ error: 'Bundle not found.' });
    itemTitle = bundle.title;
    originalAmount = bundle.price;
    bundleTests = bundle.testIds;
  } else {
    const test = db.tests.find((t) => t.id === itemId);
    if (!test) return res.status(404).json({ error: 'Test not found.' });
    itemTitle = test.title;
    originalAmount = test.price;
  }

  let discountAmount = 0;
  let appliedCoupon: Coupon | undefined;
  if (couponCode) {
    appliedCoupon = db.coupons.find((c) => c.code.toUpperCase() === couponCode && c.active);
    if (appliedCoupon && appliedCoupon.usedCount < appliedCoupon.maxUses) {
      if (appliedCoupon.type === 'free') discountAmount = originalAmount;
      else if (appliedCoupon.type === 'percent') discountAmount = Math.round((originalAmount * appliedCoupon.value) / 100);
      else discountAmount = Math.min(originalAmount, appliedCoupon.value);
    }
  }

  const finalAmount = Math.max(0, originalAmount - discountAmount);

  if (finalAmount > 0 && (!utrNumber || !/^[A-Za-z0-9]{8,22}$/.test(utrNumber))) {
    return res.status(400).json({ error: 'Please enter a valid 12-digit UPI UTR / Transaction ID.' });
  }

  if (appliedCoupon) {
    appliedCoupon.usedCount += 1;
  }

  const isFreeUnlock = finalAmount === 0;
  const order: PaymentOrder = {
    id: `pay-${Date.now()}`,
    orderNumber: `EXP-${Math.floor(1000 + Math.random() * 9000)}`,
    userId: user.id,
    userName: user.name,
    userPhone: user.phone,
    itemType,
    itemId,
    itemTitle,
    originalAmount,
    discountAmount,
    finalAmount,
    couponCode: appliedCoupon?.code,
    utrNumber: isFreeUnlock ? undefined : utrNumber,
    screenshotUrl,
    paymentMethod: isFreeUnlock ? 'FREE_COUPON' : 'UPI',
    status: isFreeUnlock ? 'PAID' : 'PENDING_VERIFICATION',
    createdAt: formatNowDisplay(),
    verifiedAt: isFreeUnlock ? formatNowDisplay() : undefined,
  };

  db.payments.unshift(order);

  if (isFreeUnlock) {
    if (itemType === 'bundle') {
      if (!user.ownedBundleIds.includes(itemId)) user.ownedBundleIds.push(itemId);
      for (const tid of bundleTests) {
        if (!user.ownedTestIds.includes(tid)) user.ownedTestIds.push(tid);
      }
    } else {
      if (!user.ownedTestIds.includes(itemId)) user.ownedTestIds.push(itemId);
    }
  }

  saveDb();
  broadcastDataSync();

  return res.json({
    order,
    user: sanitizeUser(user),
  });
});

// ================= ADMIN ROUTES =================

app.post('/api/admin/tests', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const body = req.body as Partial<MockTest>;
  const newId = db.tests.reduce((m, t) => Math.max(m, t.id), 0) + 1;
  const test: MockTest = {
    id: newId,
    cat: body.cat || 'latest',
    exam: body.exam || db.exams[0],
    title: String(body.title || '').trim(),
    testType: body.testType === 'sectional' ? 'sectional' : 'full',
    subject: body.testType === 'sectional' ? body.subject : undefined,
    paid: Boolean(body.paid),
    price: body.paid ? Number(body.price || 99) : 0,
    dur: Number(body.dur || 60),
    neg: Number(body.neg ?? 0.25),
    sched: body.sched || new Date().toISOString().slice(0, 16),
    status: body.status || 'draft',
    desc: String(body.desc || ''),
    syllabusTag: String(body.syllabusTag || 'J&K Exam Pattern'),
    language: String(body.language || 'English'),
    attemptCount: Number(body.attemptCount || 0),
    bundleId: body.bundleId ? Number(body.bundleId) : null,
    qs: Array.isArray(body.qs) ? body.qs : [],
  };
  db.tests.unshift(test);
  if (test.bundleId) {
    const bundle = db.bundles.find((b) => b.id === test.bundleId);
    if (bundle && !bundle.testIds.includes(test.id)) bundle.testIds.push(test.id);
  }
  saveDb();
  broadcastDataSync();
  return res.json({ test });
});

app.put('/api/admin/tests/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const id = Number(req.params.id);
  const idx = db.tests.findIndex((t) => t.id === id);
  if (idx < 0) return res.status(404).json({ error: 'Test not found.' });
  const updated: MockTest = { ...db.tests[idx], ...req.body, id };
  db.tests[idx] = updated;

  // Sync bundle testIds
  db.bundles.forEach((b) => {
    if (updated.bundleId === b.id) {
      if (!b.testIds.includes(id)) b.testIds.push(id);
    } else {
      b.testIds = b.testIds.filter((tid) => tid !== id);
    }
  });

  saveDb();
  broadcastDataSync();
  return res.json({ test: updated });
});

app.delete('/api/admin/tests/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const id = Number(req.params.id);
  db.tests = db.tests.filter((t) => t.id !== id);
  db.bundles.forEach((b) => {
    b.testIds = b.testIds.filter((tid) => tid !== id);
  });
  saveDb();
  broadcastDataSync();
  return res.json({ ok: true });
});

// Bundles
app.post('/api/admin/bundles', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const newId = db.bundles.reduce((m, b) => Math.max(m, b.id), 0) + 1;
  const bundle: TestBundle = {
    id: newId,
    title: String(req.body.title || '').trim(),
    exam: String(req.body.exam || db.exams[0]),
    desc: String(req.body.desc || ''),
    price: Number(req.body.price || 199),
    mrp: Number(req.body.mrp || 499),
    validity: String(req.body.validity || '6 Months'),
    bundleOnly: Boolean(req.body.bundleOnly),
    testIds: Array.isArray(req.body.testIds) ? req.body.testIds.map(Number) : [],
    featured: Boolean(req.body.featured),
  };
  db.bundles.unshift(bundle);
  saveDb();
  broadcastDataSync();
  return res.json({ bundle });
});

app.put('/api/admin/bundles/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const id = Number(req.params.id);
  const idx = db.bundles.findIndex((b) => b.id === id);
  if (idx < 0) return res.status(404).json({ error: 'Bundle not found.' });
  db.bundles[idx] = { ...db.bundles[idx], ...req.body, id };
  saveDb();
  broadcastDataSync();
  return res.json({ bundle: db.bundles[idx] });
});

app.delete('/api/admin/bundles/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const id = Number(req.params.id);
  db.bundles = db.bundles.filter((b) => b.id !== id);
  saveDb();
  broadcastDataSync();
  return res.json({ ok: true });
});

// Payments Approval / Rejection / Manual Unlock
function unlockOrderForUser(order: PaymentOrder) {
  const db = getDb();
  const user = db.users.find((u) => u.id === order.userId);
  if (!user) return;
  if (order.itemType === 'bundle') {
    if (!user.ownedBundleIds.includes(order.itemId)) user.ownedBundleIds.push(order.itemId);
    const bundle = db.bundles.find((b) => b.id === order.itemId);
    if (bundle) {
      for (const tid of bundle.testIds) {
        if (!user.ownedTestIds.includes(tid)) user.ownedTestIds.push(tid);
      }
    }
  } else {
    if (!user.ownedTestIds.includes(order.itemId)) user.ownedTestIds.push(order.itemId);
  }
}

app.post('/api/admin/payments/:id/approve', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const order = db.payments.find((p) => p.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  order.status = 'PAID';
  order.verifiedAt = formatNowDisplay();
  unlockOrderForUser(order);
  saveDb();
  broadcastDataSync();
  return res.json({ order });
});

app.post('/api/admin/payments/:id/reject', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const order = db.payments.find((p) => p.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });
  order.status = 'REJECTED';
  order.verifiedAt = formatNowDisplay();
  saveDb();
  broadcastDataSync();
  return res.json({ order });
});

app.post('/api/admin/payments/manual-unlock', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const userId = Number(req.body.userId);
  const itemType = req.body.itemType === 'bundle' ? 'bundle' : 'test';
  const itemId = Number(req.body.itemId);
  const user = db.users.find((u) => u.id === userId);
  if (!user) return res.status(404).json({ error: 'Student not found.' });

  if (itemType === 'bundle') {
    if (!user.ownedBundleIds.includes(itemId)) user.ownedBundleIds.push(itemId);
    const b = db.bundles.find((x) => x.id === itemId);
    if (b) {
      b.testIds.forEach((tid) => {
        if (!user.ownedTestIds.includes(tid)) user.ownedTestIds.push(tid);
      });
    }
  } else {
    if (!user.ownedTestIds.includes(itemId)) user.ownedTestIds.push(itemId);
  }
  saveDb();
  broadcastDataSync();
  return res.json({ ok: true });
});

// Coupons
app.post('/api/admin/coupons', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const code = String(req.body.code || '').trim().toUpperCase();
  if (!code) return res.status(400).json({ error: 'Coupon code is required.' });
  if (db.coupons.some((c) => c.code.toUpperCase() === code)) {
    return res.status(409).json({ error: 'Coupon code already exists.' });
  }
  const coupon: Coupon = {
    id: `cp-${Date.now()}`,
    code,
    type: req.body.type || 'percent',
    value: Number(req.body.value || 0),
    maxUses: Number(req.body.maxUses || 100),
    usedCount: 0,
    expiryDate: String(req.body.expiryDate || '2026-12-31'),
    active: true,
  };
  db.coupons.unshift(coupon);
  saveDb();
  broadcastDataSync();
  return res.json({ coupon });
});

app.put('/api/admin/coupons/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const c = db.coupons.find((x) => x.id === req.params.id);
  if (!c) return res.status(404).json({ error: 'Coupon not found.' });
  Object.assign(c, req.body);
  saveDb();
  broadcastDataSync();
  return res.json({ coupon: c });
});

app.delete('/api/admin/coupons/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  db.coupons = db.coupons.filter((c) => c.id !== req.params.id);
  saveDb();
  broadcastDataSync();
  return res.json({ ok: true });
});

// Daily Quiz & Updates
app.post('/api/admin/daily-quiz', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const date = String(req.body.date || new Date().toISOString().slice(0, 10));
  const title = String(req.body.title || 'Daily 10-Question J&K Current Affairs');
  const questions: Question[] = Array.isArray(req.body.questions) ? req.body.questions : [];
  if (!questions.length) return res.status(400).json({ error: 'Add at least one question.' });

  const existing = db.dailyQuizzes.find((d) => d.date === date);
  if (existing) {
    existing.title = title;
    existing.questions = questions;
  } else {
    db.dailyQuizzes.unshift({
      id: `dq-${Date.now()}`,
      date,
      title,
      questions,
    });
  }
  saveDb();
  broadcastDataSync();
  return res.json({ ok: true });
});

app.post('/api/admin/updates', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const update: ExamUpdate = {
    id: `upd-${Date.now()}`,
    type: req.body.type || 'alert',
    title: String(req.body.title || '').trim(),
    exam: String(req.body.exam || 'All J&K Exams'),
    message: String(req.body.message || '').trim(),
    examDate: req.body.examDate || undefined,
    link: req.body.link || undefined,
    createdAt: formatNowDisplay(),
  };
  db.updates.unshift(update);
  saveDb();
  broadcastDataSync();
  return res.json({ update });
});

app.delete('/api/admin/updates/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  db.updates = db.updates.filter((u) => u.id !== req.params.id);
  saveDb();
  broadcastDataSync();
  return res.json({ ok: true });
});

// Syllabus Manager
app.post('/api/admin/syllabus', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const doc: SyllabusDoc = {
    id: `syl-${Date.now()}`,
    exam: String(req.body.exam || db.exams[0]),
    title: String(req.body.title || '').trim(),
    summary: String(req.body.summary || '').trim(),
    pdfUrl: String(req.body.pdfUrl || ''),
    fileName: String(req.body.fileName || 'Syllabus.pdf'),
    uploadedAt: formatNowDisplay(),
  };
  db.syllabi.unshift(doc);
  saveDb();
  broadcastDataSync();
  return res.json({ doc });
});

app.delete('/api/admin/syllabus/:id', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  db.syllabi = db.syllabi.filter((s) => s.id !== req.params.id);
  saveDb();
  broadcastDataSync();
  return res.json({ ok: true });
});

// Support & Reports Resolution
app.post('/api/admin/support/:id/resolve', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const t = db.supportTickets.find((x) => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Ticket not found.' });
  t.status = 'resolved';
  saveDb();
  broadcastDataSync();
  return res.json({ ticket: t });
});

app.post('/api/admin/reports/:id/resolve', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const r = db.reportedQuestions.find((x) => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: 'Report not found.' });
  r.status = 'resolved';
  saveDb();
  broadcastDataSync();
  return res.json({ report: r });
});

app.post('/api/admin/results/refresh', (req, res) => {
  if (!requireAdmin(req, res)) return;
  checkAndRunMonthlyResultRefresh(new Date(), true);
  broadcastDataSync();
  return res.json({ ok: true });
});

// Exams & Subjects
app.post('/api/admin/exams', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const name = String(req.body.name || '').trim();
  if (name && !db.exams.includes(name)) {
    const idx = db.exams.indexOf('Other');
    if (idx >= 0) db.exams.splice(idx, 0, name);
    else db.exams.push(name);
    saveDb();
    broadcastDataSync();
  }
  return res.json({ exams: db.exams });
});

app.delete('/api/admin/exams/:name', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  db.exams = db.exams.filter((e) => e !== req.params.name || e === 'Other');
  saveDb();
  broadcastDataSync();
  return res.json({ exams: db.exams });
});

app.post('/api/admin/subjects', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const name = String(req.body.name || '').trim();
  if (name && !db.subjects.includes(name)) {
    db.subjects.push(name);
    saveDb();
    broadcastDataSync();
  }
  return res.json({ subjects: db.subjects });
});

// Settings (UPI, Social, WhatsApp Support, Admin Phone/Email Credentials)
app.put('/api/admin/settings', (req, res) => {
  if (!requireAdmin(req, res)) return;
  const db = getDb();
  const next = req.body;
  db.settings = {
    ...db.settings,
    ...next,
    social: { ...db.settings.social, ...(next.social || {}) },
    upi: { ...db.settings.upi, ...(next.upi || {}) },
  };
  // Update admin user record if admin email/phone changed
  const adminUser = db.users.find((u) => u.role === 'admin');
  if (adminUser) {
    adminUser.email = db.settings.adminEmail;
    adminUser.phone = db.settings.adminPhone;
  }
  saveDb();
  broadcastDataSync();
  return res.json({ settings: db.settings });
});

// Server-side Gemini PDF Question Extractor (up to 120 questions + ExamRef detection)
app.post('/api/admin/ai-extract-pdf', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const count = Math.max(1, Math.min(120, Number(req.body.count || 10)));
  const pdfBase64 = req.body.pdfBase64 ? String(req.body.pdfBase64) : '';
  const useSample = Boolean(req.body.useSample);

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error: 'GEMINI_API_KEY is not configured in Secrets. Please configure GEMINI_API_KEY to run AI PDF extraction.',
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const prompt = `You are an expert Jammu & Kashmir competitive exam paper setter (JKSSB, JKPSC KAS, JKP SI/Constable).
Extract or generate EXACTLY ${count} unique, non-duplicate multiple-choice questions based on the provided PDF document${useSample ? ' (focusing on Jammu & Kashmir General Knowledge, History, Geography, Polity, Economy, and Reasoning)' : ''}.
Rules:
1. Each question must have:
   - t: concise, clear question text (do NOT duplicate any question)
   - o: array of exactly 4 distinct options
   - c: 0-based index (0, 1, 2, or 3) of the correct option
   - e: short, accurate 1-2 sentence explanation
   - subj: subject name (e.g., J&K General Knowledge, History, Geography, Indian Polity, English, Math, Reasoning, Computer, Current Affairs)
   - examRef: array of up to 3 previous exam reference tags ONLY if the question text in the PDF explicitly mentions past exam names/years (like "[JKSSB 2024]", "JKPSC 2023", "JKP SI 2022"). Leave examRef as an empty array [] if none are mentioned.
Return valid JSON matching the schema.`;

    const contents =
      pdfBase64 && !useSample
        ? {
            parts: [
              {
                inlineData: {
                  mimeType: 'application/pdf',
                  data: pdfBase64.replace(/^data:application\/pdf;base64,/, ''),
                },
              },
              { text: prompt },
            ],
          }
        : `${prompt}\n\nSample Document Topics: Jammu & Kashmir Geography (Jhelum, Chenab, Wular Lake, Dal Lake, Zoji La, Banihal), History (Kalhana's Rajatarangini, Karkota & Dogra dynasties, Martand Sun Temple), J&K Reorganisation Act 2019, Pampore Saffron, Dachigam Hangul, Computer MS Office shortcuts, JKSSB English & Reasoning.`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              t: { type: Type.STRING },
              o: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              c: { type: Type.INTEGER },
              e: { type: Type.STRING },
              subj: { type: Type.STRING },
              examRef: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ['t', 'o', 'c', 'e', 'subj'],
          },
        },
      },
    });

    const rawText = (response.text ?? '[]').trim();
    const parsed = JSON.parse(rawText) as Array<{
      t: string;
      o: string[];
      c: number;
      e: string;
      subj: string;
      examRef?: string[];
    }>;

    // Normalize & deduplicate
    const seen = new Set<string>();
    const questions: Question[] = [];
    for (let i = 0; i < parsed.length && questions.length < count; i++) {
      const item = parsed[i];
      const norm = String(item.t || '').trim().toLowerCase().replace(/\s+/g, ' ');
      if (!norm || seen.has(norm)) continue;
      seen.add(norm);
      const opts = Array.isArray(item.o) ? item.o.slice(0, 4).map(String) : [];
      while (opts.length < 4) opts.push(`Option ${opts.length + 1}`);
      questions.push({
        id: `ai-${Date.now()}-${i}`,
        t: String(item.t).trim(),
        o: [opts[0], opts[1], opts[2], opts[3]],
        c: Math.max(0, Math.min(3, Number(item.c || 0))),
        e: String(item.e || 'Correct option verified.'),
        subj: String(item.subj || 'J&K General Knowledge'),
        src: 'ai',
        examRef: Array.isArray(item.examRef)
          ? item.examRef.map((x) => String(x).trim()).filter(Boolean).slice(0, 3)
          : [],
      });
    }

    return res.json({ questions });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Failed to extract questions from PDF.';
    console.error('Gemini PDF extraction error:', err);
    return res.status(500).json({ error: message });
  }
});

// Vite dev middleware or production static build
async function startServer() {
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server: httpServer },
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build not found');
      }
    });
  }

  // Run month-end 11:55 PM automatic Result Menu refresh check at boot and every 30 seconds
  checkAndRunMonthlyResultRefresh();
  setInterval(() => {
    if (checkAndRunMonthlyResultRefresh()) {
      broadcastDataSync();
    }
  }, 30_000);

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`ExamPro server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
