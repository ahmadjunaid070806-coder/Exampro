import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface Props {
  compact?: boolean;
  onToast?: (msg: string) => void;
}

export const PWAInstallButton: React.FC<Props> = ({ compact = false, onToast }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) return null;

  const handleClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok && onToast) onToast('ExamPro App installed!');
    } else {
      setShowGuide(true);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className={`btn-press inline-flex items-center gap-1.5 rounded-lg font-medium whitespace-nowrap shrink-0 cursor-pointer ${
          compact
            ? 'border border-indigo-200 dark:border-indigo-700/60 bg-indigo-50 dark:bg-indigo-950/60 px-3 py-2 text-xs text-indigo-700 dark:text-indigo-200 hover:bg-indigo-100 dark:hover:bg-indigo-900/60'
            : 'bg-indigo-600 px-4 py-2.5 text-sm text-white hover:bg-indigo-700 shadow-sm'
        }`}
      >
        <Download className="w-3.5 h-3.5" />
        <span>{compact ? 'Install App' : '📲 Install ExamPro App'}</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-xl border border-slate-200 dark:border-slate-800"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 font-display font-bold text-slate-900 dark:text-white">
                <Smartphone className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>Install ExamPro App</span>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {isIOS ? (
              <div className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <p>Install ExamPro directly to your iPhone or iPad Home Screen:</p>
                <ol className="list-decimal pl-5 space-y-1">
                  <li>Tap the <strong>Share</strong> icon in the Safari toolbar.</li>
                  <li>Scroll down and tap <strong>Add to Home Screen</strong>.</li>
                  <li>Tap <strong>Add</strong> to launch ExamPro like a native app.</li>
                </ol>
              </div>
            ) : (
              <div className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <p>Install ExamPro on Android or Desktop for offline access and faster mock tests:</p>
                <ol className="list-decimal pl-5 space-y-1">
                  <li>Open browser menu (<strong>⋮</strong> in Chrome or Edge).</li>
                  <li>Tap <strong>Install App</strong> or <strong>Add to Home screen</strong>.</li>
                  <li>Confirm to install ExamPro on your device.</li>
                </ol>
              </div>
            )}
            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="btn-press mt-5 w-full rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const PWAInstallBanner: React.FC<{ onToast?: (msg: string) => void }> = ({ onToast }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);
  const [showModal, setShowModal] = useState(false);

  if (isInstalled || dismissed) return null;

  const handleAction = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok && onToast) onToast('ExamPro App installed!');
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-indigo-200 dark:border-indigo-800/70 bg-indigo-50/80 dark:bg-indigo-950/40 px-4 py-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white font-bold text-lg">
            📲
          </div>
          <div className="min-w-0">
            <p className="font-display text-sm font-bold text-slate-900 dark:text-white truncate">
              Install ExamPro App on Your Phone
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-300 truncate">
              Fast CBT test engine, offline revision &amp; instant J&amp;K exam alerts
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleAction}
            className="btn-press rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-700 whitespace-nowrap"
          >
            📲 Install ExamPro App
          </button>
          <button
            type="button"
            onClick={() => setDismissed(true)}
            aria-label="Dismiss install banner"
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-200/70 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          onClick={() => setShowModal(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-xl border border-slate-200 dark:border-slate-800"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">
              Install ExamPro App
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              {isIOS
                ? 'Tap the Share icon in Safari and choose "Add to Home Screen" to install ExamPro.'
                : 'Open your browser menu (⋮) and choose "Install App" or "Add to Home screen".'}
            </p>
            <button
              type="button"
              onClick={() => setShowModal(false)}
              className="btn-press mt-4 w-full rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
