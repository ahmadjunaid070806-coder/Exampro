import React, { useState } from 'react';
import { CheckCircle2, Copy, ExternalLink, ImagePlus, ShieldCheck, Tag, X } from 'lucide-react';
import type { AppSettings, PaymentOrder } from '../types';
import { apiFetch } from '../lib/api';

interface Props {
  itemType: 'test' | 'bundle';
  itemId: number;
  itemTitle: string;
  price: number;
  settings: AppSettings;
  onClose: () => void;
  onSuccess: (order: PaymentOrder, updatedUser: unknown) => void;
  onToast: (msg: string) => void;
}

export const CheckoutModal: React.FC<Props> = ({
  itemType,
  itemId,
  itemTitle,
  price,
  settings,
  onClose,
  onSuccess,
  onToast,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [discount, setDiscount] = useState(0);
  const [couponMsg, setCouponMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [utr, setUtr] = useState('');
  const [screenshot, setScreenshot] = useState<string | undefined>(undefined);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const finalAmount = Math.max(0, price - discount);
  const upiLink = `upi://pay?pa=${encodeURIComponent(settings.upi.upiId)}&pn=${encodeURIComponent(
    settings.upi.payeeName
  )}&am=${finalAmount}&cu=INR&tn=${encodeURIComponent(`ExamPro ${itemTitle}`)}`;

  const handleApplyCoupon = async () => {
    setCouponMsg(null);
    const code = couponCode.trim().toUpperCase();
    if (!code) return;
    try {
      const res = await apiFetch<{ discount: number; finalAmount: number; coupon: { code: string } }>(
        '/api/coupons/validate',
        {
          method: 'POST',
          body: JSON.stringify({ code, amount: price }),
        }
      );
      setDiscount(res.discount);
      setAppliedCoupon(res.coupon.code);
      setCouponMsg({
        ok: true,
        text:
          res.finalAmount === 0
            ? `Coupon ${res.coupon.code} applied! 100% Free unlock ready.`
            : `Coupon ${res.coupon.code} applied! You saved ₹${res.discount}.`,
      });
    } catch (err: unknown) {
      setDiscount(0);
      setAppliedCoupon(null);
      setCouponMsg({ ok: false, text: err instanceof Error ? err.message : 'Invalid coupon.' });
    }
  };

  const handleScreenshot = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setScreenshot(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleCopyUpi = () => {
    try {
      navigator.clipboard.writeText(settings.upi.upiId);
    } catch {
      // ignore
    }
    onToast('UPI ID copied!');
  };

  const handleSubmit = async () => {
    setError('');
    if (finalAmount > 0 && !/^[A-Za-z0-9]{8,22}$/.test(utr.trim())) {
      setError('Please enter a valid 12-digit UPI UTR / Transaction ID.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiFetch<{ order: PaymentOrder; user: unknown }>('/api/payments/submit', {
        method: 'POST',
        body: JSON.stringify({
          itemType,
          itemId,
          couponCode: appliedCoupon || undefined,
          utrNumber: finalAmount > 0 ? utr.trim() : undefined,
          screenshotUrl: screenshot,
        }),
      });
      onSuccess(res.order, res.user);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to submit order.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-2xl max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
          <div>
            <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
              Direct UPI Checkout
            </p>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mt-0.5">
              {itemTitle}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Price Breakdown */}
        <div className="mt-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3.5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Payable Amount</div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="font-display text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                ₹{finalAmount}
              </span>
              {discount > 0 && (
                <span className="text-xs text-slate-400 line-through tabular-nums">₹{price}</span>
              )}
            </div>
          </div>
          <div className="text-right text-xs text-slate-600 dark:text-slate-300">
            <div className="font-semibold">{settings.upi.payeeName}</div>
            <div>{itemType === 'bundle' ? 'Bundle Pack' : 'Single Test'}</div>
          </div>
        </div>

        {/* Coupon Input */}
        <div className="mt-4">
          <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5 mb-1.5">
            <Tag className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            Have a Coupon Code?
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
              placeholder="e.g. JKFREE100, KAS50"
              className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3 py-2 text-sm text-slate-900 dark:text-white uppercase focus:outline-none focus:border-indigo-500"
            />
            <button
              type="button"
              onClick={handleApplyCoupon}
              className="btn-press rounded-xl bg-slate-900 dark:bg-indigo-600 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              Apply Coupon
            </button>
          </div>
          {couponMsg && (
            <p className={`mt-1.5 text-xs font-medium ${couponMsg.ok ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
              {couponMsg.text}
            </p>
          )}
        </div>

        {finalAmount === 0 ? (
          <div className="mt-5 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 p-4 text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 dark:text-emerald-400 mx-auto mb-1.5" />
            <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
              100% Discount Applied — ₹0 Payable
            </p>
            <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-1">
              No UPI payment needed. Click below to unlock immediately!
            </p>
            <button
              type="button"
              disabled={submitting}
              onClick={handleSubmit}
              className="btn-press mt-4 w-full rounded-xl bg-emerald-600 py-3 text-sm font-bold text-white hover:bg-emerald-700 cursor-pointer disabled:opacity-50"
            >
              {submitting ? 'Unlocking...' : 'Unlock Now for ₹0'}
            </button>
          </div>
        ) : (
          <div className="mt-5 space-y-4">
            {/* QR + UPI Copy + Deep Link */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-700/80 bg-slate-50/60 dark:bg-slate-800/40 p-4 flex flex-col items-center text-center">
              <div className="rounded-xl bg-white p-2.5 shadow-sm border border-slate-200">
                <img
                  src={settings.upi.qrImageUrl}
                  alt="UPI QR Code"
                  referrerPolicy="no-referrer"
                  className="h-44 w-44 object-contain"
                />
              </div>
              <div className="mt-3 flex items-center gap-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 px-3 py-1.5">
                <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                  {settings.upi.upiId}
                </span>
                <button
                  type="button"
                  onClick={handleCopyUpi}
                  className="btn-press inline-flex items-center gap-1 rounded-md bg-indigo-50 dark:bg-indigo-950 px-2 py-1 text-[11px] font-semibold text-indigo-700 dark:text-indigo-300 cursor-pointer"
                >
                  <Copy className="w-3 h-3" />
                  Copy UPI
                </button>
              </div>
              <a
                href={upiLink}
                className="btn-press mt-3 inline-flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-indigo-700 w-full"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Pay ₹{finalAmount} via UPI App (GPay / PhonePe / Paytm)</span>
              </a>
            </div>

            {/* UTR Input */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                12-Digit UPI UTR / Transaction ID *
              </label>
              <input
                type="text"
                value={utr}
                onChange={(e) => setUtr(e.target.value)}
                placeholder="Enter 12-digit UTR e.g. 431955018274"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Optional Screenshot Upload */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1.5">
                Payment Screenshot (Optional)
              </label>
              <label className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 px-3 py-2.5 text-xs text-slate-600 dark:text-slate-300 hover:border-indigo-500 cursor-pointer">
                <ImagePlus className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>{screenshot ? 'Screenshot attached ✔ (click to change)' : 'Upload payment screenshot'}</span>
                <input type="file" accept="image/*" onChange={handleScreenshot} className="hidden" />
              </label>
            </div>

            {error && <p className="text-xs font-semibold text-rose-600 dark:text-rose-400">{error}</p>}

            <button
              type="button"
              disabled={submitting}
              onClick={handleSubmit}
              className="btn-press w-full rounded-xl bg-emerald-600 py-3 text-sm font-bold text-white hover:bg-emerald-700 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{submitting ? 'Submitting...' : 'Submit UTR for Instant Verification'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
