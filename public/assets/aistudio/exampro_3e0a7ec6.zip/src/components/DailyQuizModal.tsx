import React, { useState } from 'react';
import { CheckCircle2, Flame, X, XCircle } from 'lucide-react';
import type { DailyQuiz, UserProfile } from '../types';
import { apiFetch } from '../lib/api';

interface Props {
  quiz: DailyQuiz;
  streak: number;
  onClose: () => void;
  onCompleted: (updatedUser: UserProfile) => void;
}

const LABELS = ['A', 'B', 'C', 'D'];

export const DailyQuizModal: React.FC<Props> = ({ quiz, streak, onClose, onCompleted }) => {
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [finished, setFinished] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [scoreInfo, setScoreInfo] = useState<{ correct: number; total: number } | null>(null);

  const q = quiz.questions[idx];
  const selected = answers[idx];
  const hasAnswered = selected !== undefined;

  const handleSelect = (optIdx: number) => {
    if (hasAnswered) return;
    setAnswers((prev) => ({ ...prev, [idx]: optIdx }));
  };

  const handleFinish = async () => {
    setSubmitting(true);
    try {
      const res = await apiFetch<{ correct: number; total: number; user: UserProfile }>(
        '/api/daily-quiz/submit',
        {
          method: 'POST',
          body: JSON.stringify({ quizId: quiz.id, answers }),
        }
      );
      setScoreInfo({ correct: res.correct, total: res.total });
      setFinished(true);
      onCompleted(res.user);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4 backdrop-blur-xs">
      <div className="w-full max-w-2xl rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 px-5 py-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400">
              <Flame className="w-4 h-4" />
              <span>Daily Streak: {streak} days</span>
            </div>
            <h3 className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-white mt-0.5">
              {quiz.title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto flex-1">
          {finished && scoreInfo ? (
            <div className="text-center py-6 space-y-4">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-3xl">
                🎯
              </div>
              <h4 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                {scoreInfo.correct} / {scoreInfo.total} Correct
              </h4>
              <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto">
                Your Daily Streak has been updated! Any wrong answers have been automatically saved to your Mistake Notebook for revision.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="btn-press rounded-xl bg-indigo-600 px-6 py-3 text-sm font-semibold text-white hover:bg-indigo-700 cursor-pointer"
              >
                Back to Home
              </button>
            </div>
          ) : q ? (
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-3">
                <span>
                  Question <strong className="text-slate-900 dark:text-white">{idx + 1}</strong> of{' '}
                  {quiz.questions.length}
                </span>
                <span>{q.subj}</span>
              </div>

              {/* Progress Bar */}
              <div className="h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 mb-5 overflow-hidden">
                <div
                  className="h-full bg-indigo-600 transition-all duration-200"
                  style={{ width: `${((idx + 1) / quiz.questions.length) * 100}%` }}
                />
              </div>

              {q.examRef && q.examRef.length > 0 && (
                <div className="mb-2.5 flex flex-wrap items-center gap-1.5">
                  <span className="inline-flex items-center rounded-md bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 px-2 py-0.5 text-[11px] font-semibold text-amber-800 dark:text-amber-300">
                    📌 Asked in: {q.examRef.slice(0, 3).join(' • ')}
                  </span>
                </div>
              )}

              <h4 className="text-base font-semibold text-slate-900 dark:text-white leading-relaxed mb-4">
                {q.t}
              </h4>

              <div className="space-y-2.5">
                {q.o.map((opt, optIdx) => {
                  const isCorrect = optIdx === q.c;
                  const isPicked = selected === optIdx;
                  let cls =
                    'border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/60 hover:border-indigo-400';
                  if (hasAnswered) {
                    if (isCorrect) {
                      cls = 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-200';
                    } else if (isPicked) {
                      cls = 'border-rose-500 bg-rose-50 dark:bg-rose-950/50 text-rose-900 dark:text-rose-200';
                    }
                  }

                  return (
                    <button
                      key={optIdx}
                      type="button"
                      disabled={hasAnswered}
                      onClick={() => handleSelect(optIdx)}
                      className={`w-full flex items-center gap-3 rounded-xl border p-3.5 text-left text-sm transition-all duration-150 cursor-pointer ${cls}`}
                    >
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-bold">
                        {LABELS[optIdx]}
                      </span>
                      <span className="flex-1 font-medium">{opt}</span>
                      {hasAnswered && isCorrect && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                      {hasAnswered && isPicked && !isCorrect && (
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {hasAnswered && (
                <div className="mt-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 p-3.5 text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                  <strong>Explanation:</strong> {q.e}
                </div>
              )}
            </div>
          ) : null}
        </div>

        {/* Footer Actions */}
        {!finished && (
          <div className="flex items-center justify-between border-t border-slate-200 dark:border-slate-800 px-5 py-3.5 bg-slate-50/70 dark:bg-slate-900">
            <button
              type="button"
              disabled={idx === 0}
              onClick={() => setIdx((i) => Math.max(0, i - 1))}
              className="btn-press rounded-xl border border-slate-300 dark:border-slate-700 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 disabled:opacity-40 cursor-pointer"
            >
              Previous
            </button>

            {idx < quiz.questions.length - 1 ? (
              <button
                type="button"
                onClick={() => setIdx((i) => i + 1)}
                className="btn-press rounded-xl bg-indigo-600 px-5 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
              >
                {hasAnswered ? 'Next Question →' : 'Skip →'}
              </button>
            ) : (
              <button
                type="button"
                disabled={submitting}
                onClick={handleFinish}
                className="btn-press rounded-xl bg-emerald-600 px-5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer disabled:opacity-50"
              >
                {submitting ? 'Saving...' : 'Finish Daily Quiz'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
