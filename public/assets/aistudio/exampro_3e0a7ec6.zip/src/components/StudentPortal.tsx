import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Award,
  BarChart3,
  Bell,
  Bookmark,
  BookOpen,
  Calendar,
  CalendarCheck,
  Check,
  CheckCircle2,
  ClipboardList,
  Clock,
  Edit3,
  FileText,
  Flame,
  HelpCircle,
  LayoutDashboard,
  Lock,
  LogOut,
  Menu,
  MessageCircle,
  Moon,
  Package,
  Play,
  Plus,
  Search,
  Settings,
  Shield,
  Sun,
  Trash2,
  Trophy,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import type {
  AppBootstrapData,
  AttemptSummary,
  MockTest,
  PaymentOrder,
  TestBundle,
  TestResultEntry,
  UserProfile,
} from '../types';
import { DEFAULT_CATEGORIES, JK_DISTRICTS, getNextMonthEndRefreshDate } from '../types';
import { apiFetch } from '../lib/api';
import { PWAInstallBanner, PWAInstallButton } from './PWAInstallBanner';
import { Footer } from './Footer';
import { InfoPagesModal, type InfoPageKey } from './InfoPagesModal';
import { SocialShareBar } from './SocialShareBar';
import { CheckoutModal } from './CheckoutModal';
import { DailyQuizModal } from './DailyQuizModal';
import { BundleDetailView } from './BundleDetailView';
import { MockTestEngine } from './MockTestEngine';
import { ResultView } from './ResultView';
import { TopperPosterModal } from './TopperPosterModal';

interface Props {
  data: AppBootstrapData;
  user: UserProfile | null;
  dark: boolean;
  kickedAlert: boolean;
  onToggleTheme: () => void;
  onDismissKicked: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  onUserUpdate: (user: UserProfile) => void;
  onLogout: () => void;
  onOpenAdmin: () => void;
  onToast: (msg: string) => void;
  onRefreshData: () => void;
}

type StudentSubView =
  | 'home'
  | 'courses'
  | 'bundles'
  | 'assignments'
  | 'attendance'
  | 'timetable'
  | 'results'
  | 'settings'
  | 'updates'
  | 'profile'
  | 'payments'
  | 'mistakes'
  | 'districtRank'
  | 'attempts'
  | 'bookmarks'
  | 'syllabus'
  | 'support';

interface ChecklistItem {
  id: string;
  title: string;
  course: string;
  due: string;
  done: boolean;
}

const LABELS = ['A', 'B', 'C', 'D'];

export const StudentPortal: React.FC<Props> = ({
  data,
  user,
  dark,
  kickedAlert,
  onToggleTheme,
  onDismissKicked,
  onLoginSuccess,
  onUserUpdate,
  onLogout,
  onOpenAdmin,
  onToast,
  onRefreshData,
}) => {
  // Auth & Profile Completion state
  const [authMode, setAuthMode] = useState<'in' | 'up'>('in');
  const [authEmail, setAuthEmail] = useState('');
  const [authPw, setAuthPw] = useState('');
  const [authErr, setAuthErr] = useState('');
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [customGoogleEmail, setCustomGoogleEmail] = useState('');

  const [pendingProfile, setPendingProfile] = useState<{
    email: string;
    name: string;
    phone: string;
    district: string;
    exam: string;
    password?: string;
    isEdit?: boolean;
  } | null>(null);
  const [profileErr, setProfileErr] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  // Navigation, Search & Modals
  const [subView, setSubView] = useState<StudentSubView>('home');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  const [examFilter, setExamFilter] = useState<string>('');
  const [selectedTopperDistrict, setSelectedTopperDistrict] = useState<string>('All Districts');
  const [infoPage, setInfoPage] = useState<InfoPageKey | null>(null);
  const [activeBundle, setActiveBundle] = useState<TestBundle | null>(null);
  const [checkoutItem, setCheckoutItem] = useState<{
    type: 'test' | 'bundle';
    id: number;
    title: string;
    price: number;
  } | null>(null);
  const [showDailyQuiz, setShowDailyQuiz] = useState(false);
  const [activeTestSession, setActiveTestSession] = useState<{
    test: MockTest;
    previewOnly: boolean;
  } | null>(null);
  const [resultSession, setResultSession] = useState<{
    test: MockTest;
    result: TestResultEntry;
    summary: AttemptSummary;
    answers: Record<number, number>;
  } | null>(null);
  const [showTopperPoster, setShowTopperPoster] = useState(false);

  // Mistake re-practice state
  const [repracticeAnswers, setRepracticeAnswers] = useState<Record<string, number>>({});

  // Support ticket form
  const [ticketOrderId, setTicketOrderId] = useState('');
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMsg, setTicketMsg] = useState('');
  const [submittingTicket, setSubmittingTicket] = useState(false);

  // Student Upcoming Assignments Checklist (persisted per user in localStorage)
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [newTaskText, setNewTaskText] = useState('');

  useEffect(() => {
    if (!user) return;
    const key = `exampro_checklist_v1_${user.id}`;
    try {
      const saved = localStorage.getItem(key);
      if (saved) {
        setChecklist(JSON.parse(saved) as ChecklistItem[]);
        return;
      }
    } catch {
      // ignore storage errors
    }
    const defaultTasks: ChecklistItem[] = [
      {
        id: 'task-1',
        title: `Complete ${user.exam.split(',')[0] || 'JKSSB'} Full-Length Mock Test`,
        course: user.exam.split(',')[0] || 'Core Series',
        due: 'Today, 8:00 PM',
        done: user.attempts.length > 0,
      },
      {
        id: 'task-2',
        title: 'Revise J&K Geography & Reorganisation Act Notes',
        course: 'J&K General Knowledge',
        due: 'Tomorrow',
        done: false,
      },
      {
        id: 'task-3',
        title: 'Solve 15 Quantitative & Reasoning PYQ Sets',
        course: 'Math & Reasoning',
        due: 'In 2 days',
        done: false,
      },
      {
        id: 'task-4',
        title: 'Download & review latest official Exam Syllabus PDF',
        course: 'Exam Preparation',
        due: 'This week',
        done: false,
      },
    ];
    setChecklist(defaultTasks);
  }, [user?.id]);

  const updateChecklist = (next: ChecklistItem[]) => {
    setChecklist(next);
    if (!user) return;
    try {
      localStorage.setItem(`exampro_checklist_v1_${user.id}`, JSON.stringify(next));
    } catch {
      // ignore storage errors
    }
  };

  const toggleChecklistItem = (id: string) => {
    updateChecklist(checklist.map((item) => (item.id === id ? { ...item, done: !item.done } : item)));
  };

  const addChecklistItem = (e: React.FormEvent) => {
    e.preventDefault();
    const title = newTaskText.trim();
    if (!title) return;
    const item: ChecklistItem = {
      id: `task-${Date.now()}`,
      title,
      course: user?.exam.split(',')[0] || 'Self Study',
      due: 'Upcoming',
      done: false,
    };
    updateChecklist([item, ...checklist]);
    setNewTaskText('');
  };

  const removeChecklistItem = (id: string) => {
    updateChecklist(checklist.filter((item) => item.id !== id));
  };

  // Computed District Toppers (100% auto-calculated from test results)
  const districtToppers = useMemo(() => {
    const map = new Map<
      string,
      { district: string; name: string; score: number; maxScore: number; targetExam: string; testTitle: string }
    >();
    data.results.forEach((r) => {
      const prev = map.get(r.district);
      if (!prev || r.score > prev.score) {
        const t = data.tests.find((x) => x.id === r.testId);
        map.set(r.district, {
          district: r.district,
          name: r.name,
          score: r.score,
          maxScore: r.maxScore,
          targetExam: r.targetExam,
          testTitle: t?.title || 'Mock Test',
        });
      }
    });
    return Array.from(map.values()).sort((a, b) => b.score - a.score);
  }, [data.results, data.tests]);

  // Student's district leaderboard (cumulative across results)
  const myDistrictBoard = useMemo(() => {
    if (!user) return [];
    const byStudent = new Map<number, { userId: number; name: string; totalScore: number; exam: string }>();
    data.results
      .filter((r) => r.district === user.district)
      .forEach((r) => {
        const existing = byStudent.get(r.userId);
        if (existing) existing.totalScore += r.score;
        else
          byStudent.set(r.userId, {
            userId: r.userId,
            name: r.name,
            totalScore: r.score,
            exam: r.targetExam,
          });
      });
    return Array.from(byStudent.values()).sort((a, b) => b.totalScore - a.totalScore);
  }, [data.results, user]);

  const myDistrictRank = useMemo(() => {
    if (!user) return null;
    const idx = myDistrictBoard.findIndex((x) => x.userId === user.id);
    return idx >= 0 ? idx + 1 : null;
  }, [myDistrictBoard, user]);

  const isPaidUser = useMemo(() => {
    if (!user) return false;
    return user.ownedTestIds.length > 0 || user.ownedBundleIds.length > 0;
  }, [user]);

  const myPayments = useMemo(() => {
    if (!user) return [];
    return data.payments.filter((p) => p.userId === user.id);
  }, [data.payments, user]);

  const todayDailyQuiz = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return data.dailyQuizzes.find((q) => q.date === today) || data.dailyQuizzes[0];
  }, [data.dailyQuizzes]);

  const didDailyQuizToday = useMemo(() => {
    if (!user) return false;
    return user.lastDailyQuizDate === new Date().toISOString().slice(0, 10);
  }, [user]);

  // Dashboard Metrics computed dynamically from real student data
  const dashboardStats = useMemo(() => {
    if (!user) {
      return {
        attendancePct: 0,
        gradeLabel: '—',
        gpaValue: '0.0',
        avgPct: 0,
        pendingTasksCount: 0,
        upcomingCount: 0,
      };
    }
    const streak = user.dailyStreak || 0;
    const attempts = user.attempts.length;
    const attendancePct = Math.min(99, Math.max(76, 76 + streak * 4 + attempts * 3));

    let avgPct = 0;
    if (attempts > 0) {
      const sum = user.attempts.reduce((acc, a) => {
        const pct = a.maxScore > 0 ? (a.score / a.maxScore) * 100 : 0;
        return acc + pct;
      }, 0);
      avgPct = Math.round(sum / attempts);
    }
    const gpaNum = attempts > 0 ? Math.min(10, Math.max(5.5, Number((avgPct / 10).toFixed(1)))) : 8.5;
    const gradeLabel =
      attempts === 0
        ? 'Ready'
        : avgPct >= 90
        ? 'A+'
        : avgPct >= 80
        ? 'A'
        : avgPct >= 70
        ? 'B+'
        : avgPct >= 60
        ? 'B'
        : 'C+';

    const openChecklist = checklist.filter((c) => !c.done).length;
    const dailyPending = didDailyQuizToday ? 0 : 1;
    const pendingTasksCount = openChecklist + dailyPending + (user.mistakes.length > 0 ? 1 : 0);

    const scheduledTests = data.tests.filter((t) => t.status === 'scheduled').length;
    const alertExams = data.updates.filter((u) => Boolean(u.examDate)).length;
    const upcomingCount = Math.max(1, scheduledTests + alertExams);

    return {
      attendancePct,
      gradeLabel,
      gpaValue: gpaNum.toFixed(1),
      avgPct,
      pendingTasksCount,
      upcomingCount,
    };
  }, [user, checklist, didDailyQuizToday, data.tests, data.updates]);

  // Course syllabus progress derived from bundles + user attempts
  const courseProgressList = useMemo(() => {
    const attemptedTestIds = new Set((user?.attempts || []).map((a) => a.testId));
    const list = data.bundles.map((bundle, idx) => {
      const total = Math.max(1, bundle.testIds.length);
      const completed = bundle.testIds.filter((tid) => attemptedTestIds.has(tid)).length;
      const owned = user?.ownedBundleIds.includes(bundle.id) ?? false;
      const basePct = Math.round((completed / total) * 100);
      const progress = basePct > 0 ? basePct : owned ? 28 + idx * 12 : Math.min(40, (user?.attempts.length || 0) * 15);
      return {
        id: bundle.id,
        title: bundle.title,
        exam: bundle.exam,
        completedTests: completed,
        totalTests: bundle.testIds.length,
        progress: Math.min(100, progress),
        owned,
        bundle,
      };
    });
    return list;
  }, [data.bundles, user]);

  // Today's Schedule built from real Daily Quiz + live/scheduled tests
  const todaysSchedule = useMemo(() => {
    const liveTests = data.tests.filter((t) => t.status === 'live');
    const scheduledTests = data.tests.filter((t) => t.status === 'scheduled');
    const firstLive = liveTests[0];
    const secondLive = liveTests[1];
    const nextScheduled = scheduledTests[0];

    return [
      {
        id: 'sch-1',
        time: '09:00 AM – 09:20 AM',
        title: todayDailyQuiz ? todayDailyQuiz.title : 'Daily 10-Q J&K Current Affairs',
        subtitle: `${todayDailyQuiz?.questions.length || 10} Questions · Free Practice`,
        status: didDailyQuizToday ? ('Completed' as const) : ('Live Now' as const),
        actionLabel: didDailyQuizToday ? 'Retake' : 'Join Now',
        onAction: () => setShowDailyQuiz(true),
      },
      {
        id: 'sch-2',
        time: '11:30 AM – 01:00 PM',
        title: firstLive ? firstLive.title : 'JKSSB Full-Length CBT Mock Session',
        subtitle: firstLive
          ? `${firstLive.exam} · ${firstLive.dur} mins · ${firstLive.qs.length} Qs`
          : 'Core Subject Mock Test',
        status: 'Live Now' as const,
        actionLabel: 'Start Mock',
        onAction: () => {
          if (!firstLive) return;
          const unlocked = !firstLive.paid || user?.ownedTestIds.includes(firstLive.id);
          if (unlocked) setActiveTestSession({ test: firstLive, previewOnly: false });
          else
            setCheckoutItem({
              type: 'test',
              id: firstLive.id,
              title: firstLive.title,
              price: firstLive.price,
            });
        },
      },
      {
        id: 'sch-3',
        time: '04:00 PM – 04:45 PM',
        title: `Mistake Notebook Revision (${user?.mistakes.length || 0} Pending)`,
        subtitle: 'Auto-curated weak questions & detailed explanations',
        status: (user?.mistakes.length || 0) === 0 ? ('Completed' as const) : ('Upcoming' as const),
        actionLabel: 'Review',
        onAction: () => setSubView('mistakes'),
      },
      {
        id: 'sch-4',
        time: '07:30 PM – 08:30 PM',
        title: nextScheduled
          ? nextScheduled.title
          : secondLive
          ? secondLive.title
          : 'Evening Sectional Speed Drill',
        subtitle: nextScheduled
          ? `${nextScheduled.exam} · Scheduled ${new Date(nextScheduled.sched).toLocaleDateString('en-IN', {
              day: 'numeric',
              month: 'short',
            })}`
          : secondLive
          ? `${secondLive.exam} · ${secondLive.dur} mins`
          : 'Timed sectional practice',
        status: 'Upcoming' as const,
        actionLabel: 'View Timetable',
        onAction: () => setSubView('timetable'),
      },
    ];
  }, [data.tests, todayDailyQuiz, didDailyQuizToday, user]);

  const filteredUpdates = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return data.updates;
    return data.updates.filter(
      (u) =>
        u.title.toLowerCase().includes(q) ||
        u.message.toLowerCase().includes(q) ||
        u.exam.toLowerCase().includes(q)
    );
  }, [data.updates, searchQuery]);

  // Automatic Month-End 11:55 PM Result Menu Refresh Scheduler
  useEffect(() => {
    let timerId: number | undefined;
    const scheduleNext = () => {
      const next = getNextMonthEndRefreshDate(new Date());
      const remaining = next.getTime() - Date.now();
      // Cap single setTimeout under 2^31-1 ms (~24.8 days) and re-arm accurately
      const delay = Math.min(Math.max(1000, remaining + 1000), 2_000_000_000);
      timerId = window.setTimeout(() => {
        if (Date.now() >= next.getTime()) {
          onRefreshData();
          onToast('Result Menu automatically refreshed for the new monthly cycle!');
        }
        scheduleNext();
      }, delay);
    };
    scheduleNext();
    return () => {
      if (timerId !== undefined) window.clearTimeout(timerId);
    };
  }, [onRefreshData, onToast]);

  const nextResultRefreshLabel = useMemo(() => {
    if (data.resultCycle?.nextRefreshLabel) return data.resultCycle.nextRefreshLabel;
    return getNextMonthEndRefreshDate(new Date()).toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  }, [data.resultCycle?.nextRefreshLabel]);

  // Auth Handlers
  const handleGoogleSignIn = async (email: string, name: string) => {
    setShowGoogleModal(false);
    setAuthErr('');
    try {
      const res = await apiFetch<{
        needsProfile: boolean;
        user?: UserProfile;
        email?: string;
        name?: string;
      }>('/api/auth/google', {
        method: 'POST',
        body: JSON.stringify({ email, name }),
      });
      if (!res.needsProfile && res.user) {
        onLoginSuccess(res.user);
      } else {
        setPendingProfile({
          email: res.email || email,
          name: res.name || name,
          phone: '',
          district: '',
          exam: '',
        });
        setProfileErr('');
      }
    } catch (err: unknown) {
      setAuthErr(err instanceof Error ? err.message : 'Google sign-in failed.');
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthErr('');
    try {
      const res = await apiFetch<{
        needsProfile: boolean;
        user?: UserProfile;
        email?: string;
        name?: string;
        password?: string;
      }>('/api/auth/email', {
        method: 'POST',
        body: JSON.stringify({ mode: authMode, email: authEmail, password: authPw }),
      });
      if (!res.needsProfile && res.user) {
        setAuthPw('');
        onLoginSuccess(res.user);
      } else {
        setPendingProfile({
          email: res.email || authEmail,
          name: res.name || '',
          phone: '',
          district: '',
          exam: '',
          password: res.password || authPw,
        });
        setAuthPw('');
        setProfileErr('');
      }
    } catch (err: unknown) {
      setAuthErr(err instanceof Error ? err.message : 'Authentication failed.');
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingProfile) return;
    setProfileErr('');
    const phone = pendingProfile.phone.replace(/\D/g, '');
    if (!/^[6-9]\d{9}$/.test(phone)) {
      setProfileErr('⚠️ Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.');
      return;
    }
    if (pendingProfile.name.trim().length < 2) {
      setProfileErr('Enter your full name.');
      return;
    }
    if (!pendingProfile.district) {
      setProfileErr('Select your district.');
      return;
    }
    if (!pendingProfile.exam.trim()) {
      setProfileErr('Enter your target exam.');
      return;
    }

    setSavingProfile(true);
    try {
      if (pendingProfile.isEdit) {
        const res = await apiFetch<{ user: UserProfile }>('/api/profile', {
          method: 'PUT',
          body: JSON.stringify({ ...pendingProfile, phone }),
        });
        onUserUpdate(res.user);
        setPendingProfile(null);
        onToast('Profile updated!');
      } else {
        const res = await apiFetch<{ user: UserProfile }>('/api/auth/complete-profile', {
          method: 'POST',
          body: JSON.stringify({ ...pendingProfile, phone }),
        });
        setPendingProfile(null);
        onLoginSuccess(res.user);
        onToast(`Welcome to ExamPro, ${res.user.name.split(' ')[0]}!`);
      }
    } catch (err: unknown) {
      setProfileErr(err instanceof Error ? err.message : 'Could not save profile.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleMistakeAnswer = async (mistakeId: string, optIdx: number, correctIdx: number) => {
    setRepracticeAnswers((prev) => ({ ...prev, [mistakeId]: optIdx }));
    if (optIdx === correctIdx) {
      try {
        const res = await apiFetch<{ isCorrect: boolean; removed: boolean; user: UserProfile }>(
          '/api/mistakes/practice',
          {
            method: 'POST',
            body: JSON.stringify({ mistakeId, selected: optIdx }),
          }
        );
        if (res.removed) {
          onToast('✔ Solved correctly! Removed from Mistake Notebook.');
          setTimeout(() => {
            onUserUpdate(res.user);
          }, 900);
        }
      } catch {
        // ignore
      }
    }
  };

  const handleSupportTicketSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketMsg.trim()) return;
    setSubmittingTicket(true);
    try {
      await apiFetch('/api/support', {
        method: 'POST',
        body: JSON.stringify({
          orderId: ticketOrderId.trim() || undefined,
          subject: ticketSubject.trim() || 'Student Support Request',
          message: ticketMsg.trim(),
        }),
      });
      setTicketOrderId('');
      setTicketSubject('');
      setTicketMsg('');
      onRefreshData();
      onToast('Support ticket submitted! Admin will reply soon.');
    } catch (err: unknown) {
      onToast(err instanceof Error ? err.message : 'Failed to submit ticket.');
    } finally {
      setSubmittingTicket(false);
    }
  };

  const handleFooterCategoryClick = (keyword: string) => {
    if (!user) {
      onToast('Sign in to explore tests');
      return;
    }
    setActiveBundle(null);
    setResultSession(null);
    setSubView('home');
    setExamFilter(keyword);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateSidebar = (next: StudentSubView) => {
    setSubView(next);
    setMobileSidebarOpen(false);
    setShowNotifDropdown(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ================= VIEW 1: COMPLETE PROFILE (1-STEP) =================
  if (pendingProfile) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 flex flex-col justify-center px-4 py-8">
        <div className="mx-auto w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-7 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-display text-xl font-extrabold text-slate-900 dark:text-white">
              {pendingProfile.isEdit ? 'Edit Profile' : 'Complete Your Profile'}
            </h2>
            {pendingProfile.isEdit && (
              <button
                type="button"
                onClick={() => setPendingProfile(null)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
            )}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-5">
            {pendingProfile.isEdit
              ? 'Update your details below. Mobile number must be unique.'
              : 'One quick step before you start. All fields are mandatory.'}
          </p>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Google Email (Locked)
              </label>
              <input
                type="email"
                value={pendingProfile.email}
                disabled
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-800/70 px-3.5 py-2.5 text-sm text-slate-500 dark:text-slate-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                10-Digit Mobile / WhatsApp Number *
              </label>
              <div className="flex gap-2">
                <span className="inline-flex items-center rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 text-sm font-semibold text-slate-700 dark:text-slate-300">
                  +91
                </span>
                <input
                  type="tel"
                  inputMode="numeric"
                  maxLength={10}
                  required
                  value={pendingProfile.phone}
                  onChange={(e) =>
                    setPendingProfile({
                      ...pendingProfile,
                      phone: e.target.value.replace(/\D/g, ''),
                    })
                  }
                  placeholder="9876543210"
                  className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3.5 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={pendingProfile.name}
                onChange={(e) => setPendingProfile({ ...pendingProfile, name: e.target.value })}
                placeholder="Your full name"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3.5 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                District (20 J&amp;K Districts) *
              </label>
              <select
                required
                value={pendingProfile.district}
                onChange={(e) => setPendingProfile({ ...pendingProfile, district: e.target.value })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
              >
                <option value="">Select your district</option>
                {JK_DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                Target Exam *
              </label>
              <input
                type="text"
                required
                value={pendingProfile.exam}
                onChange={(e) => setPendingProfile({ ...pendingProfile, exam: e.target.value })}
                placeholder="e.g. JKSSB Naib Tehsildar, JKPSC KAS"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3.5 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
              />
            </div>

            {profileErr && (
              <div className="rounded-xl border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/50 p-3 text-xs font-semibold text-rose-700 dark:text-rose-300">
                {profileErr}
              </div>
            )}

            <button
              type="submit"
              disabled={savingProfile}
              className="btn-press w-full rounded-xl bg-[#4F46E5] py-3 text-sm font-bold text-white hover:bg-indigo-700 cursor-pointer disabled:opacity-50"
            >
              {savingProfile
                ? 'Saving...'
                : pendingProfile.isEdit
                ? 'Save Profile Changes'
                : 'Save & Continue to Home'}
            </button>

            {!pendingProfile.isEdit && (
              <button
                type="button"
                onClick={() => setPendingProfile(null)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                Use a different account
              </button>
            )}
          </form>
        </div>
      </div>
    );
  }

  // ================= VIEW 2: LOGIN SCREEN (PRESERVED INTACT) =================
  if (!user) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 flex flex-col justify-between">
        <header className="border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md">
          <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-4">
            <div className="font-display text-xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              ExamPro
            </div>
            <div className="flex items-center gap-2">
              <PWAInstallButton compact onToast={onToast} />
              <button
                type="button"
                onClick={onToggleTheme}
                aria-label="Toggle theme"
                className="rounded-xl border border-slate-200 dark:border-slate-700 p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center px-4 py-10">
          <div className="w-full max-w-md space-y-6">
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-sm">
              <div className="text-center mb-6">
                <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#4F46E5] text-2xl text-white shadow-sm">
                  🎓
                </div>
                <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                  Sign in to ExamPro
                </h1>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  Jammu &amp; Kashmir Mock Tests, PYQs &amp; District Ranks
                </p>
              </div>

              {/* 1-Tap Google Sign-In */}
              <button
                type="button"
                onClick={() => setShowGoogleModal(true)}
                className="btn-press w-full flex items-center justify-center gap-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 py-3 px-4 text-sm font-bold text-slate-800 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-700/80 shadow-xs cursor-pointer min-h-[46px]"
              >
                <span className="font-display text-lg font-extrabold text-[#4285F4]">G</span>
                <span>Continue with Google</span>
              </button>

              <div className="my-5 flex items-center gap-3 text-xs text-slate-400">
                <span className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
                <span>or use email &amp; password</span>
                <span className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
              </div>

              <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 dark:bg-slate-800 p-1 mb-4">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('in');
                    setAuthErr('');
                  }}
                  className={`py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    authMode === 'in'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-500'
                  }`}
                >
                  Sign in
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('up');
                    setAuthErr('');
                  }}
                  className={`py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    authMode === 'up'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-500'
                  }`}
                >
                  Create account
                </button>
              </div>

              <form onSubmit={handleEmailAuth} className="space-y-3">
                <input
                  type="email"
                  required
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder="Email address"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3.5 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
                />
                <input
                  type="password"
                  required
                  value={authPw}
                  onChange={(e) => setAuthPw(e.target.value)}
                  placeholder="Password (min 5 chars)"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3.5 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
                />
                {authErr && (
                  <p className="text-xs font-semibold text-rose-600 dark:text-rose-400">{authErr}</p>
                )}
                <button
                  type="submit"
                  className="btn-press w-full rounded-xl bg-[#4F46E5] py-3 text-sm font-bold text-white hover:bg-indigo-700 cursor-pointer min-h-[46px]"
                >
                  {authMode === 'in' ? 'Sign in' : 'Continue'}
                </button>
              </form>
            </div>
          </div>
        </main>

        <Footer
          settings={data.settings}
          onSelectCategoryFilter={handleFooterCategoryClick}
          onOpenPage={setInfoPage}
          onToast={onToast}
        />

        {/* Google 1-Tap Account Chooser */}
        {showGoogleModal && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
            onClick={() => setShowGoogleModal(false)}
          >
            <div
              className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">
                    Choose a Google account
                  </h3>
                  <p className="text-xs text-slate-500">to continue to ExamPro</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowGoogleModal(false)}
                  className="p-1 text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2">
                {[
                  { email: 'aarif.mir@gmail.com', name: 'Aarif Mir', tag: 'Returning Student · Budgam' },
                  { email: 'sana.bhat@gmail.com', name: 'Sana Bhat', tag: 'Returning Student · Srinagar' },
                  { email: data.settings.adminEmail, name: 'Ahmad Junaid', tag: 'Admin Account' },
                ].map((acc) => (
                  <button
                    key={acc.email}
                    type="button"
                    onClick={() => handleGoogleSignIn(acc.email, acc.name)}
                    className="w-full flex items-center gap-3 rounded-xl border border-slate-200 dark:border-slate-700 p-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#4F46E5] text-sm font-bold text-white">
                      {acc.name[0]}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                        {acc.name}
                      </div>
                      <div className="text-xs text-slate-500 truncate">
                        {acc.email} · {acc.tag}
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800">
                <label className="block text-[11px] font-semibold text-slate-500 mb-1.5">
                  Or sign in with any Google email (tests New User flow):
                </label>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={customGoogleEmail}
                    onChange={(e) => setCustomGoogleEmail(e.target.value)}
                    placeholder="student@gmail.com"
                    className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3 py-2 text-xs text-slate-900 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!/^\S+@\S+\.\S+$/.test(customGoogleEmail.trim())) return;
                      handleGoogleSignIn(
                        customGoogleEmail.trim(),
                        customGoogleEmail
                          .split('@')[0]
                          .replace(/[._]+/g, ' ')
                          .replace(/\b\w/g, (c) => c.toUpperCase())
                      );
                    }}
                    className="btn-press rounded-xl bg-[#4F46E5] px-3.5 py-2 text-xs font-semibold text-white cursor-pointer"
                  >
                    Go
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Single-Device Logout Alert */}
        {kickedAlert && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-rose-300 dark:border-rose-800 p-6 text-center shadow-2xl">
              <p className="text-sm font-bold text-slate-900 dark:text-white leading-relaxed">
                ⚠️ You have been logged out because your account was signed in on another device.
              </p>
              <button
                type="button"
                onClick={onDismissKicked}
                className="btn-press mt-4 w-full rounded-xl bg-[#4F46E5] py-2.5 text-sm font-semibold text-white cursor-pointer"
              >
                OK
              </button>
            </div>
          </div>
        )}

        <InfoPagesModal page={infoPage} settings={data.settings} onClose={() => setInfoPage(null)} />
      </div>
    );
  }

  // ================= VIEW 3: ACTIVE CBT TEST ENGINE =================
  if (activeTestSession) {
    return (
      <MockTestEngine
        test={activeTestSession.test}
        user={user}
        previewOnly={activeTestSession.previewOnly}
        onExit={() => setActiveTestSession(null)}
        onBookmarkUpdated={onUserUpdate}
        onToast={onToast}
        onSubmitted={({ result, summary, user: updatedUser, answers }) => {
          onUserUpdate(updatedUser);
          onRefreshData();
          setResultSession({
            test: activeTestSession.test,
            result: result as TestResultEntry,
            summary: summary as AttemptSummary,
            answers,
          });
          setActiveTestSession(null);
        }}
      />
    );
  }

  // ================= VIEW 4: RESULT & SOLUTIONS SCREEN =================
  if (resultSession) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950">
        <ResultView
          test={resultSession.test}
          user={user}
          result={resultSession.result}
          summary={resultSession.summary}
          allResults={data.results}
          answers={resultSession.answers}
          onBackHome={() => {
            setResultSession(null);
            setSubView('home');
          }}
          onToast={onToast}
        />
      </div>
    );
  }

  // ================= VIEW 5: BUNDLE DETAIL SCREEN =================
  if (activeBundle) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950">
        <BundleDetailView
          bundle={activeBundle}
          tests={data.tests}
          user={user}
          onBack={() => setActiveBundle(null)}
          onUnlockBundle={(b) =>
            setCheckoutItem({ type: 'bundle', id: b.id, title: b.title, price: b.price })
          }
          onStartTest={(test, previewOnly) =>
            setActiveTestSession({ test, previewOnly: Boolean(previewOnly) })
          }
        />
        {checkoutItem && (
          <CheckoutModal
            itemType={checkoutItem.type}
            itemId={checkoutItem.id}
            itemTitle={checkoutItem.title}
            price={checkoutItem.price}
            settings={data.settings}
            onClose={() => setCheckoutItem(null)}
            onToast={onToast}
            onSuccess={(order, updatedUser) => {
              setCheckoutItem(null);
              onUserUpdate(updatedUser as UserProfile);
              onRefreshData();
              onToast(
                order.status === 'PAID'
                  ? 'Unlocked successfully!'
                  : 'UTR submitted! Verification pending by Admin.'
              );
            }}
          />
        )}
      </div>
    );
  }

  // Helper to render a Mock Test Card (clean white 16px rounded card with soft shadow)
  const renderTestCard = (t: MockTest) => {
    const isUnlocked = !t.paid || user.ownedTestIds.includes(t.id);
    const isPendingVerification = data.payments.some(
      (p) => p.userId === user.id && p.itemType === 'test' && p.itemId === t.id && p.status === 'PENDING_VERIFICATION'
    );
    const isScheduled = t.status === 'scheduled';

    return (
      <div
        key={t.id}
        className="card-hover group rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.04)] dark:shadow-none flex flex-col justify-between gap-4 hover:border-indigo-200 dark:hover:border-indigo-700"
      >
        <div>
          <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1.5">
            <span className="truncate font-semibold text-[#4F46E5] dark:text-indigo-400">
              {t.exam} {t.subject ? `· ${t.subject}` : ''}
            </span>
            <span className="shrink-0 font-mono font-bold text-slate-800 dark:text-slate-200 tabular-nums">
              {!t.paid ? 'Free' : isUnlocked ? 'Unlocked' : `₹${t.price}`}
            </span>
          </div>

          <h3 className="font-display text-base font-bold text-slate-900 dark:text-white leading-snug">
            {t.title}
          </h3>

          <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
            {t.syllabusTag}
          </p>

          <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
            <span className="inline-flex items-center gap-1 tabular-nums">
              <Clock className="w-3.5 h-3.5" /> {t.dur}m
            </span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1 tabular-nums">
              <BookOpen className="w-3.5 h-3.5" /> {t.qs.length} Qs
            </span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1 tabular-nums">
              <Users className="w-3.5 h-3.5" />{' '}
              {t.attemptCount >= 1000 ? `${(t.attemptCount / 1000).toFixed(1)}k` : t.attemptCount}
            </span>
          </div>

          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
            {t.language} · -{t.neg} Neg ·{' '}
            {t.status === 'live'
              ? 'Live now'
              : new Date(t.sched).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
          </div>
        </div>

        <div className="flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
          {isUnlocked ? (
            <button
              type="button"
              disabled={isScheduled || t.qs.length === 0}
              onClick={() => setActiveTestSession({ test: t, previewOnly: false })}
              className="btn-press flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#4F46E5] py-2.5 px-3 text-xs font-semibold text-white hover:bg-indigo-700 disabled:opacity-45 cursor-pointer min-h-[42px] whitespace-nowrap"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{isScheduled ? 'Starts Soon' : 'Start Test'}</span>
            </button>
          ) : isPendingVerification ? (
            <button
              type="button"
              onClick={() => setSubView('payments')}
              className="flex-1 rounded-xl border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40 py-2.5 px-3 text-xs font-semibold text-amber-800 dark:text-amber-300 cursor-pointer min-h-[42px] whitespace-nowrap"
            >
              Verification Pending
            </button>
          ) : (
            <>
              {t.qs.length > 0 && (
                <button
                  type="button"
                  onClick={() => setActiveTestSession({ test: t, previewOnly: true })}
                  className="btn-press rounded-xl border border-slate-200 dark:border-slate-700 px-3 py-2.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer min-h-[42px] whitespace-nowrap"
                >
                  Preview
                </button>
              )}
              <button
                type="button"
                onClick={() =>
                  setCheckoutItem({ type: 'test', id: t.id, title: t.title, price: t.price })
                }
                className="btn-press flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 dark:bg-[#4F46E5] py-2.5 px-3 text-xs font-semibold text-white hover:bg-slate-800 dark:hover:bg-indigo-700 cursor-pointer min-h-[42px] whitespace-nowrap"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Unlock ₹{t.price}</span>
              </button>
            </>
          )}
        </div>
      </div>
    );
  };

  const firstPaidLockedTest = data.tests.find(
    (t) => t.paid && t.status !== 'draft' && !user.ownedTestIds.includes(t.id)
  );

  const waSupportHref = `https://wa.me/${data.settings.whatsappSupportNumber.replace(
    /\D/g,
    ''
  )}?text=${encodeURIComponent(data.settings.whatsappSupportMessage)}`;

  const filteredToppers =
    selectedTopperDistrict === 'All Districts'
      ? districtToppers.slice(0, 6)
      : districtToppers.filter((d) => d.district === selectedTopperDistrict);

  const publicTests = data.tests.filter((t) => {
    if (t.status === 'draft') return false;
    const q = searchQuery.trim().toLowerCase();
    if (q) {
      const matchesQ =
        t.title.toLowerCase().includes(q) ||
        t.exam.toLowerCase().includes(q) ||
        t.syllabusTag.toLowerCase().includes(q) ||
        (t.subject && t.subject.toLowerCase().includes(q));
      if (!matchesQ) return false;
    }
    if (!examFilter) return true;
    if (examFilter === 'FREE') return !t.paid;
    return (
      t.exam.toLowerCase().includes(examFilter.toLowerCase()) ||
      t.title.toLowerCase().includes(examFilter.toLowerCase())
    );
  });

  const sidebarItems: Array<{
    id: StudentSubView;
    label: string;
    icon: React.ReactNode;
    badge?: number;
  }> = [
    { id: 'home', label: 'Dashboard', icon: <LayoutDashboard className="w-[18px] h-[18px]" /> },
    { id: 'courses', label: 'My Courses', icon: <BookOpen className="w-[18px] h-[18px]" /> },
    {
      id: 'assignments',
      label: 'Assignments',
      icon: <ClipboardList className="w-[18px] h-[18px]" />,
      badge: dashboardStats.pendingTasksCount,
    },
    { id: 'attendance', label: 'Attendance', icon: <CalendarCheck className="w-[18px] h-[18px]" /> },
    { id: 'timetable', label: 'Timetable', icon: <Clock className="w-[18px] h-[18px]" /> },
    { id: 'results', label: 'Results', icon: <BarChart3 className="w-[18px] h-[18px]" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-[18px] h-[18px]" /> },
  ];

  const isNavActive = (id: StudentSubView) => {
    if (id === 'courses' && subView === 'bundles') return true;
    if (id === 'results' && (subView === 'attempts' || subView === 'districtRank')) return true;
    if (id === 'assignments' && subView === 'mistakes') return true;
    if (
      id === 'settings' &&
      ['profile', 'payments', 'bookmarks', 'syllabus', 'support'].includes(subView)
    )
      return true;
    return subView === id;
  };

  const firstName = user.name.split(' ')[0] || user.name;
  const initials = user.name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');

  // ================= MAIN POST-LOGIN STUDENT PORTAL (SIDEBAR + TOP HEADER + #F8FAFC WORKSPACE) =================
  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex pb-16 lg:pb-0">
      {/* Mobile Sidebar Backdrop */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        />
      )}

      {/* Left Sidebar Navigation */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 shrink-0 border-r border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col justify-between transition-transform duration-200 ease-out lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col flex-1 overflow-y-auto px-4 py-5">
          {/* Sidebar Brand */}
          <div className="flex items-center justify-between px-2 mb-6">
            <button
              type="button"
              onClick={() => navigateSidebar('home')}
              className="flex items-center gap-2.5 text-left cursor-pointer"
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#4F46E5] text-white font-display font-extrabold text-base shadow-sm">
                E
              </div>
              <div className="min-w-0">
                <div className="font-display text-lg font-extrabold tracking-tight text-slate-900 dark:text-white leading-none">
                  ExamPro
                </div>
                <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-1 truncate">
                  {isPaidUser ? 'PRO Student Portal' : 'Student Portal'}
                </div>
              </div>
            </button>
            <button
              type="button"
              onClick={() => setMobileSidebarOpen(false)}
              className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Close navigation"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Primary Sidebar Links */}
          <nav className="space-y-1 flex-1" aria-label="Student Navigation">
            {sidebarItems.map((item) => {
              const active = isNavActive(item.id);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateSidebar(item.id)}
                  className={`w-full flex items-center justify-between gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    active
                      ? 'bg-[#4F46E5] text-white shadow-[0_4px_12px_rgba(79,70,229,0.28)]'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-3 min-w-0">
                    {item.icon}
                    <span className="truncate">{item.label}</span>
                  </span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`text-[11px] font-mono font-bold tabular-nums px-1.5 py-0.5 rounded-md ${
                        active
                          ? 'bg-white/20 text-white'
                          : 'bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5] dark:text-indigo-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Sidebar Bottom Summary / Quick Upgrade / Admin Link */}
          <div className="mt-6 space-y-2.5 pt-4 border-t border-slate-100 dark:border-slate-800">
            {user.role === 'admin' && (
              <button
                type="button"
                onClick={onOpenAdmin}
                className="btn-press w-full flex items-center justify-center gap-2 rounded-xl bg-teal-700 px-3 py-2.5 text-xs font-bold text-white hover:bg-teal-800 cursor-pointer whitespace-nowrap"
              >
                <Shield className="w-4 h-4" />
                <span>Open Admin Panel</span>
              </button>
            )}

            {!isPaidUser && firstPaidLockedTest ? (
              <div className="rounded-2xl bg-indigo-50/90 dark:bg-indigo-950/50 p-3.5 border border-indigo-100 dark:border-indigo-900/60">
                <div className="text-xs font-bold text-slate-900 dark:text-white">
                  Unlock Full Test Series
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-snug">
                  Access J&amp;K District Ranks &amp; all full-length mocks.
                </p>
                <button
                  type="button"
                  onClick={() =>
                    setCheckoutItem({
                      type: 'test',
                      id: firstPaidLockedTest.id,
                      title: firstPaidLockedTest.title,
                      price: firstPaidLockedTest.price,
                    })
                  }
                  className="btn-press mt-2.5 w-full rounded-xl bg-[#4F46E5] py-2 text-xs font-bold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  Upgrade Now
                </button>
              </div>
            ) : (
              <div className="rounded-2xl bg-slate-50 dark:bg-slate-800/60 p-3.5">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800 dark:text-white">
                  <span className="inline-flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-amber-500" />
                    <span>{user.dailyStreak || 0}-Day Streak</span>
                  </span>
                  <span className="text-[11px] font-medium text-[#4F46E5] dark:text-indigo-400">
                    {user.district}
                  </span>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={onLogout}
              className="w-full flex items-center gap-2.5 rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 hover:text-rose-600 dark:hover:text-rose-400 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Log out</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Right Workspace Column */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Header */}
        <header className="sticky top-0 z-30 border-b border-slate-200/80 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md">
          <div className="mx-auto max-w-[1360px] px-4 sm:px-6 h-[72px] flex items-center justify-between gap-4">
            {/* Left: Mobile Drawer Button + Personalized Welcome */}
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileSidebarOpen(true)}
                aria-label="Open menu"
                className="lg:hidden rounded-xl border border-slate-200 dark:border-slate-700 p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="min-w-0">
                <h2 className="font-display text-base sm:text-lg font-extrabold text-slate-900 dark:text-white truncate">
                  Welcome back, {firstName}
                </h2>
                <p className="hidden sm:block text-xs text-slate-500 dark:text-slate-400 truncate">
                  {user.exam} · {user.district}
                </p>
              </div>
            </div>

            {/* Right: Search Bar + Notification Bell + Theme/Install + Profile Avatar */}
            <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
              <div className="relative hidden md:block w-60 lg:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    if (subView !== 'home' && subView !== 'courses') {
                      setSubView('home');
                    }
                  }}
                  placeholder="Search tests, courses, notices..."
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800/80 pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-[#4F46E5] focus:bg-white dark:focus:bg-slate-900 transition-colors"
                />
              </div>

              <div className="hidden xl:block">
                <PWAInstallButton compact onToast={onToast} />
              </div>

              {/* Notification Bell */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowNotifDropdown((v) => !v)}
                  aria-label="Notifications"
                  className="relative rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                >
                  <Bell className="w-4 h-4" />
                  {data.updates.length > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[#4F46E5] px-1 text-[10px] font-bold text-white tabular-nums">
                      {data.updates.length}
                    </span>
                  )}
                </button>

                {showNotifDropdown && (
                  <div className="absolute right-0 mt-2 w-80 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xl z-50">
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-display text-sm font-bold text-slate-900 dark:text-white">
                        Notice Board Alerts
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setShowNotifDropdown(false);
                          setSubView('updates');
                        }}
                        className="text-xs font-semibold text-[#4F46E5] dark:text-indigo-400 hover:underline cursor-pointer"
                      >
                        View all
                      </button>
                    </div>
                    <div className="space-y-2.5 max-h-64 overflow-y-auto">
                      {data.updates.slice(0, 4).map((upd) => (
                        <button
                          key={upd.id}
                          type="button"
                          onClick={() => {
                            setShowNotifDropdown(false);
                            setSubView('updates');
                          }}
                          className="w-full text-left rounded-xl p-2.5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        >
                          <div className="text-[11px] font-semibold text-[#4F46E5] dark:text-indigo-400">
                            {upd.exam} · {upd.createdAt}
                          </div>
                          <div className="text-xs font-bold text-slate-900 dark:text-white mt-0.5 line-clamp-1">
                            {upd.title}
                          </div>
                        </button>
                      ))}
                      {data.updates.length === 0 && (
                        <p className="text-xs text-slate-500 py-3 text-center">No new notices.</p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={onToggleTheme}
                aria-label="Toggle theme"
                className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              >
                {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              {/* Student Profile Avatar */}
              <button
                type="button"
                onClick={() => navigateSidebar('settings')}
                title={`${user.name} (${user.district})`}
                className="flex items-center gap-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-1 pr-2.5 hover:border-[#4F46E5] transition-colors cursor-pointer"
              >
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#4F46E5] text-xs font-extrabold text-white">
                  {initials || 'S'}
                </span>
                <span className="hidden sm:block text-left max-w-[110px]">
                  <span className="block text-xs font-bold text-slate-900 dark:text-white truncate leading-tight">
                    {firstName}
                  </span>
                  <span className="block text-[10px] text-slate-500 dark:text-slate-400 truncate leading-tight">
                    {isPaidUser ? 'PRO Member' : 'Free Plan'}
                  </span>
                </span>
              </button>
            </div>
          </div>

          {/* Mobile Search Bar */}
          <div className="md:hidden px-4 pb-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (subView !== 'home' && subView !== 'courses') {
                    setSubView('home');
                  }
                }}
                placeholder="Search mock tests, courses, notices..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
              />
            </div>
          </div>
        </header>

        {/* Main Content Container */}
        <main className="flex-1 mx-auto w-full max-w-[1360px] px-4 sm:px-6 py-6">
          {/* ================= STUDENT HOME SCREEN (DASHBOARD) ================= */}
          {subView === 'home' && (
            <div className="space-y-6">
              <PWAInstallBanner onToast={onToast} />

              {/* Row 1: 4 Quick Stats Cards */}
              <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
                <button
                  type="button"
                  onClick={() => navigateSidebar('attendance')}
                  className="card-hover text-left rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 cursor-pointer"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Attendance
                    </span>
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-950/70 text-[#4F46E5] dark:text-indigo-400">
                      <CalendarCheck className="w-4 h-4" />
                    </span>
                  </div>
                  <div className="mt-3 font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                    {dashboardStats.attendancePct}%
                  </div>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    {user.dailyStreak || 0}-day study streak · On track
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => navigateSidebar('results')}
                  className="card-hover text-left rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 cursor-pointer"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Current Grade / GPA
                    </span>
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400">
                      <Award className="w-4 h-4" />
                    </span>
                  </div>
                  <div className="mt-3 font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                    {dashboardStats.gradeLabel}{' '}
                    <span className="text-base font-bold text-slate-500 dark:text-slate-400">
                      · {dashboardStats.gpaValue} GPA
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                    {user.attempts.length > 0
                      ? `${dashboardStats.avgPct}% avg across ${user.attempts.length} test${
                          user.attempts.length === 1 ? '' : 's'
                        }`
                      : 'Take a mock test to compute score'}
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => navigateSidebar('assignments')}
                  className="card-hover text-left rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 cursor-pointer"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Pending Assignments
                    </span>
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 dark:bg-amber-950/70 text-amber-600 dark:text-amber-400">
                      <ClipboardList className="w-4 h-4" />
                    </span>
                  </div>
                  <div className="mt-3 font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                    {dashboardStats.pendingTasksCount}
                  </div>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                    {user.mistakes.length} mistake{user.mistakes.length === 1 ? '' : 's'} to master ·{' '}
                    {didDailyQuizToday ? 'Daily quiz done' : 'Daily quiz due'}
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => navigateSidebar('timetable')}
                  className="card-hover text-left rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 cursor-pointer"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Upcoming Exams
                    </span>
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-50 dark:bg-sky-950/70 text-sky-600 dark:text-sky-400">
                      <Calendar className="w-4 h-4" />
                    </span>
                  </div>
                  <div className="mt-3 font-display text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                    {dashboardStats.upcomingCount}
                  </div>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    Scheduled mocks &amp; J&amp;K exam dates
                  </p>
                </button>
              </section>

              {/* Row 2: Today's Schedule + My Courses Syllabus Progress */}
              <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {/* Today's Schedule */}
                <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 flex flex-col">
                  <div className="flex items-center justify-between gap-3 mb-5">
                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                        Today&apos;s Schedule
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Live classes, daily J&amp;K quiz &amp; scheduled test timings
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateSidebar('timetable')}
                      className="text-xs font-semibold text-[#4F46E5] dark:text-indigo-400 hover:underline whitespace-nowrap cursor-pointer"
                    >
                      Full Timetable →
                    </button>
                  </div>

                  <div className="divide-y divide-slate-100 dark:divide-slate-800 flex-1">
                    {todaysSchedule.map((slot) => {
                      const statusStyles =
                        slot.status === 'Live Now'
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                          : slot.status === 'Completed'
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                          : 'bg-indigo-50 dark:bg-indigo-950/60 text-[#4F46E5] dark:text-indigo-300';

                      return (
                        <div
                          key={slot.id}
                          className="py-3.5 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="min-w-0 space-y-1">
                            <div className="flex flex-wrap items-center gap-2.5 text-xs">
                              <span className="font-mono font-semibold text-slate-500 dark:text-slate-400 tabular-nums">
                                {slot.time}
                              </span>
                              <span className={`rounded-lg px-2 py-0.5 text-[11px] font-bold ${statusStyles}`}>
                                {slot.status}
                              </span>
                            </div>
                            <div className="font-display text-sm font-bold text-slate-900 dark:text-white truncate">
                              {slot.title}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                              {slot.subtitle}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={slot.onAction}
                            className="btn-press shrink-0 rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-800 dark:text-white hover:border-[#4F46E5] hover:text-[#4F46E5] dark:hover:text-indigo-300 cursor-pointer whitespace-nowrap"
                          >
                            {slot.actionLabel}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* My Courses with Syllabus Progress Bars */}
                <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 flex flex-col">
                  <div className="flex items-center justify-between gap-3 mb-5">
                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                        My Courses
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Syllabus &amp; mock series completion
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateSidebar('courses')}
                      className="text-xs font-semibold text-[#4F46E5] dark:text-indigo-400 hover:underline whitespace-nowrap cursor-pointer"
                    >
                      All Courses →
                    </button>
                  </div>

                  <div className="space-y-4 flex-1">
                    {courseProgressList.slice(0, 4).map((course) => (
                      <div
                        key={course.id}
                        onClick={() => setActiveBundle(course.bundle)}
                        className="group cursor-pointer rounded-xl p-3 -mx-3 hover:bg-[#F8FAFC] dark:hover:bg-slate-800/60 transition-colors"
                      >
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <div className="min-w-0">
                            <div className="font-display text-sm font-bold text-slate-900 dark:text-white group-hover:text-[#4F46E5] dark:group-hover:text-indigo-400 truncate">
                              {course.title}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400">
                              {course.exam} · {course.completedTests}/{course.totalTests} mocks completed
                            </div>
                          </div>
                          <span className="font-mono text-xs font-bold text-[#4F46E5] dark:text-indigo-400 tabular-nums shrink-0">
                            {course.progress}%
                          </span>
                        </div>
                        <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-[#4F46E5] transition-all duration-300"
                            style={{ width: `${course.progress}%` }}
                          />
                        </div>
                      </div>
                    ))}
                    {courseProgressList.length === 0 && (
                      <p className="text-xs text-slate-500 py-6 text-center">
                        No courses available yet.
                      </p>
                    )}
                  </div>
                </div>
              </section>

              {/* Row 3: Upcoming Assignments Checklist + Notice Board */}
              <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {/* Upcoming Assignments Checklist */}
                <div className="lg:col-span-6 rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 flex flex-col">
                  <div className="flex items-center justify-between gap-3 mb-4">
                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                        Upcoming Assignments
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {checklist.filter((c) => c.done).length} of {checklist.length} tasks completed
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateSidebar('assignments')}
                      className="text-xs font-semibold text-[#4F46E5] dark:text-indigo-400 hover:underline whitespace-nowrap cursor-pointer"
                    >
                      Manage Tasks →
                    </button>
                  </div>

                  <div className="space-y-2.5 flex-1">
                    {checklist.slice(0, 4).map((item) => (
                      <div
                        key={item.id}
                        className="flex items-start justify-between gap-3 rounded-xl p-2.5 hover:bg-[#F8FAFC] dark:hover:bg-slate-800/60 transition-colors"
                      >
                        <button
                          type="button"
                          onClick={() => toggleChecklistItem(item.id)}
                          className="flex items-start gap-3 text-left flex-1 min-w-0 cursor-pointer"
                        >
                          <span
                            className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${
                              item.done
                                ? 'bg-[#4F46E5] border-[#4F46E5] text-white'
                                : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900'
                            }`}
                          >
                            {item.done && <Check className="w-3.5 h-3.5" />}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span
                              className={`block text-sm font-medium ${
                                item.done
                                  ? 'line-through text-slate-400 dark:text-slate-500'
                                  : 'text-slate-800 dark:text-slate-100'
                              }`}
                            >
                              {item.title}
                            </span>
                            <span className="block text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                              {item.course} · Due {item.due}
                            </span>
                          </span>
                        </button>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={addChecklistItem} className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                    <input
                      type="text"
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                      placeholder="Add a study task or assignment..."
                      className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
                    />
                    <button
                      type="submit"
                      className="btn-press inline-flex items-center gap-1 rounded-xl bg-[#4F46E5] px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer whitespace-nowrap"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </form>
                </div>

                {/* Notice Board */}
                <div className="lg:col-span-6 rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none border border-slate-100 dark:border-slate-800 flex flex-col">
                  <div className="flex items-center justify-between gap-3 mb-4">
                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                        Notice Board
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Official J&amp;K exam alerts, admit cards &amp; announcements
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigateSidebar('updates')}
                      className="text-xs font-semibold text-[#4F46E5] dark:text-indigo-400 hover:underline whitespace-nowrap cursor-pointer"
                    >
                      All Notices ({data.updates.length}) →
                    </button>
                  </div>

                  <div className="divide-y divide-slate-100 dark:divide-slate-800 flex-1">
                    {filteredUpdates.slice(0, 4).map((upd) => (
                      <div key={upd.id} className="py-3 first:pt-0 last:pb-0">
                        <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                          <span className="font-bold text-[#4F46E5] dark:text-indigo-400">
                            {upd.exam} · {upd.type.replace('_', ' ')}
                          </span>
                          <span>{upd.createdAt}</span>
                        </div>
                        <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                          {upd.title}
                        </h3>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">
                          {upd.message}
                        </p>
                      </div>
                    ))}
                    {filteredUpdates.length === 0 && (
                      <p className="text-xs text-slate-500 py-6 text-center">
                        No notices matching &ldquo;{searchQuery}&rdquo;.
                      </p>
                    )}
                  </div>
                </div>
              </section>

              {/* Daily 10-Question J&K Current Affairs Banner + J&K District Toppers Hall of Fame */}
              {todayDailyQuiz && (
                <section className="rounded-2xl bg-gradient-to-r from-[#4F46E5] via-indigo-700 to-slate-900 p-6 sm:p-7 text-white shadow-[0_6px_24px_rgba(79,70,229,0.22)]">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
                    <div className="space-y-1.5 max-w-2xl">
                      <div className="flex flex-wrap items-center gap-3 text-xs font-semibold text-indigo-100">
                        <span className="inline-flex items-center gap-1 text-amber-300 font-bold">
                          <Flame className="w-4 h-4" /> Daily Streak: {user.dailyStreak || 0} Days
                        </span>
                        <span>·</span>
                        <span>{todayDailyQuiz.questions.length} Questions · 5 Min · Free</span>
                      </div>
                      <h2 className="font-display text-xl sm:text-2xl font-extrabold tracking-tight">
                        {todayDailyQuiz.title}
                      </h2>
                      <p className="text-xs sm:text-sm text-indigo-100/90">
                        Practice today&apos;s high-yield J&amp;K current affairs with instant explanations and keep your attendance streak active.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowDailyQuiz(true)}
                      className="btn-press group shrink-0 inline-flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-bold text-[#4F46E5] hover:bg-indigo-50 cursor-pointer shadow-sm whitespace-nowrap"
                    >
                      <span>{didDailyQuizToday ? 'Practice Again' : 'Start Daily Quiz'}</span>
                      <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </button>
                  </div>
                </section>
              )}

              {/* District Toppers Hall of Fame */}
              <section className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  <div>
                    <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-amber-500" />
                      <span>J&amp;K District Toppers Hall of Fame</span>
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Auto-calculated Rank #1 scorers across 20 Jammu &amp; Kashmir districts
                    </p>
                  </div>
                  <select
                    value={selectedTopperDistrict}
                    onChange={(e) => setSelectedTopperDistrict(e.target.value)}
                    className="rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 px-3 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200"
                  >
                    <option value="All Districts">All Districts</option>
                    {JK_DISTRICTS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                {filteredToppers.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">
                    No topper recorded in {selectedTopperDistrict} yet. Be the first to take a test!
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {filteredToppers.map((topper) => (
                      <div
                        key={topper.district}
                        className="rounded-xl border border-slate-100 dark:border-slate-800 bg-[#F8FAFC] dark:bg-slate-800/50 p-3.5 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <div className="text-[11px] font-bold text-amber-600 dark:text-amber-400">
                            #1 in {topper.district}
                          </div>
                          <div className="font-display text-sm font-bold text-slate-900 dark:text-white truncate">
                            {topper.name}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {topper.targetExam}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="font-mono text-sm font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                            {topper.score}/{topper.maxScore}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              {/* Exam Filter + Mock Test Library */}
              <div className="space-y-6 pt-2">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    {['', 'JKSSB', 'JKPSC', 'JKP', 'JKBOSE', 'FREE'].map((f) => (
                      <button
                        key={f || 'all'}
                        type="button"
                        onClick={() => setExamFilter(f)}
                        className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                          examFilter === f
                            ? 'bg-[#4F46E5] border-[#4F46E5] text-white shadow-xs'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-[#4F46E5]'
                        }`}
                      >
                        {f === '' ? 'All Exams' : f === 'FREE' ? 'Free Mocks' : f}
                      </button>
                    ))}
                  </div>
                  {(examFilter || searchQuery) && (
                    <button
                      type="button"
                      onClick={() => {
                        setExamFilter('');
                        setSearchQuery('');
                      }}
                      className="text-xs font-semibold text-[#4F46E5] dark:text-indigo-400 hover:underline cursor-pointer"
                    >
                      Clear Filters
                    </button>
                  )}
                </div>

                {DEFAULT_CATEGORIES.map((cat) => {
                  const list = publicTests.filter((t) => t.cat === cat.id);
                  if (list.length === 0 && (examFilter || searchQuery)) return null;
                  return (
                    <section key={cat.id} className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h2 className="font-display text-lg font-extrabold text-slate-900 dark:text-white">
                          {cat.icon} {cat.label}
                        </h2>
                        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 tabular-nums">
                          {list.length} {list.length === 1 ? 'Test' : 'Tests'}
                        </span>
                      </div>
                      {list.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 p-6 text-center text-xs text-slate-500 bg-white/50 dark:bg-slate-900/50">
                          No tests in this category yet.
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {list.map(renderTestCard)}
                        </div>
                      )}
                    </section>
                  );
                })}
              </div>
            </div>
          )}

          {/* ================= MY COURSES & TEST BUNDLES ================= */}
          {(subView === 'courses' || subView === 'bundles') && (
            <div className="space-y-6">
              <div>
                <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                  My Courses &amp; Test Series Bundles
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Track your syllabus progress and open full-length &amp; sectional test packs
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {courseProgressList.map((course) => (
                  <div
                    key={course.id}
                    onClick={() => setActiveBundle(course.bundle)}
                    className="card-hover group rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] dark:shadow-none flex flex-col justify-between gap-4 cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-[#4F46E5] dark:text-indigo-400">
                          {course.exam} · {course.bundle.validity}
                        </span>
                        <span className="font-mono font-bold text-slate-700 dark:text-slate-200 tabular-nums">
                          {course.owned ? 'Enrolled' : `₹${course.bundle.price}`}
                        </span>
                      </div>
                      <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                        {course.title}
                      </h3>
                      <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                        {course.bundle.desc}
                      </p>

                      <div className="mt-4">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-slate-500 dark:text-slate-400">
                            Syllabus Progress ({course.completedTests}/{course.totalTests} mocks)
                          </span>
                          <span className="font-mono font-bold text-[#4F46E5] dark:text-indigo-400 tabular-nums">
                            {course.progress}%
                          </span>
                        </div>
                        <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-[#4F46E5]"
                            style={{ width: `${course.progress}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                      <div>
                        <span className="font-display text-base font-extrabold text-slate-900 dark:text-white tabular-nums">
                          {course.owned ? 'Unlocked' : `₹${course.bundle.price}`}
                        </span>{' '}
                        {!course.owned && (
                          <span className="text-xs text-slate-400 line-through tabular-nums">
                            ₹{course.bundle.mrp}
                          </span>
                        )}
                      </div>
                      <span className="inline-flex items-center gap-1 text-xs font-bold text-[#4F46E5] dark:text-indigo-400">
                        Open Course <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================= ASSIGNMENTS & CHECKLIST ================= */}
          {subView === 'assignments' && (
            <div className="max-w-4xl space-y-6">
              <div>
                <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                  Assignments &amp; Study Tasks
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Manage your preparation checklist, clear Mistake Notebook items, and complete today&apos;s quiz
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
                  <div>
                    <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Daily Current Affairs
                    </div>
                    <div className="font-display text-base font-bold text-slate-900 dark:text-white mt-0.5">
                      {didDailyQuizToday ? 'Completed Today' : 'Pending Today'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowDailyQuiz(true)}
                    className="btn-press rounded-xl bg-[#4F46E5] px-4 py-2 text-xs font-semibold text-white cursor-pointer whitespace-nowrap"
                  >
                    {didDailyQuizToday ? 'Retake' : 'Start Quiz'}
                  </button>
                </div>

                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
                  <div>
                    <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      Mistake Notebook Mastery
                    </div>
                    <div className="font-display text-base font-bold text-slate-900 dark:text-white mt-0.5 tabular-nums">
                      {user.mistakes.length} Question{user.mistakes.length === 1 ? '' : 's'} Left
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSubView('mistakes')}
                    className="btn-press rounded-xl border border-slate-200 dark:border-slate-700 px-4 py-2 text-xs font-semibold text-slate-800 dark:text-white hover:border-[#4F46E5] cursor-pointer whitespace-nowrap"
                  >
                    Practice Now
                  </button>
                </div>
              </div>

              <div className="rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                <form onSubmit={addChecklistItem} className="flex gap-2 mb-5">
                  <input
                    type="text"
                    value={newTaskText}
                    onChange={(e) => setNewTaskText(e.target.value)}
                    placeholder="Add a new assignment or revision topic..."
                    className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 px-3.5 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#4F46E5]"
                  />
                  <button
                    type="submit"
                    className="btn-press inline-flex items-center gap-1.5 rounded-xl bg-[#4F46E5] px-4 py-2.5 text-xs font-bold text-white cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Task</span>
                  </button>
                </form>

                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {checklist.map((item) => (
                    <div key={item.id} className="py-3 flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => toggleChecklistItem(item.id)}
                        className="flex items-start gap-3 text-left flex-1 min-w-0 cursor-pointer"
                      >
                        <span
                          className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                            item.done
                              ? 'bg-[#4F46E5] border-[#4F46E5] text-white'
                              : 'border-slate-300 dark:border-slate-600'
                          }`}
                        >
                          {item.done && <Check className="w-3.5 h-3.5" />}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span
                            className={`block text-sm font-medium ${
                              item.done
                                ? 'line-through text-slate-400 dark:text-slate-500'
                                : 'text-slate-900 dark:text-white'
                            }`}
                          >
                            {item.title}
                          </span>
                          <span className="block text-xs text-slate-500 dark:text-slate-400">
                            {item.course} · Due {item.due}
                          </span>
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => removeChecklistItem(item.id)}
                        aria-label="Remove task"
                        className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  {checklist.length === 0 && (
                    <p className="text-xs text-slate-500 py-6 text-center">
                      All tasks cleared! Add a new study goal above.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ================= ATTENDANCE & STUDY STREAK ================= */}
          {subView === 'attendance' && (
            <div className="max-w-4xl space-y-6">
              <div>
                <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                  Attendance &amp; Study Consistency
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Your daily login activity, streak log, and preparation attendance percentage
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                  <div className="text-xs text-slate-500 dark:text-slate-400">Overall Attendance</div>
                  <div className="mt-2 font-display text-3xl font-extrabold text-[#4F46E5] dark:text-indigo-400 tabular-nums">
                    {dashboardStats.attendancePct}%
                  </div>
                </div>
                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                  <div className="text-xs text-slate-500 dark:text-slate-400">Daily Quiz Streak</div>
                  <div className="mt-2 font-display text-3xl font-extrabold text-amber-600 dark:text-amber-400 tabular-nums">
                    {user.dailyStreak || 0} Days
                  </div>
                </div>
                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                  <div className="text-xs text-slate-500 dark:text-slate-400">Last Active</div>
                  <div className="mt-2 font-display text-xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                    {user.lastActiveDate}
                  </div>
                </div>
              </div>

              <div className="rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                <h2 className="font-display text-base font-bold text-slate-900 dark:text-white mb-4">
                  14-Day Activity Tracker
                </h2>
                <div className="grid grid-cols-7 gap-2.5">
                  {Array.from({ length: 14 }).map((_, i) => {
                    const daysAgo = 13 - i;
                    const active = daysAgo <= (user.dailyStreak || 0);
                    const dt = new Date();
                    dt.setDate(dt.getDate() - daysAgo);
                    return (
                      <div
                        key={i}
                        className={`rounded-xl p-3 text-center border ${
                          active
                            ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-[#4F46E5] dark:text-indigo-300'
                            : 'bg-[#F8FAFC] dark:bg-slate-800/50 border-slate-100 dark:border-slate-800 text-slate-400'
                        }`}
                      >
                        <div className="text-[10px] font-semibold">
                          {dt.toLocaleDateString('en-IN', { weekday: 'short' })}
                        </div>
                        <div className="font-mono text-sm font-bold mt-1 tabular-nums">
                          {dt.getDate()}
                        </div>
                        <div className="mt-1 flex justify-center">
                          {active ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#4F46E5] dark:text-indigo-400" />
                          ) : (
                            <span className="text-[10px]">—</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ================= TIMETABLE & UPCOMING EXAMS ================= */}
          {subView === 'timetable' && (
            <div className="max-w-4xl space-y-6">
              <div>
                <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                  Timetable &amp; Exam Schedule
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Today&apos;s study schedule and upcoming scheduled mock tests
                </p>
              </div>

              <div className="rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
                {todaysSchedule.map((slot) => (
                  <div
                    key={slot.id}
                    className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono font-bold text-[#4F46E5] dark:text-indigo-400 tabular-nums">
                          {slot.time}
                        </span>
                        <span>·</span>
                        <span className="font-semibold text-slate-600 dark:text-slate-300">
                          {slot.status}
                        </span>
                      </div>
                      <h3 className="font-display text-base font-bold text-slate-900 dark:text-white mt-0.5">
                        {slot.title}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{slot.subtitle}</p>
                    </div>
                    <button
                      type="button"
                      onClick={slot.onAction}
                      className="btn-press shrink-0 rounded-xl bg-[#4F46E5] px-4 py-2 text-xs font-semibold text-white cursor-pointer whitespace-nowrap"
                    >
                      {slot.actionLabel}
                    </button>
                  </div>
                ))}
              </div>

              <div className="space-y-3">
                <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  Scheduled Mock Tests &amp; Target Exam Dates
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {data.tests
                    .filter((t) => t.status === 'scheduled')
                    .map((t) => (
                      <div
                        key={t.id}
                        className="rounded-2xl bg-white dark:bg-slate-900 p-4 shadow-[0_2px_12px_rgba(15,23,42,0.04)] border border-slate-100 dark:border-slate-800"
                      >
                        <div className="text-xs font-bold text-[#4F46E5] dark:text-indigo-400">
                          {t.exam} · {new Date(t.sched).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                        </div>
                        <div className="font-display text-sm font-bold text-slate-900 dark:text-white mt-1">
                          {t.title}
                        </div>
                        <div className="text-xs text-slate-500 mt-1">
                          {t.dur} mins · {t.qs.length} Qs
                        </div>
                      </div>
                    ))}
                  {data.updates
                    .filter((u) => u.examDate)
                    .map((u) => (
                      <div
                        key={u.id}
                        className="rounded-2xl bg-white dark:bg-slate-900 p-4 shadow-[0_2px_12px_rgba(15,23,42,0.04)] border border-slate-100 dark:border-slate-800"
                      >
                        <div className="text-xs font-bold text-amber-600 dark:text-amber-400">
                          {u.exam} · Exam Date: {u.examDate}
                        </div>
                        <div className="font-display text-sm font-bold text-slate-900 dark:text-white mt-1">
                          {u.title}
                        </div>
                        <div className="text-xs text-slate-500 mt-1 line-clamp-2">{u.message}</div>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}

          {/* ================= RESULTS & RANKINGS ================= */}
          {(subView === 'results' || subView === 'attempts') && (
            <div className="max-w-4xl space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                    Results &amp; District Performance
                  </h1>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Your test scores, All-J&amp;K rank, and {user.district} district standing · Next monthly auto-refresh: {nextResultRefreshLabel}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setSubView('districtRank')}
                  className="btn-press rounded-xl bg-[#4F46E5] px-4 py-2 text-xs font-semibold text-white cursor-pointer whitespace-nowrap"
                >
                  View {user.district} Leaderboard
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                  <div className="text-xs text-slate-500">Current Grade / GPA</div>
                  <div className="mt-2 font-display text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                    {dashboardStats.gradeLabel} · {dashboardStats.gpaValue}
                  </div>
                </div>
                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                  <div className="text-xs text-slate-500">Tests Completed</div>
                  <div className="mt-2 font-display text-2xl font-extrabold text-[#4F46E5] dark:text-indigo-400 tabular-nums">
                    {user.attempts.length}
                  </div>
                </div>
                <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.05)] border border-slate-100 dark:border-slate-800">
                  <div className="text-xs text-slate-500">{user.district} Rank</div>
                  <div className="mt-2 font-display text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {myDistrictRank ? `#${myDistrictRank}` : '—'}
                  </div>
                </div>
              </div>

              {user.attempts.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
                  You haven&apos;t attempted any mock test yet. Start a free mock test from the Dashboard!
                </div>
              ) : (
                <div className="space-y-3">
                  {user.attempts.map((a) => (
                    <div
                      key={a.id}
                      className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-[0_2px_12px_rgba(15,23,42,0.04)] flex flex-wrap items-center justify-between gap-3"
                    >
                      <div>
                        <div className="font-display text-sm font-bold text-slate-900 dark:text-white">
                          {a.testTitle}
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5 tabular-nums">
                          {a.date} · All-J&amp;K Rank #{a.rank} · {user.district} Rank #{a.districtRank} ·{' '}
                          {a.percentile}%ile
                        </div>
                      </div>
                      <div className="font-mono text-base font-extrabold text-[#4F46E5] dark:text-indigo-400 tabular-nums">
                        {a.score} / {a.maxScore}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= J&K UPDATES / NOTICE BOARD FULL VIEW ================= */}
          {subView === 'updates' && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Bell className="w-6 h-6 text-[#4F46E5] dark:text-indigo-400" />
                  <span>Notice Board &amp; J&amp;K Exam Updates</span>
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Real-time exam dates, admit card links, and official alerts
                </p>
              </div>

              <div className="space-y-4">
                {filteredUpdates.map((upd) => (
                  <div
                    key={upd.id}
                    className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.04)] space-y-2"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="font-bold text-[#4F46E5] dark:text-indigo-400">
                        {upd.exam} · {upd.type.replace('_', ' ').toUpperCase()}
                      </span>
                      <span className="text-slate-400">{upd.createdAt}</span>
                    </div>
                    <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">
                      {upd.title}
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {upd.message}
                    </p>
                    {upd.examDate && (
                      <div className="pt-2 flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400">
                        <Calendar className="w-4 h-4" />
                        <span>Target Exam Date: {upd.examDate}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================= SETTINGS & PROFILE HUB ================= */}
          {(subView === 'settings' || subView === 'profile') && (
            <div className="max-w-3xl space-y-6">
              {/* Profile Header Card */}
              <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-[0_2px_12px_rgba(15,23,42,0.05)]">
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-[#4F46E5] text-xl font-extrabold text-white">
                    {user.name[0]?.toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-display text-xl font-extrabold text-slate-900 dark:text-white truncate">
                        {user.name}
                      </h2>
                      <span
                        className={`rounded-md px-2 py-0.5 text-[11px] font-bold ${
                          isPaidUser
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {isPaidUser ? 'PRO Unlocked' : 'Free Plan'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {user.email}
                    </p>
                  </div>
                </div>

                {isPaidUser ? (
                  <div className="mt-5 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/70 dark:bg-emerald-950/30 p-4 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                        {user.ownedTestIds.length} Mock Test{user.ownedTestIds.length !== 1 ? 's' : ''} Unlocked
                      </div>
                      <div className="text-xs text-emerald-700 dark:text-emerald-300">
                        Your premium tests &amp; district ranks are active
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setSubView('home')}
                        className="btn-press rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white cursor-pointer"
                      >
                        Dashboard
                      </button>
                      <button
                        type="button"
                        onClick={() => setSubView('payments')}
                        className="btn-press rounded-xl border border-emerald-300 dark:border-emerald-700 px-3.5 py-2 text-xs font-semibold text-emerald-800 dark:text-emerald-200 cursor-pointer"
                      >
                        View Receipt
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="mt-5 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/80 dark:bg-indigo-950/30 p-4 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold text-indigo-950 dark:text-indigo-100">
                        Unlock JKSSB &amp; JKPSC Mock Tests
                      </div>
                      <div className="text-xs text-indigo-700 dark:text-indigo-300">
                        Full-length paid mocks with District Ranks
                      </div>
                    </div>
                    {firstPaidLockedTest && (
                      <button
                        type="button"
                        onClick={() =>
                          setCheckoutItem({
                            type: 'test',
                            id: firstPaidLockedTest.id,
                            title: firstPaidLockedTest.title,
                            price: firstPaidLockedTest.price,
                          })
                        }
                        className="btn-press rounded-xl bg-[#4F46E5] px-4 py-2 text-xs font-bold text-white cursor-pointer"
                      >
                        Buy Now
                      </button>
                    )}
                  </div>
                )}

                {user.role === 'admin' && (
                  <button
                    type="button"
                    onClick={onOpenAdmin}
                    className="btn-press mt-4 w-full flex items-center justify-center gap-2 rounded-xl bg-teal-700 py-3 text-sm font-bold text-white hover:bg-teal-800 cursor-pointer"
                  >
                    <Shield className="w-4 h-4" />
                    <span>Open Admin Dashboard</span>
                  </button>
                )}

                <div className="mt-5 divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                  {[
                    ['Email', user.email],
                    ['Mobile', `+91 ${user.phone}`],
                    ['District', user.district],
                    ['Target Exam', user.exam],
                  ].map(([k, v]) => (
                    <div key={k} className="py-2.5 flex justify-between gap-4">
                      <span className="text-slate-500 dark:text-slate-400">{k}</span>
                      <span className="font-semibold text-slate-900 dark:text-white text-right">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Account & Study Tools Menu */}
              <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-[0_2px_12px_rgba(15,23,42,0.05)] divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
                {[
                  {
                    icon: <Wallet className="w-4 h-4 text-[#4F46E5]" />,
                    label: 'My Payments & UPI Receipts',
                    right: `${myPayments.length} ›`,
                    onClick: () => setSubView('payments'),
                  },
                  {
                    icon: <BookOpen className="w-4 h-4 text-rose-600" />,
                    label: 'My Mistake Notebook',
                    right: `${user.mistakes.length} ›`,
                    onClick: () => setSubView('mistakes'),
                  },
                  {
                    icon: <Trophy className="w-4 h-4 text-amber-500" />,
                    label: 'District Rank Leaderboard',
                    right: `${myDistrictRank ? `#${myDistrictRank}` : '—'} in ${user.district} ›`,
                    onClick: () => setSubView('districtRank'),
                  },
                  {
                    icon: <Award className="w-4 h-4 text-emerald-600" />,
                    label: 'My Test Attempts',
                    right: `${user.attempts.length} ›`,
                    onClick: () => setSubView('results'),
                  },
                  {
                    icon: <Bookmark className="w-4 h-4 text-amber-600" />,
                    label: 'Saved / Bookmarked Questions',
                    right: `${user.bookmarks.length} ›`,
                    onClick: () => setSubView('bookmarks'),
                  },
                  {
                    icon: <FileText className="w-4 h-4 text-sky-600" />,
                    label: 'Exam Syllabus PDFs',
                    right: `${data.syllabi.length} PDFs ›`,
                    onClick: () => setSubView('syllabus'),
                  },
                  {
                    icon: <HelpCircle className="w-4 h-4 text-violet-600" />,
                    label: 'Help & Support',
                    right: '›',
                    onClick: () => setSubView('support'),
                  },
                ].map((row) => (
                  <button
                    key={row.label}
                    type="button"
                    onClick={row.onClick}
                    className="w-full flex items-center gap-3 px-5 py-4 text-left text-sm hover:bg-[#F8FAFC] dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                  >
                    {row.icon}
                    <span className="flex-1 font-medium text-slate-900 dark:text-white">
                      {row.label}
                    </span>
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 tabular-nums">
                      {row.right}
                    </span>
                  </button>
                ))}

                <a
                  href={waSupportHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center gap-3 px-5 py-4 text-left text-sm hover:bg-[#F8FAFC] dark:hover:bg-slate-800/60 transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-[#25D366]" />
                  <span className="flex-1 font-medium text-slate-900 dark:text-white">
                    WhatsApp Support
                  </span>
                  <span className="text-xs font-semibold text-slate-500">›</span>
                </a>

                <button
                  type="button"
                  onClick={() =>
                    setPendingProfile({
                      email: user.email,
                      name: user.name,
                      phone: user.phone,
                      district: user.district,
                      exam: user.exam,
                      isEdit: true,
                    })
                  }
                  className="w-full flex items-center gap-3 px-5 py-4 text-left text-sm hover:bg-[#F8FAFC] dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
                >
                  <Edit3 className="w-4 h-4 text-slate-500" />
                  <span className="flex-1 font-medium text-slate-900 dark:text-white">
                    Edit Profile
                  </span>
                  <span className="text-xs font-semibold text-slate-500">›</span>
                </button>

                <button
                  type="button"
                  onClick={onLogout}
                  className="w-full flex items-center gap-3 px-5 py-4 text-left text-sm text-rose-600 dark:text-rose-400 hover:bg-rose-50/50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="flex-1 font-semibold">Log out</span>
                </button>
              </div>

              <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.04)]">
                <SocialShareBar
                  settings={data.settings}
                  onToast={onToast}
                  title="Share ExamPro with Friends"
                />
              </div>
            </div>
          )}

          {/* ================= MY PAYMENTS (2-Column Cards) ================= */}
          {subView === 'payments' && (
            <div className="max-w-3xl space-y-5">
              <button
                type="button"
                onClick={() => setSubView('settings')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Settings
              </button>
              <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                My Payments
              </h1>

              {myPayments.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
                  No transactions yet.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {myPayments.map((p: PaymentOrder) => {
                    const statusColor =
                      p.status === 'PAID'
                        ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50'
                        : p.status === 'PENDING_VERIFICATION'
                        ? 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50'
                        : 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50';
                    return (
                      <div
                        key={p.id}
                        className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-[0_2px_12px_rgba(15,23,42,0.04)] flex flex-col justify-between gap-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                            {p.itemTitle}
                          </h3>
                          <span className="font-mono text-base font-extrabold text-slate-900 dark:text-white tabular-nums">
                            ₹{p.finalAmount}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                          <span>{p.createdAt}</span>
                          <span className={`rounded-md px-2 py-0.5 font-bold text-[11px] ${statusColor}`}>
                            {p.status === 'PENDING_VERIFICATION' ? 'Verification Pending' : p.status}
                          </span>
                        </div>
                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                          <span className="text-slate-500 font-mono">
                            {p.orderNumber} · {p.paymentMethod}
                          </span>
                          {p.status === 'PAID' && (
                            <button
                              type="button"
                              onClick={() => {
                                if (p.itemType === 'bundle') {
                                  const b = data.bundles.find((x) => x.id === p.itemId);
                                  if (b) setActiveBundle(b);
                                } else {
                                  const t = data.tests.find((x) => x.id === p.itemId);
                                  if (t) setActiveTestSession({ test: t, previewOnly: false });
                                }
                              }}
                              className="font-bold text-[#4F46E5] dark:text-indigo-400 hover:underline cursor-pointer"
                            >
                              {p.itemType === 'bundle' ? 'Open Course →' : 'Start →'}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ================= MISTAKE NOTEBOOK (Automated Re-Practice & Auto-Remove) ================= */}
          {subView === 'mistakes' && (
            <div className="max-w-3xl space-y-5">
              <button
                type="button"
                onClick={() => setSubView('assignments')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Assignments
              </button>
              <div>
                <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                  My Mistake Notebook ({user.mistakes.length})
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Wrong answers from your tests &amp; daily quizzes are saved automatically. Solve a question correctly below to master and remove it!
                </p>
              </div>

              {user.mistakes.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
                  No mistakes saved right now! Great job.
                </div>
              ) : (
                <div className="space-y-4">
                  {user.mistakes.map((m) => {
                    const picked = repracticeAnswers[m.id];
                    const answered = picked !== undefined;
                    return (
                      <div
                        key={m.id}
                        className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.04)] space-y-3"
                      >
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                          {m.subj} · {m.testTitle}
                        </div>
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white">{m.t}</h3>
                        <div className="space-y-2">
                          {m.o.map((opt, idx) => {
                            const isCorrect = idx === m.c;
                            const isPicked = picked === idx;
                            return (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => handleMistakeAnswer(m.id, idx, m.c)}
                                className={`w-full flex items-center gap-2.5 rounded-xl border p-3 text-left text-xs font-medium cursor-pointer transition-colors ${
                                  answered && isCorrect
                                    ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200'
                                    : answered && isPicked && !isCorrect
                                    ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200'
                                    : 'border-slate-200 dark:border-slate-800 hover:border-[#4F46E5]'
                                }`}
                              >
                                <span className="font-bold">{LABELS[idx]}.</span>
                                <span>{opt}</span>
                              </button>
                            );
                          })}
                        </div>
                        {answered && (
                          <div className="rounded-xl bg-[#F8FAFC] dark:bg-slate-800 p-3 text-xs text-slate-600 dark:text-slate-300">
                            <strong>Explanation:</strong> {m.e}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ================= DISTRICT RANK VIEW ================= */}
          {subView === 'districtRank' && (
            <div className="max-w-2xl space-y-5">
              <button
                type="button"
                onClick={() => setSubView('results')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Results
              </button>
              <div className="rounded-2xl bg-gradient-to-br from-[#4F46E5] to-slate-900 p-6 text-center text-white shadow-md">
                <div className="text-xs text-indigo-200">Your Rank in {user.district}</div>
                <div className="font-display text-4xl font-extrabold mt-1 tabular-nums">
                  {myDistrictRank ? `#${myDistrictRank}` : '—'}
                </div>
                {myDistrictRank === 1 && (
                  <button
                    type="button"
                    onClick={() => setShowTopperPoster(true)}
                    className="btn-press mt-4 inline-flex items-center gap-1.5 rounded-xl bg-amber-400 px-4 py-2 text-xs font-extrabold text-amber-950 cursor-pointer"
                  >
                    <Award className="w-4 h-4" />
                    <span>Share #1 District Topper Poster</span>
                  </button>
                )}
              </div>

              <div className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-[0_2px_12px_rgba(15,23,42,0.04)] divide-y divide-slate-100 dark:divide-slate-800">
                {myDistrictBoard.map((row, idx) => (
                  <div
                    key={row.userId}
                    className={`flex items-center justify-between px-5 py-3.5 text-sm ${
                      row.userId === user.id ? 'bg-indigo-50/70 dark:bg-indigo-950/30 font-bold' : ''
                    }`}
                  >
                    <span>
                      {['🥇', '🥈', '🥉'][idx] || `#${idx + 1}`} {row.name}
                      {row.userId === user.id ? ' (You)' : ''}
                    </span>
                    <span className="font-mono font-bold tabular-nums">{row.totalScore} pts</span>
                  </div>
                ))}
                {myDistrictBoard.length === 0 && (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No attempts recorded in {user.district} yet.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= BOOKMARKS ================= */}
          {subView === 'bookmarks' && (
            <div className="max-w-3xl space-y-5">
              <button
                type="button"
                onClick={() => setSubView('settings')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Settings
              </button>
              <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                Saved Questions ({user.bookmarks.length})
              </h1>
              {user.bookmarks.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
                  Tap the Bookmark icon during any test to save questions here.
                </div>
              ) : (
                <div className="space-y-4">
                  {user.bookmarks.map((b) => (
                    <div
                      key={b.id}
                      className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.04)] space-y-2"
                    >
                      <div className="text-xs text-slate-500">
                        {b.subj} · {b.testTitle}
                      </div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">{b.t}</h3>
                      <div className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                        ✔ Correct Answer: {LABELS[b.c]}. {b.o[b.c]}
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300">{b.e}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= EXAM SYLLABUS PDFs ================= */}
          {subView === 'syllabus' && (
            <div className="max-w-3xl space-y-5">
              <button
                type="button"
                onClick={() => setSubView('settings')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Settings
              </button>
              <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                Official Exam Syllabus PDFs
              </h1>
              <div className="space-y-3">
                {data.syllabi.map((s) => {
                  const matchesTarget = user.exam
                    .toLowerCase()
                    .includes(s.exam.split(' ')[0].toLowerCase());
                  return (
                    <div
                      key={s.id}
                      className={`rounded-2xl border p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-[0_2px_12px_rgba(15,23,42,0.04)] ${
                        matchesTarget
                          ? 'border-indigo-300 bg-indigo-50/50 dark:bg-indigo-950/30'
                          : 'border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-bold text-[#4F46E5] dark:text-indigo-400">
                          {s.exam} {matchesTarget ? '· Matches Your Target Exam' : ''}
                        </div>
                        <h3 className="font-display text-base font-bold text-slate-900 dark:text-white mt-0.5">
                          {s.title}
                        </h3>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{s.summary}</p>
                      </div>
                      <a
                        href={s.pdfUrl}
                        download={s.fileName}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-press shrink-0 rounded-xl bg-[#4F46E5] px-4 py-2.5 text-xs font-semibold text-white text-center whitespace-nowrap"
                      >
                        Download PDF
                      </a>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ================= HELP & SUPPORT ================= */}
          {subView === 'support' && (
            <div className="max-w-2xl space-y-6">
              <button
                type="button"
                onClick={() => setSubView('settings')}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Settings
              </button>
              <h1 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                Help &amp; Support
              </h1>

              <form
                onSubmit={handleSupportTicketSubmit}
                className="rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-[0_2px_12px_rgba(15,23,42,0.04)] space-y-4"
              >
                <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
                  Submit a Support Ticket
                </h2>
                <input
                  type="text"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  placeholder="Subject (e.g. Payment Verification / Test Issue)"
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 px-3.5 py-2.5 text-sm"
                />
                <input
                  type="text"
                  value={ticketOrderId}
                  onChange={(e) => setTicketOrderId(e.target.value)}
                  placeholder="Order ID (Optional, e.g. EXP-8499)"
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 px-3.5 py-2.5 text-sm font-mono"
                />
                <textarea
                  required
                  rows={3}
                  value={ticketMsg}
                  onChange={(e) => setTicketMsg(e.target.value)}
                  placeholder="Describe your issue..."
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800 p-3.5 text-sm"
                />
                <div className="flex flex-wrap gap-2">
                  <button
                    type="submit"
                    disabled={submittingTicket}
                    className="btn-press rounded-xl bg-[#4F46E5] px-5 py-2.5 text-xs font-semibold text-white cursor-pointer"
                  >
                    {submittingTicket ? 'Submitting...' : 'Submit Ticket'}
                  </button>
                  <a
                    href={waSupportHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-press inline-flex items-center gap-1.5 rounded-xl bg-[#25D366] px-4 py-2.5 text-xs font-semibold text-white"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp Support</span>
                  </a>
                </div>
              </form>

              <div className="space-y-3">
                <h3 className="font-display text-sm font-bold text-slate-700 dark:text-slate-300">
                  Your Previous Tickets
                </h3>
                {data.supportTickets
                  .filter((t) => t.userId === user.id)
                  .map((t) => (
                    <div
                      key={t.id}
                      className="rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex items-start justify-between gap-3"
                    >
                      <div>
                        <div className="text-sm font-bold text-slate-900 dark:text-white">{t.subject}</div>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{t.message}</p>
                        <div className="text-[11px] text-slate-400 mt-1">{t.createdAt}</div>
                      </div>
                      <span
                        className={`rounded-md px-2 py-0.5 text-[11px] font-bold uppercase ${
                          t.status === 'resolved'
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {t.status}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </main>

        {/* Global Website Footer */}
        {(subView === 'home' || subView === 'courses' || subView === 'settings' || subView === 'profile') && (
          <Footer
            settings={data.settings}
            onSelectCategoryFilter={handleFooterCategoryClick}
            onOpenPage={setInfoPage}
            onToast={onToast}
          />
        )}
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex h-16">
        {[
          { id: 'home', label: 'Home', icon: <LayoutDashboard className="w-5 h-5" /> },
          { id: 'courses', label: 'Courses', icon: <Package className="w-5 h-5" /> },
          { id: 'assignments', label: 'Tasks', icon: <ClipboardList className="w-5 h-5" /> },
          { id: 'results', label: 'Results', icon: <BarChart3 className="w-5 h-5" /> },
          { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" /> },
        ].map((item) => {
          const active = isNavActive(item.id as StudentSubView);
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => navigateSidebar(item.id as StudentSubView)}
              className={`flex-1 flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium cursor-pointer ${
                active
                  ? 'text-[#4F46E5] dark:text-indigo-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Modals */}
      {checkoutItem && (
        <CheckoutModal
          itemType={checkoutItem.type}
          itemId={checkoutItem.id}
          itemTitle={checkoutItem.title}
          price={checkoutItem.price}
          settings={data.settings}
          onClose={() => setCheckoutItem(null)}
          onToast={onToast}
          onSuccess={(order, updatedUser) => {
            setCheckoutItem(null);
            onUserUpdate(updatedUser as UserProfile);
            onRefreshData();
            onToast(
              order.status === 'PAID'
                ? 'Unlocked successfully!'
                : 'UTR submitted! Verification pending by Admin.'
            );
          }}
        />
      )}

      {showDailyQuiz && todayDailyQuiz && (
        <DailyQuizModal
          quiz={todayDailyQuiz}
          streak={user.dailyStreak || 0}
          onClose={() => setShowDailyQuiz(false)}
          onCompleted={(u) => {
            onUserUpdate(u);
            onRefreshData();
          }}
        />
      )}

      {showTopperPoster && (
        <TopperPosterModal
          studentName={user.name}
          district={user.district}
          testTitle="District Cumulative Leaderboard"
          score={myDistrictBoard[0]?.totalScore || 0}
          maxScore={myDistrictBoard[0]?.totalScore || 100}
          onClose={() => setShowTopperPoster(false)}
          onToast={onToast}
        />
      )}

      <InfoPagesModal
        page={infoPage}
        settings={data.settings}
        onClose={() => setInfoPage(null)}
        onOpenSupportTicket={() => setSubView('support')}
      />
    </div>
  );
};
