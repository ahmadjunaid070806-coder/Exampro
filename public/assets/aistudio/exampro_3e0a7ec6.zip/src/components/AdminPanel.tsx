import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Award,
  BarChart3,
  BookOpen,
  Calendar,
  Check,
  CheckCircle2,
  Copy,
  CreditCard,
  Download,
  Edit3,
  FileText,
  GraduationCap,
  Headphones,
  Link2,
  Menu,
  Package,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  Trophy,
  Upload,
  Users,
  X,
  XCircle,
} from 'lucide-react';
import type {
  AppBootstrapData,
  AppSettings,
  Coupon,
  MockTest,
  Question,
  TestBundle,
  UserProfile,
} from '../types';
import { DEFAULT_CATEGORIES, JK_DISTRICTS, getNextMonthEndRefreshDate } from '../types';
import { apiFetch } from '../lib/api';

type AdminTab =
  | 'dash'
  | 'tests'
  | 'results'
  | 'students'
  | 'exams'
  | 'bundles'
  | 'payments'
  | 'daily'
  | 'syllabus'
  | 'support'
  | 'settings';

interface Props {
  data: AppBootstrapData;
  user: UserProfile | null;
  onBackToStudent: () => void;
  onAdminAuthenticated: (adminUser: UserProfile) => void;
  onRefreshData: () => void;
  onToast: (msg: string) => void;
}

const LABELS = ['A', 'B', 'C', 'D'];

export const AdminPanel: React.FC<Props> = ({
  data,
  user,
  onBackToStudent,
  onAdminAuthenticated,
  onRefreshData,
  onToast,
}) => {
  const [tab, setTab] = useState<AdminTab>('dash');
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Admin Login Form if not logged in as admin yet
  const [loginId, setLoginId] = useState('');
  const [loginPw, setLoginPw] = useState('');
  const [loginErr, setLoginErr] = useState('');

  // Test Editor state
  const [editingTest, setEditingTest] = useState<MockTest | null>(null);
  const [isNewTest, setIsNewTest] = useState(false);
  const [newSubjectInput, setNewSubjectInput] = useState('');
  const [builderPanel, setBuilderPanel] = useState<'manual' | 'ai' | 'bulk' | null>(null);
  const [qForm, setQForm] = useState<{
    t: string;
    o: [string, string, string, string];
    c: number;
    e: string;
    subj: string;
    examRefText: string;
    editIdx: number | null;
    aiReviewIdx: number | null;
  }>({
    t: '',
    o: ['', '', '', ''],
    c: 0,
    e: '',
    subj: data.subjects[0] || 'J&K General Knowledge',
    examRefText: '',
    editIdx: null,
    aiReviewIdx: null,
  });

  // AI PDF Extraction state (up to 120 questions)
  const [aiFileName, setAiFileName] = useState('');
  const [aiPdfBase64, setAiPdfBase64] = useState('');
  const [aiUseSample, setAiUseSample] = useState(false);
  const [aiCount, setAiCount] = useState(10);
  const [aiBusy, setAiBusy] = useState(false);
  const [aiErr, setAiErr] = useState('');
  const [aiQueue, setAiQueue] = useState<Array<Question & { reviewState?: 'pending' | 'approved' | 'rejected' }>>([]);

  // Bulk CSV / JSON state
  const [bulkMode, setBulkMode] = useState<'csv' | 'json'>('csv');
  const [bulkText, setBulkText] = useState('');
  const [bulkMsg, setBulkMsg] = useState('');

  // Results & District Toppers Modal
  const [selectedResultTestId, setSelectedResultTestId] = useState<number>(data.tests[0]?.id || 1);
  const [showToppersExport, setShowToppersExport] = useState(false);

  // Exams & Subjects add inputs
  const [newExamName, setNewExamName] = useState('');

  // Bundles Manager state
  const [bundleDraft, setBundleDraft] = useState<Partial<TestBundle> | null>(null);

  // Payments & Coupons state
  const [paySubTab, setPaySubTab] = useState<'tx' | 'coupons'>('tx');
  const [txSearch, setTxSearch] = useState('');
  const [previewScreenshot, setPreviewScreenshot] = useState<string | null>(null);
  const [upiDraft, setUpiDraft] = useState(data.settings.upi);
  const [newCoupon, setNewCoupon] = useState<{
    code: string;
    type: 'percent' | 'flat' | 'free';
    value: number;
    maxUses: number;
    expiryDate: string;
  }>({ code: '', type: 'percent', value: 25, maxUses: 100, expiryDate: '2026-12-31' });
  const [manualUnlock, setManualUnlock] = useState({ userId: 0, itemType: 'test' as 'test' | 'bundle', itemId: 0 });

  // Daily Quiz & Updates state
  const [dqDate, setDqDate] = useState(new Date().toISOString().slice(0, 10));
  const [dqTitle, setDqTitle] = useState('Daily 10-Question J&K Current Affairs');
  const [dqBulkJson, setDqBulkJson] = useState('');
  const [updForm, setUpdForm] = useState({
    type: 'alert' as 'alert' | 'exam_date' | 'admit_card' | 'result',
    title: '',
    exam: data.exams[0] || 'JKSSB Junior Assistant',
    message: '',
    examDate: '',
  });

  // Syllabus state
  const [sylForm, setSylForm] = useState({
    exam: data.exams[0] || 'JKSSB Junior Assistant',
    title: '',
    summary: '',
    fileName: '',
    pdfUrl: '',
  });

  // Support & Reports tab
  const [supTab, setSupTab] = useState<'tickets' | 'reports'>('tickets');

  // Sharing & Settings draft
  const [settingsDraft, setSettingsDraft] = useState<AppSettings>(data.settings);

  const pendingPayments = useMemo(
    () => data.payments.filter((p) => p.status === 'PENDING_VERIFICATION'),
    [data.payments]
  );
  const pendingTicketsCount = useMemo(
    () => data.supportTickets.filter((t) => t.status === 'pending').length,
    [data.supportTickets]
  );
  const pendingReportsCount = useMemo(
    () => data.reportedQuestions.filter((r) => r.status === 'pending').length,
    [data.reportedQuestions]
  );
  const totalPendingSupport = pendingTicketsCount + pendingReportsCount;

  // Auto-calculated District Toppers across all results
  const districtToppersList = useMemo(() => {
    const map = new Map<
      string,
      { district: string; name: string; score: number; maxScore: number; targetExam: string }
    >();
    data.results.forEach((r) => {
      const prev = map.get(r.district);
      if (!prev || r.score > prev.score) {
        map.set(r.district, {
          district: r.district,
          name: r.name,
          score: r.score,
          maxScore: r.maxScore,
          targetExam: r.targetExam,
        });
      }
    });
    return JK_DISTRICTS.map((d) => map.get(d)).filter(Boolean) as Array<{
      district: string;
      name: string;
      score: number;
      maxScore: number;
      targetExam: string;
    }>;
  }, [data.results]);

  // If not logged in as admin, render Dark Admin Login
  if (!user || user.role !== 'admin') {
    const handleAdminLogin = async (e: React.FormEvent) => {
      e.preventDefault();
      setLoginErr('');
      try {
        const res = await apiFetch<{ user: UserProfile }>('/api/auth/admin-login', {
          method: 'POST',
          body: JSON.stringify({ identifier: loginId, password: loginPw }),
        });
        onAdminAuthenticated(res.user);
      } catch (err: unknown) {
        setLoginErr(err instanceof Error ? err.message : 'Invalid admin credentials.');
      }
    };

    return (
      <div className="min-h-screen bg-[#121218] text-[#ecebf4] flex items-center justify-center p-4">
        <div className="w-full max-w-sm rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-6 shadow-2xl">
          <div className="text-center mb-5">
            <div className="text-4xl mb-2">🛡️</div>
            <h1 className="font-display text-xl font-extrabold">ExamPro Admin</h1>
            <p className="text-xs text-[#a09eb5] mt-1">
              Sign in with Admin Email or Mobile
            </p>
          </div>
          <form onSubmit={handleAdminLogin} className="space-y-3">
            <div>
              <label className="block text-xs text-[#a09eb5] mb-1">Admin Email or Mobile</label>
              <input
                type="text"
                required
                value={loginId}
                onChange={(e) => setLoginId(e.target.value)}
                placeholder="JUMEE89@GMAIL.COM or 9906101048"
                className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#a8a4ff]"
              />
            </div>
            <div>
              <label className="block text-xs text-[#a09eb5] mb-1">Password</label>
              <input
                type="password"
                required
                value={loginPw}
                onChange={(e) => setLoginPw(e.target.value)}
                placeholder="Enter password (default: 12345)"
                className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#a8a4ff]"
              />
            </div>
            {loginErr && <p className="text-xs text-rose-400 font-semibold">{loginErr}</p>}
            <button
              type="submit"
              className="btn-press w-full rounded-xl bg-[#4f46e5] py-3 text-sm font-bold text-white hover:bg-[#4338ca] cursor-pointer"
            >
              Login to Admin Console
            </button>
          </form>
          <button
            type="button"
            onClick={onBackToStudent}
            className="mt-3 w-full rounded-xl border border-[#3a3848] py-2.5 text-xs font-semibold text-[#a09eb5] hover:text-white cursor-pointer"
          >
            ← Back to Student Portal
          </button>
        </div>
      </div>
    );
  }

  // Helpers for Test Editor & Duplicate Check
  const normalizeQ = (text: string) => text.trim().toLowerCase().replace(/\s+/g, ' ');
  const isDuplicateQuestion = (text: string, ignoreIdx: number | null = null) => {
    if (!editingTest) return false;
    const norm = normalizeQ(text);
    return editingTest.qs.some((q, idx) => idx !== ignoreIdx && normalizeQ(q.t) === norm);
  };

  const openNewTest = () => {
    setIsNewTest(true);
    setEditingTest({
      id: 0,
      cat: 'latest',
      exam: data.exams[0] || 'JKSSB Junior Assistant',
      title: '',
      testType: 'full',
      subject: data.subjects[0],
      paid: true,
      price: 99,
      dur: 60,
      neg: 0.25,
      sched: new Date().toISOString().slice(0, 16),
      status: 'draft',
      desc: '',
      syllabusTag: 'J&K GK · English · Reasoning',
      language: 'English',
      attemptCount: 0,
      bundleId: null,
      qs: [],
    });
    setBuilderPanel(null);
    setAiQueue([]);
    setTab('tests');
  };

  const openEditTest = (t: MockTest) => {
    setIsNewTest(false);
    setEditingTest(JSON.parse(JSON.stringify(t)));
    setBuilderPanel(null);
    setAiQueue([]);
    setTab('tests');
  };

  const handleSaveManualQuestion = () => {
    if (!editingTest) return;
    if (!qForm.t.trim() || qForm.o.some((x) => !x.trim()) || !qForm.e.trim()) {
      onToast('Fill question, all 4 options, and explanation.');
      return;
    }
    const examRef = qForm.examRefText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 3);

    const newQ: Question = {
      id: `q-${Date.now()}`,
      t: qForm.t.trim(),
      o: [qForm.o[0].trim(), qForm.o[1].trim(), qForm.o[2].trim(), qForm.o[3].trim()],
      c: qForm.c,
      e: qForm.e.trim(),
      subj: qForm.subj,
      src: 'manual',
      examRef,
    };

    if (qForm.aiReviewIdx !== null) {
      const nextQueue = [...aiQueue];
      nextQueue[qForm.aiReviewIdx] = { ...newQ, src: 'ai', reviewState: 'pending' };
      setAiQueue(nextQueue);
      setBuilderPanel('ai');
      setQForm({ ...qForm, t: '', o: ['', '', '', ''], e: '', examRefText: '', aiReviewIdx: null });
      return;
    }

    if (isDuplicateQuestion(newQ.t, qForm.editIdx)) {
      onToast('⚠️ Duplicate question detected! This question already exists in the test.');
      return;
    }

    const updatedQs = [...editingTest.qs];
    if (qForm.editIdx !== null) {
      updatedQs[qForm.editIdx] = { ...updatedQs[qForm.editIdx], ...newQ, id: updatedQs[qForm.editIdx].id };
      setBuilderPanel(null);
      onToast('Question updated!');
    } else {
      updatedQs.push(newQ);
      onToast(`Question #${updatedQs.length} added!`);
    }
    setEditingTest({ ...editingTest, qs: updatedQs });
    setQForm({
      t: '',
      o: ['', '', '', ''],
      c: 0,
      e: '',
      subj: qForm.subj,
      examRefText: '',
      editIdx: null,
      aiReviewIdx: null,
    });
  };

  const handleAiExtract = async () => {
    setAiErr('');
    setAiBusy(true);
    try {
      const res = await apiFetch<{ questions: Question[] }>('/api/admin/ai-extract-pdf', {
        method: 'POST',
        body: JSON.stringify({
          count: aiCount,
          pdfBase64: aiPdfBase64,
          useSample: aiUseSample,
        }),
      });
      setAiQueue(res.questions.map((q) => ({ ...q, reviewState: 'pending' })));
    } catch (err: unknown) {
      setAiErr(err instanceof Error ? err.message : 'AI extraction failed.');
    } finally {
      setAiBusy(false);
    }
  };

  const approveAiItem = (idx: number) => {
    if (!editingTest) return;
    const item = aiQueue[idx];
    if (isDuplicateQuestion(item.t)) {
      onToast('Skipped duplicate question already in test.');
      const next = [...aiQueue];
      next[idx].reviewState = 'rejected';
      setAiQueue(next);
      return;
    }
    const { reviewState: _rs, ...cleanQ } = item;
    setEditingTest({ ...editingTest, qs: [...editingTest.qs, cleanQ] });
    const next = [...aiQueue];
    next[idx].reviewState = 'approved';
    setAiQueue(next);
  };

  const approveAllPendingAi = () => {
    if (!editingTest) return;
    const added: Question[] = [];
    const existingSet = new Set(editingTest.qs.map((q) => normalizeQ(q.t)));
    const nextQueue = aiQueue.map((item) => {
      if (item.reviewState !== 'pending') return item;
      const norm = normalizeQ(item.t);
      if (existingSet.has(norm)) {
        return { ...item, reviewState: 'rejected' as const };
      }
      existingSet.add(norm);
      const { reviewState: _rs, ...cleanQ } = item;
      added.push(cleanQ);
      return { ...item, reviewState: 'approved' as const };
    });
    setAiQueue(nextQueue);
    setEditingTest({ ...editingTest, qs: [...editingTest.qs, ...added] });
    onToast(`Approved ${added.length} unique questions!`);
  };

  const downloadSampleCsv = () => {
    const csv = [
      'question,optionA,optionB,optionC,optionD,correctIndex,explanation,subject,examRef',
      '"Which river flows through Srinagar?","Chenab","Jhelum","Ravi","Indus",1,"The Jhelum flows through Srinagar and Wular Lake.","J&K General Knowledge","JKSSB 2024, JKP 2025"',
      '"Who wrote Rajatarangini?","Kalhana","Bilhana","Banabhatta","Panini",0,"Kalhana composed Rajatarangini in 12th century CE.","History","JKPSC 2023"',
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ExamPro_Sample_Questions.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const parseCsvLine = (line: string): string[] => {
    const out: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') inQuotes = !inQuotes;
      else if (ch === ',' && !inQuotes) {
        out.push(cur.trim());
        cur = '';
      } else cur += ch;
    }
    out.push(cur.trim());
    return out;
  };

  const handleBulkImport = () => {
    if (!editingTest || !bulkText.trim()) return;
    setBulkMsg('');
    const existingSet = new Set(editingTest.qs.map((q) => normalizeQ(q.t)));
    const imported: Question[] = [];
    let dupes = 0;

    try {
      if (bulkMode === 'json') {
        const arr = JSON.parse(bulkText) as Array<Record<string, unknown>>;
        arr.forEach((item, i) => {
          const text = String(item.t || item.question || '').trim();
          const norm = normalizeQ(text);
          if (!norm || existingSet.has(norm)) {
            if (norm) dupes++;
            return;
          }
          existingSet.add(norm);
          const opts = Array.isArray(item.o)
            ? item.o.map(String)
            : [
                String(item.optionA || 'Option A'),
                String(item.optionB || 'Option B'),
                String(item.optionC || 'Option C'),
                String(item.optionD || 'Option D'),
              ];
          const rawRef = item.examRef;
          const examRef = Array.isArray(rawRef)
            ? rawRef.map(String).slice(0, 3)
            : typeof rawRef === 'string'
            ? rawRef
                .split(',')
                .map((s) => s.trim())
                .filter(Boolean)
                .slice(0, 3)
            : [];
          imported.push({
            id: `json-${Date.now()}-${i}`,
            t: text,
            o: [opts[0] || '', opts[1] || '', opts[2] || '', opts[3] || ''],
            c: Math.max(0, Math.min(3, Number(item.c ?? item.correctIndex ?? 0))),
            e: String(item.e || item.explanation || 'Verified answer.'),
            subj: String(item.subj || item.subject || data.subjects[0]),
            src: 'json',
            examRef,
          });
        });
      } else {
        const lines = bulkText.trim().split(/\r?\n/);
        lines.forEach((line, idx) => {
          if (idx === 0 && line.toLowerCase().includes('question')) return;
          const cols = parseCsvLine(line);
          if (cols.length < 6) return;
          const text = cols[0];
          const norm = normalizeQ(text);
          if (!norm || existingSet.has(norm)) {
            if (norm) dupes++;
            return;
          }
          existingSet.add(norm);
          const examRef = (cols[8] || '')
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
            .slice(0, 3);
          imported.push({
            id: `csv-${Date.now()}-${idx}`,
            t: text,
            o: [cols[1] || '', cols[2] || '', cols[3] || '', cols[4] || ''],
            c: Math.max(0, Math.min(3, Number(cols[5] || 0))),
            e: cols[6] || 'Verified answer.',
            subj: cols[7] || data.subjects[0],
            src: 'csv',
            examRef,
          });
        });
      }

      setEditingTest({ ...editingTest, qs: [...editingTest.qs, ...imported] });
      setBulkMsg(`Imported ${imported.length} questions (${dupes} duplicates skipped).`);
      if (imported.length > 0) setBulkText('');
    } catch {
      setBulkMsg('Invalid format. Check CSV columns or JSON syntax.');
    }
  };

  const handleSaveTestToServer = async () => {
    if (!editingTest) return;
    if (!editingTest.title.trim()) {
      onToast('Enter a test title.');
      return;
    }
    if (editingTest.status !== 'draft' && editingTest.qs.length === 0) {
      onToast('Add at least 1 question or save as Draft.');
      return;
    }
    try {
      if (isNewTest) {
        await apiFetch('/api/admin/tests', {
          method: 'POST',
          body: JSON.stringify(editingTest),
        });
        onToast('Mock test created!');
      } else {
        await apiFetch(`/api/admin/tests/${editingTest.id}`, {
          method: 'PUT',
          body: JSON.stringify(editingTest),
        });
        onToast('Mock test updated!');
      }
      setEditingTest(null);
      onRefreshData();
    } catch (err: unknown) {
      onToast(err instanceof Error ? err.message : 'Save failed.');
    }
  };

  const sidebarItems: Array<{ id: AdminTab; label: string; icon: React.ReactNode; badge?: number }> = [
    { id: 'dash', label: 'Dashboard', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'tests', label: 'Mock Tests', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'results', label: 'Results', icon: <Trophy className="w-4 h-4" /> },
    { id: 'students', label: 'Students', icon: <Users className="w-4 h-4" /> },
    { id: 'exams', label: 'Exams', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'bundles', label: 'Test Bundles', icon: <Package className="w-4 h-4" /> },
    { id: 'payments', label: 'Payments & Coupons', icon: <CreditCard className="w-4 h-4" />, badge: pendingPayments.length || undefined },
    { id: 'daily', label: 'Daily Quiz & Updates', icon: <Calendar className="w-4 h-4" /> },
    { id: 'syllabus', label: 'Syllabus', icon: <FileText className="w-4 h-4" /> },
    { id: 'support', label: 'Support & Reports', icon: <Headphones className="w-4 h-4" />, badge: totalPendingSupport || undefined },
    { id: 'settings', label: 'Sharing & Settings', icon: <Link2 className="w-4 h-4" /> },
  ];

  const totalRevenue = data.payments
    .filter((p) => p.status === 'PAID')
    .reduce((acc, p) => acc + p.finalAmount, 0);

  return (
    <div className="min-h-screen bg-[#121218] text-[#ecebf4] flex">
      {/* Left Sidebar (Desktop fixed, Mobile collapsible drawer) */}
      {drawerOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 lg:hidden"
          onClick={() => setDrawerOpen(false)}
        />
      )}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-50 h-screen w-64 shrink-0 border-r border-[#2e2d3a] bg-[#1b1a22] flex flex-col transition-transform duration-200 ${
          drawerOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="px-5 py-4 border-b border-[#2e2d3a] flex items-center justify-between">
          <div className="font-display text-lg font-extrabold tracking-tight text-white">
            🎓 ExamPro <span className="text-xs font-medium text-[#a09eb5]">Admin</span>
          </div>
          <button
            type="button"
            onClick={() => setDrawerOpen(false)}
            className="lg:hidden text-[#a09eb5]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {sidebarItems.map((item) => {
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setTab(item.id);
                  setEditingTest(null);
                  setDrawerOpen(false);
                }}
                className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-left text-xs font-semibold transition-all duration-150 cursor-pointer ${
                  active
                    ? 'bg-[#35327a] text-white shadow-xs'
                    : 'text-[#a09eb5] hover:bg-[#25242f] hover:text-white'
                }`}
              >
                {item.icon}
                <span className="flex-1 truncate">{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="rounded-full bg-rose-600 px-2 py-0.5 text-[10px] font-extrabold text-white tabular-nums">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-[#2e2d3a]">
          <button
            type="button"
            onClick={onBackToStudent}
            className="btn-press w-full rounded-xl border border-[#3a3848] bg-[#25242f] py-2.5 text-xs font-semibold text-white hover:bg-[#2e2d3a] cursor-pointer"
          >
            📱 Open Student Portal
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 h-14 border-b border-[#2e2d3a] bg-[#1b1a22]/95 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              className="lg:hidden rounded-lg p-1.5 text-[#a09eb5] hover:text-white cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display text-base font-bold text-white">
              {editingTest
                ? isNewTest
                  ? 'New Mock Test'
                  : `Edit: ${editingTest.title}`
                : sidebarItems.find((i) => i.id === tab)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={openNewTest}
              className="btn-press inline-flex items-center gap-1.5 rounded-xl bg-[#4f46e5] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#4338ca] cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Mock Test</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto space-y-6">
          {/* ALERT BANNER FOR PENDING UPI / SUPPORT */}
          {(pendingPayments.length > 0 || totalPendingSupport > 0) && tab === 'dash' && (
            <div className="rounded-2xl border border-amber-500/40 bg-amber-950/30 p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                <div className="text-xs sm:text-sm">
                  <strong className="text-amber-300">Action Needed:</strong>{' '}
                  {pendingPayments.length > 0 && (
                    <span>{pendingPayments.length} UPI payment(s) awaiting UTR verification. </span>
                  )}
                  {totalPendingSupport > 0 && (
                    <span>{totalPendingSupport} support ticket(s) / reported question(s) pending.</span>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                {pendingPayments.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setTab('payments');
                      setPaySubTab('tx');
                    }}
                    className="btn-press rounded-xl bg-amber-400 px-3 py-1.5 text-xs font-bold text-amber-950 cursor-pointer"
                  >
                    Verify UPI Orders
                  </button>
                )}
                {totalPendingSupport > 0 && (
                  <button
                    type="button"
                    onClick={() => setTab('support')}
                    className="btn-press rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-bold text-white cursor-pointer"
                  >
                    Open Support &amp; Reports
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ================= TAB: DASHBOARD ================= */}
          {tab === 'dash' && !editingTest && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Website Visitors', value: data.traffic.totalVisitors, icon: '🌐' },
                  { label: "Today's Active Students", value: data.traffic.todayActiveStudents, icon: '⚡' },
                  { label: 'Total Students', value: data.students?.length || 0, icon: '🎓' },
                  { label: 'Total Revenue', value: `₹${totalRevenue}`, icon: '💰' },
                  { label: 'Total Mock Tests', value: data.tests.length, icon: '📝' },
                  { label: 'Test Bundles', value: data.bundles.length, icon: '📦' },
                  { label: 'Pending UPI Orders', value: pendingPayments.length, icon: '⏳' },
                  { label: 'Total Test Attempts', value: data.results.length, icon: '🧪' },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="card-hover rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-5"
                  >
                    <div className="text-xl mb-2">{stat.icon}</div>
                    <div className="font-mono text-2xl font-extrabold text-white tabular-nums">
                      {stat.value}
                    </div>
                    <div className="text-xs text-[#a09eb5] mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-3">
                  <h3 className="font-display text-sm font-bold text-white">
                    🏆 Toppers Snapshot
                  </h3>
                  {data.results
                    .slice()
                    .sort((a, b) => b.score - a.score)
                    .slice(0, 5)
                    .map((r, i) => (
                      <div
                        key={r.id}
                        className="flex items-center justify-between py-2 border-b border-[#2e2d3a] last:border-0 text-xs"
                      >
                        <span>
                          {['🥇', '🥈', '🥉'][i] || `#${i + 1}`} <strong>{r.name}</strong> ({r.district})
                        </span>
                        <span className="font-mono font-bold text-[#a8a4ff] tabular-nums">
                          {r.score}/{r.maxScore}
                        </span>
                      </div>
                    ))}
                </div>

                <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-3">
                  <h3 className="font-display text-sm font-bold text-white">
                    ⚡ Quick Admin Actions
                  </h3>
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={openNewTest}
                      className="btn-press rounded-xl bg-[#4f46e5] py-3 px-3 text-xs font-bold text-white cursor-pointer"
                    >
                      ➕ Add New Mock Test
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('bundles')}
                      className="btn-press rounded-xl bg-[#25242f] border border-[#3a3848] py-3 px-3 text-xs font-bold text-white cursor-pointer"
                    >
                      📦 Manage Bundles
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('payments')}
                      className="btn-press rounded-xl bg-[#25242f] border border-[#3a3848] py-3 px-3 text-xs font-bold text-white cursor-pointer"
                    >
                      💳 Approve UPI Orders
                    </button>
                    <button
                      type="button"
                      onClick={() => setTab('daily')}
                      className="btn-press rounded-xl bg-[#25242f] border border-[#3a3848] py-3 px-3 text-xs font-bold text-white cursor-pointer"
                    >
                      📅 Post Daily Quiz / Alert
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= TAB: MOCK TESTS + TEST EDITOR ================= */}
          {tab === 'tests' && editingTest && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-xs text-[#a09eb5] mb-1">Test Title *</label>
                    <input
                      value={editingTest.title}
                      onChange={(e) => setEditingTest({ ...editingTest, title: e.target.value })}
                      placeholder="e.g. JKSSB Junior Assistant Full Mock 02"
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Exam</label>
                    <select
                      value={editingTest.exam}
                      onChange={(e) => setEditingTest({ ...editingTest, exam: e.target.value })}
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                    >
                      {data.exams.map((ex) => (
                        <option key={ex} value={ex}>
                          {ex}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Home Section Category</label>
                    <select
                      value={editingTest.cat}
                      onChange={(e) => {
                        const c = e.target.value;
                        setEditingTest({
                          ...editingTest,
                          cat: c,
                          paid: c === 'free' ? false : editingTest.paid,
                          price: c === 'free' ? 0 : editingTest.price,
                        });
                      }}
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                    >
                      {DEFAULT_CATEGORIES.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.icon} {c.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Test Type</label>
                    <select
                      value={editingTest.testType}
                      onChange={(e) =>
                        setEditingTest({
                          ...editingTest,
                          testType: e.target.value as 'full' | 'sectional',
                        })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                    >
                      <option value="full">Full-Length Mock</option>
                      <option value="sectional">Sectional / Subject Test</option>
                    </select>
                  </div>

                  {editingTest.testType === 'sectional' && (
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Sectional Subject</label>
                      <div className="flex gap-2">
                        <select
                          value={editingTest.subject || data.subjects[0]}
                          onChange={(e) => setEditingTest({ ...editingTest, subject: e.target.value })}
                          className="flex-1 rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                        >
                          {data.subjects.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                        <input
                          value={newSubjectInput}
                          onChange={(e) => setNewSubjectInput(e.target.value)}
                          placeholder="+ New Subject"
                          className="w-32 rounded-xl border border-[#3a3848] bg-[#25242f] px-2.5 py-2 text-xs text-white"
                        />
                        <button
                          type="button"
                          onClick={async () => {
                            if (!newSubjectInput.trim()) return;
                            await apiFetch('/api/admin/subjects', {
                              method: 'POST',
                              body: JSON.stringify({ name: newSubjectInput.trim() }),
                            });
                            setEditingTest({ ...editingTest, subject: newSubjectInput.trim() });
                            setNewSubjectInput('');
                            onRefreshData();
                          }}
                          className="rounded-xl bg-[#4f46e5] px-3 text-xs font-bold text-white cursor-pointer"
                        >
                          Add
                        </button>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Bundle (Optional)</label>
                    <select
                      value={editingTest.bundleId || ''}
                      onChange={(e) =>
                        setEditingTest({
                          ...editingTest,
                          bundleId: e.target.value ? Number(e.target.value) : null,
                        })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                    >
                      <option value="">None (Standalone Test)</option>
                      {data.bundles.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Syllabus / Topics Tag</label>
                    <input
                      value={editingTest.syllabusTag}
                      onChange={(e) => setEditingTest({ ...editingTest, syllabusTag: e.target.value })}
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Duration (m)</label>
                      <input
                        type="number"
                        value={editingTest.dur}
                        onChange={(e) => setEditingTest({ ...editingTest, dur: Number(e.target.value) })}
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2.5 text-sm text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Neg Mark</label>
                      <input
                        type="number"
                        step="0.01"
                        value={editingTest.neg}
                        onChange={(e) => setEditingTest({ ...editingTest, neg: Number(e.target.value) })}
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2.5 text-sm text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Attempts</label>
                      <input
                        type="number"
                        value={editingTest.attemptCount}
                        onChange={(e) =>
                          setEditingTest({ ...editingTest, attemptCount: Number(e.target.value) })
                        }
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2.5 text-sm text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Pricing &amp; Status</label>
                    <div className="flex gap-2">
                      <select
                        value={editingTest.paid ? 'paid' : 'free'}
                        onChange={(e) =>
                          setEditingTest({
                            ...editingTest,
                            paid: e.target.value === 'paid',
                            price: e.target.value === 'paid' ? editingTest.price || 99 : 0,
                          })
                        }
                        className="rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2.5 text-sm text-white"
                      >
                        <option value="free">Free</option>
                        <option value="paid">Paid</option>
                      </select>
                      {editingTest.paid && (
                        <input
                          type="number"
                          value={editingTest.price}
                          onChange={(e) =>
                            setEditingTest({ ...editingTest, price: Number(e.target.value) })
                          }
                          placeholder="₹ Price"
                          className="w-24 rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2.5 text-sm text-white"
                        />
                      )}
                      <select
                        value={editingTest.status}
                        onChange={(e) =>
                          setEditingTest({
                            ...editingTest,
                            status: e.target.value as 'live' | 'scheduled' | 'draft',
                          })
                        }
                        className="flex-1 rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2.5 text-sm text-white"
                      >
                        <option value="live">Live</option>
                        <option value="scheduled">Scheduled</option>
                        <option value="draft">Draft</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Question Builder Toolbar */}
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h3 className="font-display text-base font-bold text-white">
                    ❓ Questions ({editingTest.qs.length})
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => setBuilderPanel('ai')}
                      className="btn-press inline-flex items-center gap-1.5 rounded-xl bg-[#4f46e5] px-3.5 py-2 text-xs font-bold text-white cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>📄 Upload PDF &amp; Generate with AI</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setBuilderPanel('bulk')}
                      className="btn-press inline-flex items-center gap-1.5 rounded-xl bg-[#25242f] border border-[#3a3848] px-3.5 py-2 text-xs font-bold text-white cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>📤 Bulk Import (CSV / JSON)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setQForm({
                          t: '',
                          o: ['', '', '', ''],
                          c: 0,
                          e: '',
                          subj: data.subjects[0],
                          examRefText: '',
                          editIdx: null,
                          aiReviewIdx: null,
                        });
                        setBuilderPanel('manual');
                      }}
                      className="btn-press inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>✍️ Add Question Manually</span>
                    </button>
                  </div>
                </div>

                {/* AI PDF Extractor Panel (up to 120 questions + ExamRef detection) */}
                {builderPanel === 'ai' && (
                  <div className="rounded-2xl border border-[#3a3848] bg-[#25242f] p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-display text-sm font-bold text-white">
                        AI PDF Extractor (Gemini · Up to 120 Questions)
                      </h4>
                      <button
                        type="button"
                        onClick={() => setBuilderPanel(null)}
                        className="text-xs text-[#a09eb5]"
                      >
                        Close
                      </button>
                    </div>
                    <p className="text-xs text-[#a09eb5]">
                      Automatically extracts MCQs with 4 options, explanations, and detects previous exam tags (e.g. [JKSSB 2024], max 3 tags). Nothing is added until you approve.
                    </p>
                    <div className="flex flex-wrap items-center gap-3">
                      <input
                        type="file"
                        accept="application/pdf"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          setAiFileName(file.name);
                          setAiUseSample(false);
                          const reader = new FileReader();
                          reader.onload = () => {
                            if (typeof reader.result === 'string') setAiPdfBase64(reader.result);
                          };
                          reader.readAsDataURL(file);
                        }}
                        className="text-xs text-[#a09eb5]"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setAiFileName('JKSSB_JK_GK_Sample.pdf');
                          setAiUseSample(true);
                          setAiPdfBase64('');
                        }}
                        className="rounded-xl border border-[#3a3848] px-3 py-1.5 text-xs font-semibold text-white cursor-pointer"
                      >
                        Use Sample J&amp;K PDF
                      </button>
                    </div>

                    {aiFileName && (
                      <div className="space-y-3">
                        <div className="text-xs text-emerald-400">Selected: {aiFileName}</div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs text-[#a09eb5]">Number of Questions:</span>
                          {[10, 25, 50, 100, 120].map((n) => (
                            <button
                              key={n}
                              type="button"
                              onClick={() => setAiCount(n)}
                              className={`rounded-lg px-3 py-1.5 text-xs font-bold cursor-pointer ${
                                aiCount === n
                                  ? 'bg-[#4f46e5] text-white'
                                  : 'bg-[#1b1a22] text-[#a09eb5] border border-[#3a3848]'
                              }`}
                            >
                              {n}
                            </button>
                          ))}
                        </div>
                        <button
                          type="button"
                          disabled={aiBusy}
                          onClick={handleAiExtract}
                          className="btn-press rounded-xl bg-[#4f46e5] px-5 py-2.5 text-xs font-bold text-white cursor-pointer disabled:opacity-50"
                        >
                          {aiBusy
                            ? `⏳ Extracting ${aiCount} questions with Gemini AI...`
                            : `✨ Generate ${aiCount} Questions`}
                        </button>
                      </div>
                    )}

                    {aiErr && <div className="text-xs text-rose-400 font-semibold">{aiErr}</div>}

                    {aiQueue.length > 0 && (
                      <div className="space-y-3 pt-3 border-t border-[#3a3848]">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">
                            Review Queue ({aiQueue.filter((x) => x.reviewState === 'pending').length} pending)
                          </span>
                          <button
                            type="button"
                            onClick={approveAllPendingAi}
                            className="btn-press rounded-xl bg-emerald-600 px-3.5 py-1.5 text-xs font-bold text-white cursor-pointer"
                          >
                            Approve All Pending
                          </button>
                        </div>
                        <div className="max-h-96 overflow-y-auto space-y-2.5">
                          {aiQueue.map((item, idx) => (
                            <div
                              key={item.id}
                              className="rounded-xl border border-[#3a3848] bg-[#1b1a22] p-3.5 space-y-2 text-xs"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <strong className="text-white">
                                  {idx + 1}. {item.t}
                                </strong>
                                <span className="uppercase text-[10px] font-bold text-[#a8a4ff]">
                                  {item.reviewState}
                                </span>
                              </div>
                              {item.examRef && item.examRef.length > 0 && (
                                <div className="text-[11px] text-amber-300">
                                  📌 Asked in: {item.examRef.join(' • ')}
                                </div>
                              )}
                              <div className="text-emerald-400">
                                ✔ {LABELS[item.c]}. {item.o[item.c]}
                              </div>
                              {item.reviewState === 'pending' && (
                                <div className="flex gap-2">
                                  <button
                                    type="button"
                                    onClick={() => approveAiItem(idx)}
                                    className="rounded-lg bg-emerald-600 px-3 py-1 text-white font-bold cursor-pointer"
                                  >
                                    Approve
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setQForm({
                                        t: item.t,
                                        o: [...item.o],
                                        c: item.c,
                                        e: item.e,
                                        subj: item.subj,
                                        examRefText: (item.examRef || []).join(', '),
                                        editIdx: null,
                                        aiReviewIdx: idx,
                                      });
                                      setBuilderPanel('manual');
                                    }}
                                    className="rounded-lg bg-[#25242f] border border-[#3a3848] px-3 py-1 text-white cursor-pointer"
                                  >
                                    Edit
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const next = [...aiQueue];
                                      next[idx].reviewState = 'rejected';
                                      setAiQueue(next);
                                    }}
                                    className="rounded-lg text-rose-400 px-2 py-1 cursor-pointer"
                                  >
                                    Reject
                                  </button>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Bulk CSV / JSON Import */}
                {builderPanel === 'bulk' && (
                  <div className="rounded-2xl border border-[#3a3848] bg-[#25242f] p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h4 className="font-display text-sm font-bold text-white">
                        📤 Bulk Import (CSV / JSON) with Duplicate Check
                      </h4>
                      <button
                        type="button"
                        onClick={downloadSampleCsv}
                        className="btn-press inline-flex items-center gap-1 rounded-xl bg-[#1b1a22] border border-[#3a3848] px-3 py-1.5 text-xs font-semibold text-[#a8a4ff] cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>📥 Download Sample CSV</span>
                      </button>
                    </div>
                    <div className="flex gap-2">
                      {(['csv', 'json'] as const).map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setBulkMode(m)}
                          className={`rounded-lg px-3 py-1.5 text-xs font-bold uppercase cursor-pointer ${
                            bulkMode === m ? 'bg-[#4f46e5] text-white' : 'bg-[#1b1a22] text-[#a09eb5]'
                          }`}
                        >
                          {m}
                        </button>
                      ))}
                      {bulkMode === 'csv' && (
                        <input
                          type="file"
                          accept=".csv,text/csv"
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (!f) return;
                            const r = new FileReader();
                            r.onload = () => {
                              if (typeof r.result === 'string') setBulkText(r.result);
                            };
                            r.readAsText(f);
                          }}
                          className="text-xs text-[#a09eb5]"
                        />
                      )}
                    </div>
                    <textarea
                      rows={5}
                      value={bulkText}
                      onChange={(e) => setBulkText(e.target.value)}
                      placeholder={
                        bulkMode === 'csv'
                          ? 'Paste CSV rows (question,optionA,optionB,optionC,optionD,correctIndex,explanation,subject,examRef)...'
                          : 'Paste JSON array: [{"t":"...","o":["A","B","C","D"],"c":0,"e":"...","subj":"History","examRef":["JKSSB 2024"]}]'
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#1b1a22] p-3 text-xs font-mono text-white"
                    />
                    {bulkMsg && <p className="text-xs text-emerald-400 font-semibold">{bulkMsg}</p>}
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={handleBulkImport}
                        className="btn-press rounded-xl bg-emerald-600 px-4 py-2 text-xs font-bold text-white cursor-pointer"
                      >
                        Import Questions
                      </button>
                      <button
                        type="button"
                        onClick={() => setBuilderPanel(null)}
                        className="rounded-xl border border-[#3a3848] px-4 py-2 text-xs text-[#a09eb5] cursor-pointer"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                )}

                {/* Manual Question Form */}
                {builderPanel === 'manual' && (
                  <div className="rounded-2xl border border-[#3a3848] bg-[#25242f] p-4 space-y-3">
                    <h4 className="font-display text-sm font-bold text-white">
                      {qForm.editIdx !== null ? 'Edit Question' : 'Add New Question'}
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-[#a09eb5] mb-1">Subject</label>
                        <select
                          value={qForm.subj}
                          onChange={(e) => setQForm({ ...qForm, subj: e.target.value })}
                          className="w-full rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                        >
                          {data.subjects.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-[#a09eb5] mb-1">
                          Exam Reference Tags (Optional, Max 3)
                        </label>
                        <input
                          value={qForm.examRefText}
                          onChange={(e) => setQForm({ ...qForm, examRefText: e.target.value })}
                          placeholder="e.g. JKSSB 2024, JKPSC 2025, JKP SI 2026"
                          className="w-full rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                        />
                      </div>
                    </div>
                    <textarea
                      rows={2}
                      value={qForm.t}
                      onChange={(e) => setQForm({ ...qForm, t: e.target.value })}
                      placeholder="Question text *"
                      className="w-full rounded-xl border border-[#3a3848] bg-[#1b1a22] p-3 text-sm text-white"
                    />
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {qForm.o.map((opt, idx) => (
                        <input
                          key={idx}
                          value={opt}
                          onChange={(e) => {
                            const next: [string, string, string, string] = [...qForm.o];
                            next[idx] = e.target.value;
                            setQForm({ ...qForm, o: next });
                          }}
                          placeholder={`Option ${LABELS[idx]} *`}
                          className="w-full rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                        />
                      ))}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <select
                        value={qForm.c}
                        onChange={(e) => setQForm({ ...qForm, c: Number(e.target.value) })}
                        className="rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                      >
                        {[0, 1, 2, 3].map((idx) => (
                          <option key={idx} value={idx}>
                            Correct: Option {LABELS[idx]}
                          </option>
                        ))}
                      </select>
                      <input
                        value={qForm.e}
                        onChange={(e) => setQForm({ ...qForm, e: e.target.value })}
                        placeholder="Short explanation *"
                        className="md:col-span-2 rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                      />
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={handleSaveManualQuestion}
                        className="btn-press rounded-xl bg-[#4f46e5] px-4 py-2 text-xs font-bold text-white cursor-pointer"
                      >
                        {qForm.editIdx !== null ? 'Update Question' : 'Add Question'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setBuilderPanel(null)}
                        className="rounded-xl border border-[#3a3848] px-4 py-2 text-xs text-[#a09eb5] cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}

                {/* List of Questions in Test */}
                <div className="space-y-2.5">
                  {editingTest.qs.map((q, idx) => (
                    <div
                      key={q.id}
                      className="rounded-xl border border-[#2e2d3a] bg-[#25242f] p-3.5 flex items-start justify-between gap-3"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="text-xs font-bold text-white">
                          Q{idx + 1}. {q.t}
                        </div>
                        <div className="text-[11px] text-[#a09eb5]">
                          {q.subj} · ✔ {LABELS[q.c]} ({q.o[q.c]})
                          {q.examRef && q.examRef.length > 0 ? ` · 📌 ${q.examRef.join(', ')}` : ''}
                        </div>
                      </div>
                      <div className="flex gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setQForm({
                              t: q.t,
                              o: [...q.o],
                              c: q.c,
                              e: q.e,
                              subj: q.subj,
                              examRefText: (q.examRef || []).join(', '),
                              editIdx: idx,
                              aiReviewIdx: null,
                            });
                            setBuilderPanel('manual');
                          }}
                          className="rounded-lg border border-[#3a3848] p-1.5 text-[#a09eb5] hover:text-white cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setEditingTest({
                              ...editingTest,
                              qs: editingTest.qs.filter((_, i) => i !== idx),
                            })
                          }
                          className="rounded-lg border border-[#3a3848] p-1.5 text-rose-400 hover:bg-rose-950/40 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-3 pt-4 border-t border-[#2e2d3a]">
                  <button
                    type="button"
                    onClick={handleSaveTestToServer}
                    className="btn-press rounded-xl bg-emerald-600 px-6 py-2.5 text-sm font-bold text-white hover:bg-emerald-700 cursor-pointer"
                  >
                    💾 Save Mock Test
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingTest(null)}
                    className="rounded-xl border border-[#3a3848] px-5 py-2.5 text-sm font-semibold text-[#a09eb5] cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ================= TAB: MOCK TESTS LIST ================= */}
          {tab === 'tests' && !editingTest && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {data.tests.map((t) => (
                  <div
                    key={t.id}
                    className="card-hover rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-4 flex flex-col justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-[#a8a4ff] font-semibold">{t.exam}</span>
                        <span
                          className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase ${
                            t.status === 'live'
                              ? 'bg-emerald-950 text-emerald-300'
                              : t.status === 'scheduled'
                              ? 'bg-amber-950 text-amber-300'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {t.status}
                        </span>
                      </div>
                      <h3 className="font-display text-sm font-bold text-white">{t.title}</h3>
                      <div className="text-xs text-[#a09eb5] mt-1">
                        {t.qs.length} Qs · {t.dur}m · {t.paid ? `₹${t.price}` : 'Free'} · {t.testType}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 pt-2 border-t border-[#2e2d3a]">
                      <button
                        type="button"
                        onClick={() => openEditTest(t)}
                        className="flex-1 rounded-lg border border-[#3a3848] py-1.5 text-xs font-semibold text-white hover:bg-[#35327a] cursor-pointer"
                      >
                        ✏️ Edit
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/api/admin/tests/${t.id}`, { method: 'DELETE' });
                          onRefreshData();
                          onToast('Test deleted');
                        }}
                        className="rounded-lg border border-[#3a3848] px-3 py-1.5 text-xs text-rose-400 hover:bg-rose-950/40 cursor-pointer"
                      >
                        🗑
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================= TAB: RESULTS & EXPORT DISTRICT TOPPERS ================= */}
          {tab === 'results' && (
            <div className="space-y-5">
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs">
                  <div className="font-bold text-white">
                    Monthly Result Menu Auto-Refresh (Month-End Day at 11:55 PM)
                  </div>
                  <div className="text-[#a09eb5] mt-0.5 tabular-nums">
                    Next automatic refresh:{' '}
                    {data.resultCycle?.nextRefreshLabel ||
                      getNextMonthEndRefreshDate(new Date()).toLocaleString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit',
                      })}
                    {data.resultCycle?.lastRefreshIso
                      ? ` · Last refreshed: ${new Date(data.resultCycle.lastRefreshIso).toLocaleString('en-IN')}`
                      : ''}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await apiFetch('/api/admin/results/refresh', { method: 'POST' });
                      onRefreshData();
                      onToast('Result Menu archived & refreshed for the new cycle!');
                    } catch (err: unknown) {
                      onToast(err instanceof Error ? err.message : 'Refresh failed.');
                    }
                  }}
                  className="btn-press inline-flex items-center gap-1.5 rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2 text-xs font-semibold text-white hover:border-[#6c63ff] cursor-pointer whitespace-nowrap"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Archive &amp; Refresh Now</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <select
                  value={selectedResultTestId}
                  onChange={(e) => setSelectedResultTestId(Number(e.target.value))}
                  className="rounded-xl border border-[#3a3848] bg-[#25242f] px-4 py-2.5 text-sm text-white"
                >
                  {data.tests.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowToppersExport(true)}
                  className="btn-press inline-flex items-center gap-2 rounded-xl bg-amber-400 px-4 py-2.5 text-xs font-extrabold text-amber-950 cursor-pointer"
                >
                  <Award className="w-4 h-4" />
                  <span>🏆 View &amp; Export District Toppers</span>
                </button>
              </div>

              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-[#2e2d3a] text-[#a09eb5]">
                    <tr>
                      <th className="p-3.5">#</th>
                      <th className="p-3.5">Student</th>
                      <th className="p-3.5">District</th>
                      <th className="p-3.5">Score</th>
                      <th className="p-3.5">✔ / ✖</th>
                      <th className="p-3.5">Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2e2d3a]">
                    {data.results
                      .filter((r) => r.testId === selectedResultTestId)
                      .sort((a, b) => b.score - a.score || a.timeSec - b.timeSec)
                      .map((r, i) => (
                        <tr key={r.id}>
                          <td className="p-3.5 font-bold">{['🥇', '🥈', '🥉'][i] || i + 1}</td>
                          <td className="p-3.5 font-semibold text-white">{r.name}</td>
                          <td className="p-3.5 text-[#a09eb5]">{r.district}</td>
                          <td className="p-3.5 font-mono font-bold text-[#a8a4ff] tabular-nums">
                            {r.score}/{r.maxScore}
                          </td>
                          <td className="p-3.5 tabular-nums">
                            {r.correct} / {r.wrong}
                          </td>
                          <td className="p-3.5 tabular-nums text-[#a09eb5]">
                            {Math.floor(r.timeSec / 60)}m {r.timeSec % 60}s
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>

              {data.resultCycle && data.resultCycle.archivedCycles.length > 0 && (
                <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-3">
                  <h3 className="font-display text-sm font-bold text-white">
                    Archived Monthly Result Cycles ({data.resultCycle.archivedCycles.length})
                  </h3>
                  <div className="space-y-2">
                    {data.resultCycle.archivedCycles.map((arc) => (
                      <div
                        key={arc.cycleKey + arc.archivedAt}
                        className="flex items-center justify-between rounded-xl bg-[#25242f] px-4 py-2.5 text-xs"
                      >
                        <span className="font-semibold text-white">
                          {arc.cycleLabel} ({arc.cycleKey})
                        </span>
                        <span className="text-[#a09eb5] tabular-nums">
                          {arc.totalAttempts} attempts · Archived {arc.archivedAt}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {showToppersExport && (
                <div
                  className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
                  onClick={() => setShowToppersExport(false)}
                >
                  <div
                    className="w-full max-w-xl rounded-2xl border border-[#3a3848] bg-[#1b1a22] p-6 space-y-4 max-h-[85vh] overflow-y-auto"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-display text-lg font-bold text-white">
                        🏆 J&amp;K District Toppers Hall of Fame
                      </h3>
                      <button
                        type="button"
                        onClick={() => setShowToppersExport(false)}
                        className="text-[#a09eb5]"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="space-y-2">
                      {districtToppersList.map((d) => (
                        <div
                          key={d.district}
                          className="flex items-center justify-between rounded-xl bg-[#25242f] px-4 py-2.5 text-xs"
                        >
                          <span>
                            <strong className="text-amber-300">{d.district}:</strong> {d.name} ({d.targetExam})
                          </span>
                          <span className="font-mono font-bold text-emerald-400">
                            {d.score}/{d.maxScore}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const text =
                            '🏆 ExamPro J&K District Toppers:\n\n' +
                            districtToppersList
                              .map((d) => `🥇 ${d.district}: ${d.name} (${d.score}/${d.maxScore})`)
                              .join('\n');
                          navigator.clipboard.writeText(text);
                          onToast('Toppers list copied for WhatsApp / Telegram!');
                        }}
                        className="btn-press flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#4f46e5] py-2.5 text-xs font-bold text-white cursor-pointer"
                      >
                        <Copy className="w-4 h-4" />
                        <span>Copy for Telegram / WhatsApp</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const csv =
                            'District,Topper Name,Target Exam,Score,Max Score\n' +
                            districtToppersList
                              .map((d) => `"${d.district}","${d.name}","${d.targetExam}",${d.score},${d.maxScore}`)
                              .join('\n');
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = 'ExamPro_JK_District_Toppers.csv';
                          a.click();
                          URL.revokeObjectURL(url);
                        }}
                        className="btn-press inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>CSV</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================= TAB: STUDENTS ================= */}
          {tab === 'students' && (
            <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-[#2e2d3a] text-[#a09eb5]">
                  <tr>
                    <th className="p-3.5">Student</th>
                    <th className="p-3.5">Email</th>
                    <th className="p-3.5">Mobile</th>
                    <th className="p-3.5">District</th>
                    <th className="p-3.5">Target Exam</th>
                    <th className="p-3.5">Plan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2e2d3a]">
                  {(data.students || []).map((s) => (
                    <tr key={s.id}>
                      <td className="p-3.5 font-semibold text-white">{s.name}</td>
                      <td className="p-3.5 text-[#a09eb5]">{s.email}</td>
                      <td className="p-3.5 font-mono">{s.phone}</td>
                      <td className="p-3.5">{s.district}</td>
                      <td className="p-3.5 text-[#a09eb5]">{s.exam}</td>
                      <td className="p-3.5">
                        <span
                          className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                            s.ownedTestIds.length > 0
                              ? 'bg-emerald-950 text-emerald-300'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {s.ownedTestIds.length > 0 ? 'Paid' : 'Free'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* ================= TAB: EXAMS ================= */}
          {tab === 'exams' && (
            <div className="max-w-2xl space-y-4">
              <div className="flex gap-2">
                <input
                  value={newExamName}
                  onChange={(e) => setNewExamName(e.target.value)}
                  placeholder="Add new exam e.g. JKSSB Forester"
                  className="flex-1 rounded-xl border border-[#3a3848] bg-[#25242f] px-3.5 py-2.5 text-sm text-white"
                />
                <button
                  type="button"
                  onClick={async () => {
                    if (!newExamName.trim()) return;
                    await apiFetch('/api/admin/exams', {
                      method: 'POST',
                      body: JSON.stringify({ name: newExamName.trim() }),
                    });
                    setNewExamName('');
                    onRefreshData();
                    onToast('Exam added!');
                  }}
                  className="btn-press rounded-xl bg-[#4f46e5] px-5 py-2.5 text-xs font-bold text-white cursor-pointer"
                >
                  Add Exam
                </button>
              </div>
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] divide-y divide-[#2e2d3a]">
                {data.exams.map((ex) => (
                  <div key={ex} className="flex items-center justify-between px-4 py-3 text-sm">
                    <span>{ex}</span>
                    {ex !== 'Other' && (
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/api/admin/exams/${encodeURIComponent(ex)}`, {
                            method: 'DELETE',
                          });
                          onRefreshData();
                        }}
                        className="text-xs text-rose-400 hover:underline cursor-pointer"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================= TAB: TEST BUNDLES ================= */}
          {tab === 'bundles' && (
            <div className="space-y-5">
              <div className="flex justify-between items-center">
                <p className="text-xs text-[#a09eb5]">
                  Group Full-Length &amp; Sectional Mocks into discounted bundles.
                </p>
                <button
                  type="button"
                  onClick={() =>
                    setBundleDraft({
                      title: '',
                      exam: data.exams[0],
                      desc: '',
                      price: 199,
                      mrp: 499,
                      validity: '6 Months',
                      bundleOnly: false,
                      testIds: [],
                    })
                  }
                  className="btn-press rounded-xl bg-[#4f46e5] px-4 py-2 text-xs font-bold text-white cursor-pointer"
                >
                  + Create Bundle
                </button>
              </div>

              {bundleDraft && (
                <div className="rounded-2xl border border-[#3a3848] bg-[#25242f] p-5 space-y-3">
                  <h3 className="font-display text-sm font-bold text-white">
                    {bundleDraft.id ? 'Edit Bundle' : 'New Test Bundle'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input
                      value={bundleDraft.title || ''}
                      onChange={(e) => setBundleDraft({ ...bundleDraft, title: e.target.value })}
                      placeholder="Bundle Title *"
                      className="rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                    />
                    <select
                      value={bundleDraft.exam || data.exams[0]}
                      onChange={(e) => setBundleDraft({ ...bundleDraft, exam: e.target.value })}
                      className="rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                    >
                      {data.exams.map((ex) => (
                        <option key={ex} value={ex}>
                          {ex}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      value={bundleDraft.price || 199}
                      onChange={(e) => setBundleDraft({ ...bundleDraft, price: Number(e.target.value) })}
                      placeholder="Selling Price ₹"
                      className="rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                    />
                    <input
                      type="number"
                      value={bundleDraft.mrp || 499}
                      onChange={(e) => setBundleDraft({ ...bundleDraft, mrp: Number(e.target.value) })}
                      placeholder="Strikethrough MRP ₹"
                      className="rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                    />
                    <input
                      value={bundleDraft.validity || '6 Months'}
                      onChange={(e) => setBundleDraft({ ...bundleDraft, validity: e.target.value })}
                      placeholder="Validity (e.g. 6 Months)"
                      className="rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-2 text-sm text-white"
                    />
                    <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(bundleDraft.bundleOnly)}
                        onChange={(e) =>
                          setBundleDraft({ ...bundleDraft, bundleOnly: e.target.checked })
                        }
                      />
                      Bundle-Only Exclusive
                    </label>
                  </div>
                  <textarea
                    rows={2}
                    value={bundleDraft.desc || ''}
                    onChange={(e) => setBundleDraft({ ...bundleDraft, desc: e.target.value })}
                    placeholder="Bundle description..."
                    className="w-full rounded-xl border border-[#3a3848] bg-[#1b1a22] p-3 text-sm text-white"
                  />
                  <div>
                    <div className="text-xs text-[#a09eb5] mb-2">Select Included Mock Tests:</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                      {data.tests.map((t) => {
                        const checked = (bundleDraft.testIds || []).includes(t.id);
                        return (
                          <label
                            key={t.id}
                            className="flex items-center gap-2 text-xs rounded-lg bg-[#1b1a22] px-3 py-2 cursor-pointer"
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => {
                                const cur = bundleDraft.testIds || [];
                                setBundleDraft({
                                  ...bundleDraft,
                                  testIds: checked ? cur.filter((x) => x !== t.id) : [...cur, t.id],
                                });
                              }}
                            />
                            <span className="truncate">{t.title}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={async () => {
                        if (!bundleDraft.title?.trim()) return;
                        if (bundleDraft.id) {
                          await apiFetch(`/api/admin/bundles/${bundleDraft.id}`, {
                            method: 'PUT',
                            body: JSON.stringify(bundleDraft),
                          });
                        } else {
                          await apiFetch('/api/admin/bundles', {
                            method: 'POST',
                            body: JSON.stringify(bundleDraft),
                          });
                        }
                        setBundleDraft(null);
                        onRefreshData();
                        onToast('Bundle saved!');
                      }}
                      className="btn-press rounded-xl bg-emerald-600 px-5 py-2 text-xs font-bold text-white cursor-pointer"
                    >
                      Save Bundle
                    </button>
                    <button
                      type="button"
                      onClick={() => setBundleDraft(null)}
                      className="rounded-xl border border-[#3a3848] px-4 py-2 text-xs text-[#a09eb5] cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {data.bundles.map((b) => (
                  <div
                    key={b.id}
                    className="rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-4 space-y-2"
                  >
                    <div className="text-xs text-[#a8a4ff] font-semibold">
                      {b.exam} · {b.validity}
                    </div>
                    <h4 className="font-display text-sm font-bold text-white">{b.title}</h4>
                    <div className="text-xs text-[#a09eb5]">
                      ₹{b.price} <span className="line-through">₹{b.mrp}</span> · {b.testIds.length} tests
                    </div>
                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setBundleDraft(b)}
                        className="flex-1 rounded-lg border border-[#3a3848] py-1.5 text-xs text-white cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await apiFetch(`/api/admin/bundles/${b.id}`, { method: 'DELETE' });
                          onRefreshData();
                        }}
                        className="rounded-lg border border-[#3a3848] px-3 py-1.5 text-xs text-rose-400 cursor-pointer"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================= TAB: PAYMENTS, UPI SETTINGS & COUPONS ================= */}
          {tab === 'payments' && (
            <div className="space-y-6">
              {/* 4 Dark Stat Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Revenue', val: `₹${totalRevenue}` },
                  { label: 'Pending UPI Orders', val: pendingPayments.length },
                  { label: 'Paid Orders', val: data.payments.filter((p) => p.status === 'PAID').length },
                  { label: 'Active Coupons', val: data.coupons.filter((c) => c.active).length },
                ].map((c) => (
                  <div key={c.label} className="rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-4">
                    <div className="font-mono text-2xl font-extrabold text-white tabular-nums">
                      {c.val}
                    </div>
                    <div className="text-xs text-[#a09eb5] mt-1">{c.label}</div>
                  </div>
                ))}
              </div>

              {/* ⚙️ UPI & QR Payment Settings */}
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-4">
                <h3 className="font-display text-sm font-bold text-white">
                  ⚙️ UPI &amp; QR Payment Settings
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                  <div className="flex items-center gap-4">
                    <img
                      src={upiDraft.qrImageUrl}
                      alt="Admin UPI QR"
                      className="h-20 w-20 rounded-xl bg-white p-1.5 object-contain"
                    />
                    <label className="btn-press rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs font-semibold text-white cursor-pointer">
                      Upload QR Image
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (!f) return;
                          const r = new FileReader();
                          r.onload = () => {
                            if (typeof r.result === 'string') {
                              setUpiDraft({ ...upiDraft, qrImageUrl: r.result });
                            }
                          };
                          r.readAsDataURL(f);
                        }}
                      />
                    </label>
                  </div>
                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">UPI ID</label>
                    <input
                      value={upiDraft.upiId}
                      onChange={(e) => setUpiDraft({ ...upiDraft, upiId: e.target.value })}
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm font-mono text-white"
                    />
                  </div>
                  <div className="flex gap-2 items-end">
                    <div className="flex-1">
                      <label className="block text-xs text-[#a09eb5] mb-1">Merchant Name</label>
                      <input
                        value={upiDraft.payeeName}
                        onChange={(e) => setUpiDraft({ ...upiDraft, payeeName: e.target.value })}
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await apiFetch('/api/admin/settings', {
                          method: 'PUT',
                          body: JSON.stringify({ upi: upiDraft }),
                        });
                        onRefreshData();
                        onToast('UPI & QR settings saved!');
                      }}
                      className="btn-press rounded-xl bg-[#4f46e5] px-4 py-2.5 text-xs font-bold text-white cursor-pointer"
                    >
                      Save UPI
                    </button>
                  </div>
                </div>
              </div>

              {/* Sub-tabs: Transactions vs Coupons */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setPaySubTab('tx')}
                  className={`rounded-xl px-4 py-2 text-xs font-bold cursor-pointer ${
                    paySubTab === 'tx' ? 'bg-[#4f46e5] text-white' : 'bg-[#25242f] text-[#a09eb5]'
                  }`}
                >
                  Transactions ({data.payments.length})
                </button>
                <button
                  type="button"
                  onClick={() => setPaySubTab('coupons')}
                  className={`rounded-xl px-4 py-2 text-xs font-bold cursor-pointer ${
                    paySubTab === 'coupons' ? 'bg-[#4f46e5] text-white' : 'bg-[#25242f] text-[#a09eb5]'
                  }`}
                >
                  Coupons ({data.coupons.length})
                </button>
              </div>

              {paySubTab === 'tx' ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-3 items-center justify-between">
                    <div className="relative flex-1 min-w-[220px]">
                      <Search className="w-4 h-4 text-[#a09eb5] absolute left-3 top-2.5" />
                      <input
                        value={txSearch}
                        onChange={(e) => setTxSearch(e.target.value)}
                        placeholder="Search by student, phone, UTR, or Order ID..."
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] pl-9 pr-3 py-2 text-xs text-white"
                      />
                    </div>

                    {/* Manual Unlock Utility */}
                    <div className="flex flex-wrap items-center gap-2">
                      <select
                        value={manualUnlock.userId}
                        onChange={(e) => setManualUnlock({ ...manualUnlock, userId: Number(e.target.value) })}
                        className="rounded-xl border border-[#3a3848] bg-[#25242f] px-2.5 py-2 text-xs text-white"
                      >
                        <option value={0}>Select Student</option>
                        {(data.students || []).map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} ({s.phone})
                          </option>
                        ))}
                      </select>
                      <select
                        value={manualUnlock.itemId}
                        onChange={(e) => setManualUnlock({ ...manualUnlock, itemId: Number(e.target.value) })}
                        className="rounded-xl border border-[#3a3848] bg-[#25242f] px-2.5 py-2 text-xs text-white"
                      >
                        <option value={0}>Select Test</option>
                        {data.tests.map((t) => (
                          <option key={t.id} value={t.id}>
                            {t.title}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={async () => {
                          if (!manualUnlock.userId || !manualUnlock.itemId) return;
                          await apiFetch('/api/admin/payments/manual-unlock', {
                            method: 'POST',
                            body: JSON.stringify(manualUnlock),
                          });
                          onRefreshData();
                          onToast('Unlocked manually for student!');
                        }}
                        className="btn-press rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white cursor-pointer"
                      >
                        Manual Unlock
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {data.payments
                      .filter((p) => {
                        const q = txSearch.toLowerCase();
                        return (
                          !q ||
                          p.userName.toLowerCase().includes(q) ||
                          p.userPhone.includes(q) ||
                          (p.utrNumber || '').toLowerCase().includes(q) ||
                          p.orderNumber.toLowerCase().includes(q)
                        );
                      })
                      .map((p) => (
                        <div
                          key={p.id}
                          className={`rounded-2xl border p-4 flex flex-wrap items-center justify-between gap-4 ${
                            p.status === 'PENDING_VERIFICATION'
                              ? 'border-amber-500/60 bg-amber-950/20'
                              : 'border-[#2e2d3a] bg-[#1b1a22]'
                          }`}
                        >
                          <div className="space-y-1 text-xs">
                            <div className="flex flex-wrap items-center gap-2">
                              <strong className="text-sm text-white">{p.itemTitle}</strong>
                              <span className="font-mono text-[#a8a4ff]">{p.orderNumber}</span>
                              <span
                                className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                                  p.status === 'PAID'
                                    ? 'bg-emerald-950 text-emerald-300'
                                    : p.status === 'PENDING_VERIFICATION'
                                    ? 'bg-amber-950 text-amber-300'
                                    : 'bg-rose-950 text-rose-300'
                                }`}
                              >
                                {p.status}
                              </span>
                            </div>
                            <div className="text-[#a09eb5]">
                              Student: <strong className="text-white">{p.userName}</strong> (+91 {p.userPhone}) ·{' '}
                              Paid: <strong className="text-white">₹{p.finalAmount}</strong>
                              {p.couponCode ? ` · Coupon: ${p.couponCode}` : ''} · {p.createdAt}
                            </div>
                            {p.utrNumber && (
                              <div className="font-mono text-amber-300">
                                UTR: <strong>{p.utrNumber}</strong>
                              </div>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-2">
                            {p.screenshotUrl && (
                              <button
                                type="button"
                                onClick={() => setPreviewScreenshot(p.screenshotUrl!)}
                                className="rounded-xl border border-[#3a3848] px-3 py-1.5 text-xs text-white cursor-pointer"
                              >
                                🖼 Screenshot
                              </button>
                            )}
                            {p.status === 'PENDING_VERIFICATION' && (
                              <>
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await apiFetch(`/api/admin/payments/${p.id}/approve`, {
                                      method: 'POST',
                                    });
                                    onRefreshData();
                                    onToast('✅ Order approved & unlocked!');
                                  }}
                                  className="btn-press inline-flex items-center gap-1 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white cursor-pointer"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Approve &amp; Unlock</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await apiFetch(`/api/admin/payments/${p.id}/reject`, {
                                      method: 'POST',
                                    });
                                    onRefreshData();
                                    onToast('Order rejected');
                                  }}
                                  className="btn-press inline-flex items-center gap-1 rounded-xl bg-rose-600 px-3.5 py-2 text-xs font-bold text-white cursor-pointer"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span>Reject</span>
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-4 grid grid-cols-1 sm:grid-cols-5 gap-3 items-end">
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Code</label>
                      <input
                        value={newCoupon.code}
                        onChange={(e) => setNewCoupon({ ...newCoupon, code: e.target.value.toUpperCase() })}
                        placeholder="JK50"
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white uppercase"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Type</label>
                      <select
                        value={newCoupon.type}
                        onChange={(e) =>
                          setNewCoupon({
                            ...newCoupon,
                            type: e.target.value as 'percent' | 'flat' | 'free',
                          })
                        }
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                      >
                        <option value="percent">% Off</option>
                        <option value="flat">Flat ₹ Off</option>
                        <option value="free">100% Free</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Value</label>
                      <input
                        type="number"
                        value={newCoupon.value}
                        onChange={(e) => setNewCoupon({ ...newCoupon, value: Number(e.target.value) })}
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-[#a09eb5] mb-1">Expiry</label>
                      <input
                        type="date"
                        value={newCoupon.expiryDate}
                        onChange={(e) => setNewCoupon({ ...newCoupon, expiryDate: e.target.value })}
                        className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!newCoupon.code.trim()) return;
                        await apiFetch('/api/admin/coupons', {
                          method: 'POST',
                          body: JSON.stringify(newCoupon),
                        });
                        setNewCoupon({ ...newCoupon, code: '' });
                        onRefreshData();
                        onToast('Coupon created!');
                      }}
                      className="btn-press rounded-xl bg-[#4f46e5] py-2.5 text-xs font-bold text-white cursor-pointer"
                    >
                      + Create Coupon
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {data.coupons.map((c: Coupon) => (
                      <div
                        key={c.id}
                        className="rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-4 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-mono text-sm font-extrabold text-white">{c.code}</div>
                          <div className="text-xs text-[#a09eb5]">
                            {c.type === 'free'
                              ? '100% Free'
                              : c.type === 'percent'
                              ? `${c.value}% Off`
                              : `₹${c.value} Off`}{' '}
                            · Used {c.usedCount}/{c.maxUses}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await apiFetch(`/api/admin/coupons/${c.id}`, {
                              method: 'PUT',
                              body: JSON.stringify({ active: !c.active }),
                            });
                            onRefreshData();
                          }}
                          className={`rounded-lg px-3 py-1 text-xs font-bold cursor-pointer ${
                            c.active ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-300'
                          }`}
                        >
                          {c.active ? 'Active' : 'Off'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {previewScreenshot && (
                <div
                  className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
                  onClick={() => setPreviewScreenshot(null)}
                >
                  <img
                    src={previewScreenshot}
                    alt="Payment screenshot"
                    className="max-h-[85vh] max-w-full rounded-2xl border border-white/20"
                  />
                </div>
              )}
            </div>
          )}

          {/* ================= TAB: DAILY QUIZ & UPDATES ================= */}
          {tab === 'daily' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-white">
                  📅 Schedule Daily 10-Q J&amp;K Quiz
                </h3>
                <input
                  type="date"
                  value={dqDate}
                  onChange={(e) => setDqDate(e.target.value)}
                  className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                />
                <input
                  value={dqTitle}
                  onChange={(e) => setDqTitle(e.target.value)}
                  className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                />
                <textarea
                  rows={6}
                  value={dqBulkJson}
                  onChange={(e) => setDqBulkJson(e.target.value)}
                  placeholder='Paste JSON array of 10 questions: [{"t":"...","o":["A","B","C","D"],"c":0,"e":"...","subj":"Current Affairs"}]'
                  className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] p-3 text-xs font-mono text-white"
                />
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const qs = JSON.parse(dqBulkJson);
                      await apiFetch('/api/admin/daily-quiz', {
                        method: 'POST',
                        body: JSON.stringify({ date: dqDate, title: dqTitle, questions: qs }),
                      });
                      setDqBulkJson('');
                      onRefreshData();
                      onToast('Daily Quiz scheduled!');
                    } catch {
                      onToast('Provide valid JSON array of questions.');
                    }
                  }}
                  className="btn-press rounded-xl bg-[#4f46e5] px-5 py-2.5 text-xs font-bold text-white cursor-pointer"
                >
                  Publish Daily Quiz
                </button>
              </div>

              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-white">
                  📢 Post J&amp;K Exam Update / Countdown
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={updForm.type}
                    onChange={(e) =>
                      setUpdForm({
                        ...updForm,
                        type: e.target.value as 'alert' | 'exam_date' | 'admit_card' | 'result',
                      })
                    }
                    className="rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                  >
                    <option value="alert">General Alert</option>
                    <option value="exam_date">Exam Date</option>
                    <option value="admit_card">Admit Card</option>
                    <option value="result">Result</option>
                  </select>
                  <select
                    value={updForm.exam}
                    onChange={(e) => setUpdForm({ ...updForm, exam: e.target.value })}
                    className="rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                  >
                    {data.exams.map((ex) => (
                      <option key={ex} value={ex}>
                        {ex}
                      </option>
                    ))}
                  </select>
                </div>
                <input
                  value={updForm.title}
                  onChange={(e) => setUpdForm({ ...updForm, title: e.target.value })}
                  placeholder="Update Title *"
                  className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                />
                <input
                  type="date"
                  value={updForm.examDate}
                  onChange={(e) => setUpdForm({ ...updForm, examDate: e.target.value })}
                  className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                />
                <textarea
                  rows={3}
                  value={updForm.message}
                  onChange={(e) => setUpdForm({ ...updForm, message: e.target.value })}
                  placeholder="Announcement details..."
                  className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] p-3 text-xs text-white"
                />
                <button
                  type="button"
                  onClick={async () => {
                    if (!updForm.title.trim()) return;
                    await apiFetch('/api/admin/updates', {
                      method: 'POST',
                      body: JSON.stringify(updForm),
                    });
                    setUpdForm({ ...updForm, title: '', message: '', examDate: '' });
                    onRefreshData();
                    onToast('Exam update published!');
                  }}
                  className="btn-press rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-bold text-white cursor-pointer"
                >
                  Publish Alert
                </button>
              </div>
            </div>
          )}

          {/* ================= TAB: SYLLABUS ================= */}
          {tab === 'syllabus' && (
            <div className="space-y-5 max-w-3xl">
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-3">
                <h3 className="font-display text-base font-bold text-white">
                  📄 Upload Official Syllabus PDF
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <select
                    value={sylForm.exam}
                    onChange={(e) => setSylForm({ ...sylForm, exam: e.target.value })}
                    className="rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                  >
                    {data.exams.map((ex) => (
                      <option key={ex} value={ex}>
                        {ex}
                      </option>
                    ))}
                  </select>
                  <input
                    value={sylForm.title}
                    onChange={(e) => setSylForm({ ...sylForm, title: e.target.value })}
                    placeholder="Syllabus Title *"
                    className="rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                  />
                </div>
                <input
                  value={sylForm.summary}
                  onChange={(e) => setSylForm({ ...sylForm, summary: e.target.value })}
                  placeholder="Short topic summary..."
                  className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                />
                <input
                  type="file"
                  accept="application/pdf"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    const r = new FileReader();
                    r.onload = () => {
                      if (typeof r.result === 'string') {
                        setSylForm({ ...sylForm, fileName: f.name, pdfUrl: r.result });
                      }
                    };
                    r.readAsDataURL(f);
                  }}
                  className="text-xs text-[#a09eb5]"
                />
                <button
                  type="button"
                  onClick={async () => {
                    if (!sylForm.title.trim()) return;
                    await apiFetch('/api/admin/syllabus', {
                      method: 'POST',
                      body: JSON.stringify(sylForm),
                    });
                    setSylForm({ ...sylForm, title: '', summary: '', fileName: '', pdfUrl: '' });
                    onRefreshData();
                    onToast('Syllabus uploaded!');
                  }}
                  className="btn-press rounded-xl bg-[#4f46e5] px-5 py-2.5 text-xs font-bold text-white cursor-pointer"
                >
                  Save Syllabus
                </button>
              </div>

              <div className="space-y-3">
                {data.syllabi.map((s) => (
                  <div
                    key={s.id}
                    className="rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-4 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-xs text-[#a8a4ff] font-semibold">{s.exam}</div>
                      <div className="font-bold text-sm text-white">{s.title}</div>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        await apiFetch(`/api/admin/syllabus/${s.id}`, { method: 'DELETE' });
                        onRefreshData();
                      }}
                      className="text-xs text-rose-400 cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ================= TAB: SUPPORT & REPORTS ================= */}
          {tab === 'support' && (
            <div className="space-y-5">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSupTab('tickets')}
                  className={`rounded-xl px-4 py-2 text-xs font-bold cursor-pointer ${
                    supTab === 'tickets' ? 'bg-[#4f46e5] text-white' : 'bg-[#25242f] text-[#a09eb5]'
                  }`}
                >
                  Student Support / Payment Issues ({pendingTicketsCount})
                </button>
                <button
                  type="button"
                  onClick={() => setSupTab('reports')}
                  className={`rounded-xl px-4 py-2 text-xs font-bold cursor-pointer ${
                    supTab === 'reports' ? 'bg-[#4f46e5] text-white' : 'bg-[#25242f] text-[#a09eb5]'
                  }`}
                >
                  Reported Questions ({pendingReportsCount})
                </button>
              </div>

              {supTab === 'tickets' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.supportTickets.map((t) => (
                    <div
                      key={t.id}
                      className="rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-4 space-y-2.5"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <strong className="text-white">{t.subject}</strong>
                        <span
                          className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase ${
                            t.status === 'resolved'
                              ? 'bg-emerald-950 text-emerald-300'
                              : 'bg-amber-950 text-amber-300'
                          }`}
                        >
                          {t.status}
                        </span>
                      </div>
                      <p className="text-xs text-[#a09eb5]">{t.message}</p>
                      <div className="text-[11px] text-[#a09eb5]">
                        {t.userName} · +91 {t.userPhone}
                        {t.orderId ? ` · Order: ${t.orderId}` : ''}
                      </div>
                      <div className="flex gap-2 pt-2">
                        <a
                          href={`https://wa.me/91${t.userPhone}?text=${encodeURIComponent(
                            `Hi ${t.userName}, regarding your ExamPro ticket (${t.subject}): `
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="btn-press rounded-xl bg-[#25D366] px-3 py-1.5 text-xs font-bold text-white"
                        >
                          💬 Reply on WhatsApp
                        </a>
                        {t.status === 'pending' && (
                          <button
                            type="button"
                            onClick={async () => {
                              await apiFetch(`/api/admin/support/${t.id}/resolve`, {
                                method: 'POST',
                              });
                              onRefreshData();
                              onToast('Ticket resolved!');
                            }}
                            className="btn-press rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white cursor-pointer"
                          >
                            ✅ Mark Resolved
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.reportedQuestions.map((r) => (
                    <div
                      key={r.id}
                      className="rounded-2xl border border-[#2e2d3a] bg-[#25242f] p-4 space-y-2.5"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[#a8a4ff] font-semibold">{r.testTitle}</span>
                        <span
                          className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase ${
                            r.status === 'resolved'
                              ? 'bg-emerald-950 text-emerald-300'
                              : 'bg-rose-950 text-rose-300'
                          }`}
                        >
                          {r.status}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-white">{r.questionText}</div>
                      <div className="text-xs text-rose-300">Reason: {r.reason}</div>
                      <div className="text-[11px] text-[#a09eb5]">
                        Reported by {r.reporterName} · {r.createdAt}
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => {
                            const found = data.tests.find((t) => t.id === r.testId);
                            if (found) openEditTest(found);
                          }}
                          className="btn-press rounded-xl border border-[#3a3848] bg-[#1b1a22] px-3 py-1.5 text-xs font-bold text-white cursor-pointer"
                        >
                          ✏️ Edit Question
                        </button>
                        {r.status === 'pending' && (
                          <button
                            type="button"
                            onClick={async () => {
                              await apiFetch(`/api/admin/reports/${r.id}/resolve`, {
                                method: 'POST',
                              });
                              onRefreshData();
                              onToast('Report marked resolved!');
                            }}
                            className="btn-press rounded-xl bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white cursor-pointer"
                          >
                            ✅ Mark Resolved
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= TAB: SHARING & ADMIN SETTINGS ================= */}
          {tab === 'settings' && (
            <div className="max-w-3xl space-y-6">
              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-4">
                <h3 className="font-display text-base font-bold text-white">
                  🔗 Social Share Bar &amp; Invite Message
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Share Message</label>
                    <input
                      value={settingsDraft.shareMessage}
                      onChange={(e) =>
                        setSettingsDraft({ ...settingsDraft, shareMessage: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">App Link</label>
                    <input
                      value={settingsDraft.shareAppUrl}
                      onChange={(e) =>
                        setSettingsDraft({ ...settingsDraft, shareAppUrl: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  {(
                    [
                      ['wa', 'WhatsApp'],
                      ['fb', 'Facebook'],
                      ['ig', 'Instagram'],
                      ['yt', 'YouTube'],
                    ] as const
                  ).map(([key, label]) => (
                    <div key={key} className="flex items-center gap-3">
                      <span className="w-24 text-xs font-semibold text-white">{label}</span>
                      <input
                        value={settingsDraft.social[key].url}
                        onChange={(e) =>
                          setSettingsDraft({
                            ...settingsDraft,
                            social: {
                              ...settingsDraft.social,
                              [key]: { ...settingsDraft.social[key], url: e.target.value },
                            },
                          })
                        }
                        className="flex-1 rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-xs text-white"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setSettingsDraft({
                            ...settingsDraft,
                            social: {
                              ...settingsDraft.social,
                              [key]: {
                                ...settingsDraft.social[key],
                                on: !settingsDraft.social[key].on,
                              },
                            },
                          })
                        }
                        className={`rounded-xl px-3 py-1.5 text-xs font-bold cursor-pointer ${
                          settingsDraft.social[key].on
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-700 text-slate-300'
                        }`}
                      >
                        {settingsDraft.social[key].on ? 'ON' : 'OFF'}
                      </button>
                    </div>
                  ))}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs font-semibold text-white">Copy Link Icon</span>
                    <button
                      type="button"
                      onClick={() =>
                        setSettingsDraft({
                          ...settingsDraft,
                          social: {
                            ...settingsDraft.social,
                            cp: { on: !settingsDraft.social.cp.on },
                          },
                        })
                      }
                      className={`rounded-xl px-3 py-1.5 text-xs font-bold cursor-pointer ${
                        settingsDraft.social.cp.on
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-700 text-slate-300'
                      }`}
                    >
                      {settingsDraft.social.cp.on ? 'ON' : 'OFF'}
                    </button>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-[#2e2d3a] bg-[#1b1a22] p-5 space-y-4">
                <h3 className="font-display text-base font-bold text-white">
                  🛡️ Admin Credentials &amp; WhatsApp Support
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Admin Email</label>
                    <input
                      value={settingsDraft.adminEmail}
                      onChange={(e) =>
                        setSettingsDraft({ ...settingsDraft, adminEmail: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">Admin Phone</label>
                    <input
                      value={settingsDraft.adminPhone}
                      onChange={(e) =>
                        setSettingsDraft({ ...settingsDraft, adminPhone: e.target.value })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">
                      WhatsApp Support Number (with 91)
                    </label>
                    <input
                      value={settingsDraft.whatsappSupportNumber}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          whatsappSupportNumber: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#a09eb5] mb-1">
                      WhatsApp Default Message
                    </label>
                    <input
                      value={settingsDraft.whatsappSupportMessage}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          whatsappSupportMessage: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[#3a3848] bg-[#25242f] px-3 py-2 text-sm text-white"
                    />
                  </div>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    await apiFetch('/api/admin/settings', {
                      method: 'PUT',
                      body: JSON.stringify(settingsDraft),
                    });
                    onRefreshData();
                    onToast('All settings saved & synced!');
                  }}
                  className="btn-press inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Save Settings</span>
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
