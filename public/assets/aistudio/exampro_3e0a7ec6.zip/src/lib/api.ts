const SESSION_KEY = 'exampro_session_v1';
const VISITOR_KEY = 'exampro_visitor_id';

export interface StoredSession {
  userId: number;
  sessionToken: string | null;
}

export function getStoredSession(): StoredSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as StoredSession) : null;
  } catch {
    return null;
  }
}

export function setStoredSession(session: StoredSession | null) {
  try {
    if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  } catch {
    // ignore storage errors
  }
}

export function getVisitorId(): string {
  try {
    let id = localStorage.getItem(VISITOR_KEY);
    if (!id) {
      id = `v-${Math.random().toString(36).slice(2)}-${Date.now().toString(36)}`;
      localStorage.setItem(VISITOR_KEY, id);
    }
    return id;
  } catch {
    return 'v-anon';
  }
}

export async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const session = getStoredSession();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'x-visitor-id': getVisitorId(),
    ...(options.headers as Record<string, string> | undefined),
  };
  if (session) {
    headers['x-user-id'] = String(session.userId);
    if (session.sessionToken) {
      headers['x-session-token'] = session.sessionToken;
    }
  }

  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data as T;
}
