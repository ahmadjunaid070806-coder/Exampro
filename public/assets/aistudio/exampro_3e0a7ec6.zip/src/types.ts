export const JK_DISTRICTS = [
  'Srinagar',
  'Budgam',
  'Baramulla',
  'Anantnag',
  'Ganderbal',
  'Bandipora',
  'Kupwara',
  'Pulwama',
  'Shopian',
  'Kulgam',
  'Jammu',
  'Samba',
  'Kathua',
  'Udhampur',
  'Reasi',
  'Doda',
  'Kishtwar',
  'Ramban',
  'Rajouri',
  'Poonch',
] as const;

export const DEFAULT_CATEGORIES = [
  { id: 'latest', label: 'Latest Mock Tests', icon: '🔥' },
  { id: 'upcoming', label: 'Upcoming', icon: '📅' },
  { id: 'free', label: 'Free Mocks', icon: '🎁' },
  { id: 'pyqs', label: 'Previous Year Papers (PYQs)', icon: '📜' },
  { id: 'popular', label: 'Most Attempted / Popular', icon: '⚡' },
  { id: 'jk_special', label: 'J&K Special & Current Affairs', icon: '🏔️' },
  { id: 'sectional', label: 'Sectional & Subject Tests', icon: '🧩' },
  { id: 'mega', label: 'All-J&K Live Mega Mocks', icon: '🏆' },
] as const;

export const DEFAULT_SUBJECTS = [
  'J&K General Knowledge',
  'History',
  'Geography',
  'Indian Polity',
  'English',
  'Math',
  'Reasoning',
  'Computer',
  'General Science',
  'Current Affairs',
];

export interface Question {
  id: string;
  t: string;
  o: [string, string, string, string];
  c: number;
  e: string;
  subj: string;
  src?: 'manual' | 'ai' | 'csv' | 'json';
  examRef?: string[]; // max 3 tags e.g. ["JKSSB 2024", "JKP 2025"]
}

export interface MockTest {
  id: number;
  cat: string;
  exam: string;
  title: string;
  testType: 'full' | 'sectional';
  subject?: string;
  paid: boolean;
  price: number;
  dur: number;
  neg: number;
  sched: string;
  status: 'live' | 'scheduled' | 'draft';
  desc: string;
  syllabusTag: string;
  language: string;
  attemptCount: number;
  bundleId?: number | null;
  qs: Question[];
}

export interface TestBundle {
  id: number;
  title: string;
  exam: string;
  desc: string;
  price: number;
  mrp: number;
  validity: string;
  bundleOnly: boolean;
  testIds: number[];
  featured?: boolean;
}

export interface TestResultEntry {
  id: string;
  testId: number;
  userId: number;
  name: string;
  district: string;
  targetExam: string;
  score: number;
  maxScore: number;
  correct: number;
  wrong: number;
  skipped: number;
  timeSec: number;
  subjectBreakdown: Record<string, { correct: number; total: number }>;
  date: string;
}

export interface MistakeItem {
  id: string;
  t: string;
  o: [string, string, string, string];
  c: number;
  sel: number;
  e: string;
  subj: string;
  testTitle: string;
  examRef?: string[];
  addedAt: string;
}

export interface BookmarkItem {
  id: string;
  t: string;
  o: [string, string, string, string];
  c: number;
  e: string;
  subj: string;
  testTitle: string;
  examRef?: string[];
}

export interface AttemptSummary {
  id: string;
  testId: number;
  testTitle: string;
  score: number;
  maxScore: number;
  correct: number;
  wrong: number;
  skipped: number;
  rank: number;
  totalParticipants: number;
  districtRank: number;
  districtTotal: number;
  percentile: number;
  date: string;
}

export type PaymentStatus = 'PENDING_VERIFICATION' | 'PAID' | 'REJECTED' | 'REFUNDED';

export interface PaymentOrder {
  id: string;
  orderNumber: string;
  userId: number;
  userName: string;
  userPhone: string;
  itemType: 'test' | 'bundle';
  itemId: number;
  itemTitle: string;
  originalAmount: number;
  discountAmount: number;
  finalAmount: number;
  couponCode?: string;
  utrNumber?: string;
  screenshotUrl?: string;
  paymentMethod: 'UPI' | 'FREE_COUPON';
  status: PaymentStatus;
  createdAt: string;
  verifiedAt?: string;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'percent' | 'flat' | 'free';
  value: number;
  maxUses: number;
  usedCount: number;
  expiryDate: string;
  active: boolean;
}

export interface DailyQuiz {
  id: string;
  date: string;
  title: string;
  questions: Question[];
}

export interface ExamUpdate {
  id: string;
  type: 'alert' | 'exam_date' | 'admit_card' | 'result';
  title: string;
  exam: string;
  message: string;
  examDate?: string;
  link?: string;
  createdAt: string;
}

export interface SyllabusDoc {
  id: string;
  exam: string;
  title: string;
  summary: string;
  pdfUrl: string;
  fileName: string;
  uploadedAt: string;
}

export interface SupportTicket {
  id: string;
  userId: number;
  userName: string;
  userPhone: string;
  userEmail: string;
  orderId?: string;
  subject: string;
  message: string;
  status: 'pending' | 'resolved';
  createdAt: string;
}

export interface ReportedQuestion {
  id: string;
  testId: number;
  testTitle: string;
  questionId: string;
  questionText: string;
  reporterId: number;
  reporterName: string;
  reason: string;
  status: 'pending' | 'resolved';
  createdAt: string;
}

export interface UpiSettings {
  upiId: string;
  payeeName: string;
  qrImageUrl: string;
}

export interface SocialPlatformConfig {
  on: boolean;
  url: string;
}

export interface AppSettings {
  adminEmail: string;
  adminPhone: string;
  whatsappSupportNumber: string;
  whatsappSupportMessage: string;
  shareMessage: string;
  shareAppUrl: string;
  social: {
    wa: SocialPlatformConfig;
    fb: SocialPlatformConfig;
    ig: SocialPlatformConfig;
    yt: SocialPlatformConfig;
    cp: { on: boolean };
  };
  upi: UpiSettings;
}

export interface UserProfile {
  id: number;
  email: string;
  phone: string;
  name: string;
  district: string;
  exam: string;
  role: 'student' | 'admin';
  sessionToken: string | null;
  ownedTestIds: number[];
  ownedBundleIds: number[];
  mistakes: MistakeItem[];
  bookmarks: BookmarkItem[];
  attempts: AttemptSummary[];
  dailyStreak: number;
  lastDailyQuizDate?: string;
  joinedAt: string;
  lastActiveDate: string;
}

export interface TrafficStats {
  totalVisitors: number;
  todayActiveStudents: number;
}

export interface MonthlyResultArchive {
  cycleKey: string; // YYYY-MM
  cycleLabel: string;
  archivedAt: string;
  totalAttempts: number;
  results: TestResultEntry[];
}

export interface ResultCycleInfo {
  cycleKey: string;
  nextRefreshIso: string;
  nextRefreshLabel: string;
  lastRefreshIso?: string;
  archivedCycles: MonthlyResultArchive[];
}

export function getMonthEndDateTime(year: number, monthIndex: number): Date {
  // Day 0 of next month gives the exact last day of `monthIndex` (28/29/30/31) at 23:55:00
  return new Date(year, monthIndex + 1, 0, 23, 55, 0, 0);
}

export function getNextMonthEndRefreshDate(now: Date = new Date()): Date {
  const thisMonthEnd = getMonthEndDateTime(now.getFullYear(), now.getMonth());
  if (now.getTime() < thisMonthEnd.getTime()) {
    return thisMonthEnd;
  }
  return getMonthEndDateTime(now.getFullYear(), now.getMonth() + 1);
}

export function getDueResultCycleKey(now: Date = new Date()): string {
  const thisMonthEnd = getMonthEndDateTime(now.getFullYear(), now.getMonth());
  if (now.getTime() >= thisMonthEnd.getTime()) {
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  }
  const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${prev.getFullYear()}-${String(prev.getMonth() + 1).padStart(2, '0')}`;
}

export interface AppBootstrapData {
  tests: MockTest[];
  bundles: TestBundle[];
  exams: string[];
  subjects: string[];
  results: TestResultEntry[];
  coupons: Coupon[];
  payments: PaymentOrder[];
  dailyQuizzes: DailyQuiz[];
  updates: ExamUpdate[];
  syllabi: SyllabusDoc[];
  supportTickets: SupportTicket[];
  reportedQuestions: ReportedQuestion[];
  settings: AppSettings;
  traffic: TrafficStats;
  resultCycle?: ResultCycleInfo;
  students?: UserProfile[]; // returned for admin view
}
