import { useCallback, useEffect, useRef, useState } from 'react';
import type { AppBootstrapData, UserProfile } from './types';
import { apiFetch, getStoredSession, setStoredSession } from './lib/api';
import { StudentPortal } from './components/StudentPortal';
import { AdminPanel } from './components/AdminPanel';
import { OfflineIndicator } from './components/OfflineIndicator';

function isAdminPath(): boolean {
  return window.location.pathname === '/admin' || window.location.hash === '#admin';
}

export default function App() {
  const [data, setData] = useState<AppBootstrapData | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [mode, setMode] = useState<'student' | 'admin'>(isAdminPath() ? 'admin' : 'student');
  const [dark, setDark] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('exampro_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });
  const [kickedAlert, setKickedAlert] = useState(false);
  const [toast, setToast] = useState('');
  const [loadError, setLoadError] = useState('');

  const userRef = useRef<UserProfile | null>(null);
  userRef.current = user;

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast((cur) => (cur === msg ? '' : cur));
    }, 2800);
  }, []);

  // Sync Tailwind dark class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add('dark');
    else root.classList.remove('dark');
    try {
      localStorage.setItem('exampro_theme', dark ? 'dark' : 'light');
    } catch {
      // ignore
    }
  }, [dark]);

  // Listen to URL changes for /admin or #admin
  useEffect(() => {
    const onPop = () => {
      setMode(isAdminPath() ? 'admin' : 'student');
    };
    window.addEventListener('popstate', onPop);
    window.addEventListener('hashchange', onPop);
    return () => {
      window.removeEventListener('popstate', onPop);
      window.removeEventListener('hashchange', onPop);
    };
  }, []);

  const loadBootstrap = useCallback(async () => {
    try {
      const res = await apiFetch<{
        data: AppBootstrapData;
        user: UserProfile | null;
        sessionInvalid?: boolean;
      }>('/api/bootstrap');
      setData(res.data);
      if (res.sessionInvalid) {
        setStoredSession(null);
        setUser(null);
        setKickedAlert(true);
      } else {
        setUser(res.user);
      }
      setLoadError('');
    } catch (err: unknown) {
      setLoadError(err instanceof Error ? err.message : 'Unable to connect to ExamPro server.');
    }
  }, []);

  useEffect(() => {
    loadBootstrap();
  }, [loadBootstrap]);

  // Real-time SSE Sync + Single-Device Lock Enforcement
  useEffect(() => {
    const session = getStoredSession();
    const qs = session
      ? `?userId=${session.userId}&token=${encodeURIComponent(session.sessionToken || '')}`
      : '';
    const es = new EventSource(`/api/stream${qs}`);

    es.addEventListener('data_updated', () => {
      loadBootstrap();
    });

    es.addEventListener('session_revoked', (ev) => {
      try {
        const payload = JSON.parse(ev.data) as { userId: number; activeToken: string };
        const current = userRef.current;
        const stored = getStoredSession();
        if (
          current &&
          current.role === 'student' &&
          current.id === payload.userId &&
          stored?.sessionToken !== payload.activeToken
        ) {
          setStoredSession(null);
          setUser(null);
          setKickedAlert(true);
          setMode('student');
        }
      } catch {
        // ignore parse errors
      }
    });

    return () => {
      es.close();
    };
  }, [loadBootstrap, user?.id, user?.sessionToken]);

  const handleLoginSuccess = (loggedInUser: UserProfile) => {
    setStoredSession({
      userId: loggedInUser.id,
      sessionToken: loggedInUser.sessionToken,
    });
    setUser(loggedInUser);
    setKickedAlert(false);
    loadBootstrap();
  };

  const handleLogout = () => {
    setStoredSession(null);
    setUser(null);
    setMode('student');
    if (isAdminPath()) {
      window.history.pushState({}, '', '/');
    }
  };

  const switchMode = (next: 'student' | 'admin') => {
    setMode(next);
    if (next === 'admin') {
      window.history.pushState({}, '', '/admin');
    } else {
      window.history.pushState({}, '', '/');
    }
  };

  if (loadError && !data) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-6 text-center">
        <div className="max-w-sm space-y-3">
          <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
            ExamPro Connection Issue
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">{loadError}</p>
          <button
            type="button"
            onClick={loadBootstrap}
            className="rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white cursor-pointer"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-6">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold">
            🎓
          </div>
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
            Loading ExamPro...
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      {mode === 'admin' ? (
        <AdminPanel
          data={data}
          user={user}
          onBackToStudent={() => switchMode('student')}
          onAdminAuthenticated={(adminUser) => {
            handleLoginSuccess(adminUser);
          }}
          onRefreshData={loadBootstrap}
          onToast={showToast}
        />
      ) : (
        <StudentPortal
          data={data}
          user={user}
          dark={dark}
          kickedAlert={kickedAlert}
          onToggleTheme={() => setDark((d) => !d)}
          onDismissKicked={() => setKickedAlert(false)}
          onLoginSuccess={handleLoginSuccess}
          onUserUpdate={(updated) => setUser(updated)}
          onLogout={handleLogout}
          onOpenAdmin={() => switchMode('admin')}
          onToast={showToast}
          onRefreshData={loadBootstrap}
        />
      )}

      <OfflineIndicator />

      {toast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-[60] rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-2.5 text-xs font-semibold shadow-xl">
          {toast}
        </div>
      )}
    </>
  );
}
