import fs from 'fs';
import path from 'path';
import type {
  AppBootstrapData,
  AppSettings,
  Coupon,
  DailyQuiz,
  ExamUpdate,
  MockTest,
  MonthlyResultArchive,
  PaymentOrder,
  Question,
  ReportedQuestion,
  ResultCycleInfo,
  SupportTicket,
  SyllabusDoc,
  TestBundle,
  TestResultEntry,
  UserProfile,
} from '../src/types.ts';
import {
  DEFAULT_SUBJECTS,
  JK_DISTRICTS,
  getDueResultCycleKey,
  getNextMonthEndRefreshDate,
} from '../src/types.ts';

export interface UserRecord extends UserProfile {
  password?: string;
}

export interface DatabaseState {
  tests: MockTest[];
  bundles: TestBundle[];
  exams: string[];
  subjects: string[];
  results: TestResultEntry[];
  archivedResults: MonthlyResultArchive[];
  lastResultCycleKey: string;
  lastResultResetAt?: string;
  coupons: Coupon[];
  payments: PaymentOrder[];
  dailyQuizzes: DailyQuiz[];
  updates: ExamUpdate[];
  syllabi: SyllabusDoc[];
  supportTickets: SupportTicket[];
  reportedQuestions: ReportedQuestion[];
  settings: AppSettings;
  users: UserRecord[];
  visitorIds: string[];
  totalVisitors: number;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

function makeDefaultQrSvgDataUri(upiId: string, payee: string): string {
  // Deterministic crisp vector QR pattern placeholder so QR displays cleanly before custom upload
  const cells = 21;
  let rects = '';
  let hash = 0;
  const seed = `${upiId}|${payee}`;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  }
  const isFinder = (r: number, c: number) =>
    (r < 7 && c < 7) || (r < 7 && c >= cells - 7) || (r >= cells - 7 && c < 7);

  for (let r = 0; r < cells; r++) {
    for (let c = 0; c < cells; c++) {
      let dark = false;
      if (isFinder(r, c)) {
        const lr = r >= cells - 7 ? r - (cells - 7) : r;
        const lc = c >= cells - 7 ? c - (cells - 7) : c;
        dark =
          lr === 0 ||
          lr === 6 ||
          lc === 0 ||
          lc === 6 ||
          (lr >= 2 && lr <= 4 && lc >= 2 && lc <= 4);
      } else if (r === 6 || c === 6) {
        dark = (r + c) % 2 === 0;
      } else {
        const v = (hash ^ (r * 73856093) ^ (c * 19349663)) >>> 0;
        dark = v % 11 < 5;
      }
      if (dark) {
        rects += `<rect x="${20 + c * 8}" y="${20 + r * 8}" width="8" height="8" fill="#0f172a"/>`;
      }
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 208 208" width="208" height="208"><rect width="208" height="208" rx="12" fill="#ffffff"/>${rects}</svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function makePdfDataUri(title: string, exam: string, topics: string[]): string {
  // Minimal valid single-page PDF containing readable exam syllabus text
  const lines = [title, `Exam: ${exam}`, 'Official Syllabus Summary:', ...topics.map((t, i) => `${i + 1}. ${t}`)];
  const escaped = lines.map((l) => l.replace(/[()\\]/g, '\\$&'));
  const textOps = escaped.map((l, idx) => `BT /F1 ${idx === 0 ? 15 : 11} Tf 50 ${750 - idx * 24} Td (${l}) Tj ET`).join('\n');
  const stream = textOps;
  const objects = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj',
    `4 0 obj << /Length ${Buffer.byteLength(stream, 'utf8')} >> stream\n${stream}\nendstream endobj`,
    '5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj',
  ];
  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [];
  for (const obj of objects) {
    offsets.push(Buffer.byteLength(pdf, 'utf8'));
    pdf += obj + '\n';
  }
  const xrefPos = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (const off of offsets) {
    pdf += String(off).padStart(10, '0') + ' 00000 n \n';
  }
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;
  return `data:application/pdf;base64,${Buffer.from(pdf, 'utf8').toString('base64')}`;
}

const SAMPLE_QS: Question[] = [
  {
    id: 'q-101',
    t: 'Which river is known as the lifeline of the Kashmir Valley?',
    o: ['Chenab', 'Jhelum', 'Ravi', 'Tawi'],
    c: 1,
    e: 'The Jhelum (anciently Vitasta) originates at Verinag and flows through the Kashmir Valley.',
    subj: 'J&K General Knowledge',
    src: 'manual',
    examRef: ['JKSSB 2024', 'JKP SI 2023'],
  },
  {
    id: 'q-102',
    t: 'Which mountain pass connects Srinagar with Leh in Ladakh?',
    o: ['Banihal Pass', 'Zoji La', 'Khardung La', 'Pir Panjal Pass'],
    c: 1,
    e: 'Zoji La is a high mountain pass on NH-1 connecting Kashmir Valley with Dras and Leh.',
    subj: 'Geography',
    src: 'manual',
    examRef: ['JKSSB 2023'],
  },
  {
    id: 'q-103',
    t: 'Who authored the 12th-century Sanskrit chronicle of Kashmir, Rajatarangini?',
    o: ['Kalhana', 'Bilhana', 'Jonaraja', 'Abhinavagupta'],
    c: 0,
    e: 'Kalhana composed Rajatarangini ("River of Kings") between 1148 and 1150 CE.',
    subj: 'History',
    src: 'manual',
    examRef: ['JKPSC KAS 2023', 'JKSSB 2024'],
  },
  {
    id: 'q-104',
    t: 'The Hangul (Kashmir Stag) is critically conserved in which National Park?',
    o: ['Dachigam National Park', 'Kishtwar National Park', 'Salim Ali National Park', 'Kazinag National Park'],
    c: 0,
    e: 'Dachigam National Park near Srinagar is the primary protected habitat of the Kashmir Stag.',
    subj: 'J&K General Knowledge',
    src: 'manual',
    examRef: ['JKP Constable 2024'],
  },
  {
    id: 'q-105',
    t: 'In which year was the Jammu and Kashmir Reorganisation Act enacted by Parliament?',
    o: ['2017', '2018', '2019', '2020'],
    c: 2,
    e: 'The J&K Reorganisation Act was passed in August 2019 and took effect on 31 October 2019.',
    subj: 'Indian Polity',
    src: 'manual',
    examRef: ['JKSSB VLW 2024'],
  },
  {
    id: 'q-106',
    t: 'Choose the correct synonym of "METICULOUS":',
    o: ['Careless', 'Thorough', 'Hasty', 'Vague'],
    c: 1,
    e: '"Meticulous" means showing great attention to detail; thorough and precise.',
    subj: 'English',
    src: 'manual',
  },
  {
    id: 'q-107',
    t: 'If a train 180 m long passes a pole in 9 seconds, what is its speed in km/h?',
    o: ['60 km/h', '72 km/h', '80 km/h', '64 km/h'],
    c: 1,
    e: 'Speed = 180 / 9 = 20 m/s = 20 × (18/5) = 72 km/h.',
    subj: 'Math',
    src: 'manual',
    examRef: ['JKSSB FAA 2024'],
  },
  {
    id: 'q-108',
    t: 'Which shortcut key in MS Excel opens the "Format Cells" dialog box?',
    o: ['Ctrl + 1', 'Ctrl + F', 'Ctrl + Shift + F', 'Alt + F1'],
    c: 0,
    e: 'Pressing Ctrl + 1 opens the Format Cells dialog box in Microsoft Excel.',
    subj: 'Computer',
    src: 'manual',
    examRef: ['JKSSB JA 2024'],
  },
];

const DAILY_10_QS: Question[] = [
  {
    id: 'dq-1',
    t: 'Which J&K wetland was recently highlighted for winter migratory bird conservation in Budgam?',
    o: ['Hokersar Wetland', 'Gharana Wetland', 'Hygam Wetland', 'Surinsar Lake'],
    c: 0,
    e: 'Hokersar Wetland near Srinagar/Budgam border hosts lakhs of migratory waterfowl every winter.',
    subj: 'Current Affairs',
    examRef: ['JKSSB 2025'],
  },
  {
    id: 'dq-2',
    t: 'The Chenab Rail Bridge, the world’s highest railway arch bridge, is located in which J&K district?',
    o: ['Ramban', 'Reasi', 'Doda', 'Udhampur'],
    c: 1,
    e: 'The Chenab Rail Bridge spans the Chenab River between Bakkal and Kauri in Reasi district.',
    subj: 'Current Affairs',
    examRef: ['JKPSC 2024'],
  },
  {
    id: 'dq-3',
    t: 'Which GI-tagged spice of Pampore is celebrated during the autumn harvest festival in Pulwama?',
    o: ['Black Cumin', 'Kashmir Saffron (Kong)', 'Cardamom', 'Turmeric'],
    c: 1,
    e: 'Pampore saffron received the Geographical Indication (GI) tag for its unique crocin content.',
    subj: 'J&K General Knowledge',
  },
  {
    id: 'dq-4',
    t: 'Which tunnel provides all-weather rail connectivity on the Banihal-Katra section of USBRL?',
    o: ['T-49 Tunnel', 'Z-Morh Tunnel', 'Chenani-Nashri Tunnel', 'Jawahar Tunnel'],
    c: 0,
    e: 'Tunnel T-49 (12.75 km) on the USBRL project is India’s longest transportation railway tunnel.',
    subj: 'Current Affairs',
  },
  {
    id: 'dq-5',
    t: 'The Z-Morh Tunnel inaugurated on the Srinagar-Leh highway connects Gagangir with:',
    o: ['Dras', 'Sonamarg', 'Kargil', 'Gurez'],
    c: 1,
    e: 'Z-Morh Tunnel ensures all-weather connectivity between Gagangir and Sonamarg in Ganderbal.',
    subj: 'Geography',
  },
  {
    id: 'dq-6',
    t: 'Which traditional Kashmiri willow craft received GI recognition for cricket bat manufacturing?',
    o: ['Sangam Kashmir Willow', 'Anantnag Paper Mache', 'Budgam Kani Shawl', 'Sopore Walnut Wood'],
    c: 0,
    e: 'Sangam and Bijbehara in Anantnag are hubs of Kashmir Willow cricket bats.',
    subj: 'J&K General Knowledge',
  },
  {
    id: 'dq-7',
    t: 'Who built the iconic Martand Sun Temple near Anantnag in the 8th century CE?',
    o: ['Avantivarman', 'Lalitaditya Muktapida', 'Durlabhavardhana', 'Harsha'],
    c: 1,
    e: 'Emperor Lalitaditya Muktapida of the Karkota dynasty constructed the Martand Sun Temple.',
    subj: 'History',
    examRef: ['JKPSC KAS 2024'],
  },
  {
    id: 'dq-8',
    t: 'Under the Indian Constitution, which Article grants power to the High Court to issue writs?',
    o: ['Article 32', 'Article 136', 'Article 226', 'Article 227'],
    c: 2,
    e: 'Article 226 empowers High Courts to issue writs for fundamental and legal rights.',
    subj: 'Indian Polity',
  },
  {
    id: 'dq-9',
    t: 'Which statement accurately describes the Ratle Hydroelectric Project in J&K?',
    o: ['Built on Jhelum in Baramulla', 'Built on Chenab in Kishtwar', 'Built on Ravi in Kathua', 'Built on Indus in Leh'],
    c: 1,
    e: 'The 850 MW Ratle Hydroelectric Project is constructed on the Chenab River in Kishtwar.',
    subj: 'Geography',
  },
  {
    id: 'dq-10',
    t: 'Find the missing number in the series: 5, 11, 23, 47, ?',
    o: ['91', '94', '95', '96'],
    c: 2,
    e: 'Pattern is ×2 + 1: 5×2+1=11, 11×2+1=23, 23×2+1=47, 47×2+1=95.',
    subj: 'Reasoning',
  },
];

function buildInitialSeed(): DatabaseState {
  const today = new Date().toISOString().slice(0, 10);
  const exams = [
    'JKSSB Junior Assistant',
    'JKSSB Naib Tehsildar',
    'JKSSB Constable',
    'JKSSB Accounts Assistant',
    'JKP Sub-Inspector',
    'JKPSC CCE (KAS)',
    'JK Bank',
    'JKBOSE Class 12',
    'NEET',
    'JEE Main',
    'CUET',
    'Other',
  ];

  const tests: MockTest[] = [
    {
      id: 1,
      cat: 'latest',
      exam: 'JKSSB Junior Assistant',
      title: 'JKSSB Junior Assistant Full Mock 01',
      testType: 'full',
      paid: true,
      price: 99,
      dur: 60,
      neg: 0.25,
      sched: '2026-11-14T09:00',
      status: 'live',
      desc: 'Full-length CBT mock covering J&K GK, General English, Quantitative Aptitude, Reasoning, and Computer Awareness as per latest JKSSB syllabus.',
      syllabusTag: 'J&K GK · English · Math · Computer',
      language: 'English',
      attemptCount: 1420,
      bundleId: 1,
      qs: SAMPLE_QS,
    },
    {
      id: 2,
      cat: 'popular',
      exam: 'JKSSB Constable',
      title: 'JKP Constable Recruitment Mock 03',
      testType: 'full',
      paid: true,
      price: 79,
      dur: 45,
      neg: 0.25,
      sched: '2026-11-13T18:00',
      status: 'live',
      desc: 'High-yield J&K Police Constable paper with special focus on J&K Geography, History, and Numerical Ability.',
      syllabusTag: 'GK · J&K Special · Reasoning',
      language: 'English',
      attemptCount: 2150,
      bundleId: 3,
      qs: SAMPLE_QS.slice(0, 6),
    },
    {
      id: 3,
      cat: 'upcoming',
      exam: 'JKPSC CCE (KAS)',
      title: 'JKPSC KAS Prelims GS Paper I — Mega Mock',
      testType: 'full',
      paid: true,
      price: 149,
      dur: 120,
      neg: 0.33,
      sched: '2026-11-22T10:00',
      status: 'scheduled',
      desc: 'Statewide All-J&K Prelims Mock following UPSC/JKPSC assertion-reason and analytical pattern.',
      syllabusTag: 'Polity · History · Economy · J&K',
      language: 'English',
      attemptCount: 890,
      bundleId: 2,
      qs: SAMPLE_QS,
    },
    {
      id: 4,
      cat: 'mega',
      exam: 'JKSSB Naib Tehsildar',
      title: 'Sunday All-J&K Naib Tehsildar Live Mega Mock',
      testType: 'full',
      paid: false,
      price: 0,
      dur: 90,
      neg: 0.25,
      sched: '2026-11-14T08:00',
      status: 'live',
      desc: 'Compete live with aspirants from all 20 districts of Jammu & Kashmir for District #1 Rank.',
      syllabusTag: 'Revenue · J&K GK · Urdu/English',
      language: 'English',
      attemptCount: 3480,
      bundleId: 1,
      qs: SAMPLE_QS,
    },
    {
      id: 5,
      cat: 'free',
      exam: 'JKSSB Junior Assistant',
      title: 'J&K Heritage, Rivers & Passes Free Practice',
      testType: 'sectional',
      subject: 'J&K General Knowledge',
      paid: false,
      price: 0,
      dur: 15,
      neg: 0,
      sched: '2026-11-10T09:00',
      status: 'live',
      desc: 'Quick free practice test on Jammu & Kashmir physical geography, lakes, and mountain passes.',
      syllabusTag: 'Geography & Heritage of J&K',
      language: 'English',
      attemptCount: 1860,
      bundleId: 1,
      qs: SAMPLE_QS.slice(0, 5),
    },
    {
      id: 6,
      cat: 'pyqs',
      exam: 'JKSSB Accounts Assistant',
      title: 'JKSSB FAA 2024 Official Memory-Based PYQ',
      testType: 'full',
      paid: false,
      price: 0,
      dur: 45,
      neg: 0.25,
      sched: '2026-11-11T09:00',
      status: 'live',
      desc: 'Actual solved Previous Year Questions asked in JKSSB Finance Accounts Assistant with crisp explanations.',
      syllabusTag: 'PYQ 2024 · J&K GK · Math · Computer',
      language: 'English',
      attemptCount: 2740,
      bundleId: 1,
      qs: SAMPLE_QS,
    },
    {
      id: 7,
      cat: 'jk_special',
      exam: 'JKPSC CCE (KAS)',
      title: 'History & Culture of Jammu & Kashmir (Rajatarangini to 1947)',
      testType: 'sectional',
      subject: 'History',
      paid: true,
      price: 49,
      dur: 25,
      neg: 0.25,
      sched: '2026-11-12T10:00',
      status: 'live',
      desc: 'Focused J&K History sectional test covering Karkota, Utpala, Shah Mir, Mughal, and Dogra dynasties.',
      syllabusTag: 'J&K History · Art & Architecture',
      language: 'English',
      attemptCount: 640,
      bundleId: 2,
      qs: SAMPLE_QS.slice(0, 5),
    },
    {
      id: 8,
      cat: 'sectional',
      exam: 'JKSSB Junior Assistant',
      title: 'Computer Awareness & MS Office Sectional Drill',
      testType: 'sectional',
      subject: 'Computer',
      paid: true,
      price: 39,
      dur: 20,
      neg: 0.25,
      sched: '2026-11-12T12:00',
      status: 'live',
      desc: 'Master keyboard shortcuts, hardware, networking, and OS questions frequently asked in JKSSB.',
      syllabusTag: 'MS Office · Networking · Shortcuts',
      language: 'English',
      attemptCount: 910,
      bundleId: 1,
      qs: [SAMPLE_QS[7], SAMPLE_QS[4], SAMPLE_QS[5], SAMPLE_QS[6]],
    },
    {
      id: 9,
      cat: 'sectional',
      exam: 'JKP Sub-Inspector',
      title: 'Quantitative Aptitude & Reasoning Booster',
      testType: 'sectional',
      subject: 'Math',
      paid: false,
      price: 0,
      dur: 20,
      neg: 0.25,
      sched: '2026-11-13T10:00',
      status: 'live',
      desc: 'Speed & accuracy drill on time-speed-distance, percentages, and number series.',
      syllabusTag: 'Arithmetic · Number Series',
      language: 'English',
      attemptCount: 1120,
      bundleId: 3,
      qs: [SAMPLE_QS[6], DAILY_10_QS[9], SAMPLE_QS[0], SAMPLE_QS[1]],
    },
  ];

  const bundles: TestBundle[] = [
    {
      id: 1,
      title: 'JKSSB All-in-One Target Bundle 2026',
      exam: 'JKSSB Junior Assistant',
      desc: 'Complete preparation pack combining Full-Length JKSSB Mocks, Official PYQs, and Subject-wise Sectional Tests (J&K GK, Computer, English, Math).',
      price: 199,
      mrp: 499,
      validity: '6 Months',
      bundleOnly: false,
      testIds: [1, 4, 5, 6, 8],
      featured: true,
    },
    {
      id: 2,
      title: 'JKPSC KAS Prelims Master Series',
      exam: 'JKPSC CCE (KAS)',
      desc: 'High-standard GS Paper I Full-Length Mocks plus dedicated J&K History, Polity & Geography Sectional Tests.',
      price: 299,
      mrp: 699,
      validity: '12 Months',
      bundleOnly: false,
      testIds: [3, 7],
      featured: true,
    },
    {
      id: 3,
      title: 'J&K Police Constable & SI Power Pack',
      exam: 'JKSSB Constable',
      desc: 'Curated full mocks and Quantitative/Reasoning speed drills tailored for JKP Constable & SI aspirants.',
      price: 149,
      mrp: 349,
      validity: '6 Months',
      bundleOnly: false,
      testIds: [2, 9],
      featured: false,
    },
  ];

  const sampleStudents: Array<{ name: string; district: string; exam: string; score: number; timeSec: number }> = [
    { name: 'Aarif Mir', district: 'Budgam', exam: 'JKSSB Junior Assistant', score: 31, timeSec: 740 },
    { name: 'Sana Bhat', district: 'Srinagar', exam: 'JKPSC CCE (KAS)', score: 32, timeSec: 695 },
    { name: 'Rohit Sharma', district: 'Jammu', exam: 'JKP Sub-Inspector', score: 30, timeSec: 780 },
    { name: 'Mehvish Qadri', district: 'Anantnag', exam: 'JKSSB Naib Tehsildar', score: 29.5, timeSec: 810 },
    { name: 'Tanveer Ahmad', district: 'Baramulla', exam: 'JKSSB Constable', score: 28, timeSec: 850 },
    { name: 'Anjali Gupta', district: 'Kathua', exam: 'JK Bank', score: 27.5, timeSec: 870 },
    { name: 'Ishfaq Wani', district: 'Pulwama', exam: 'JKSSB Accounts Assistant', score: 27, timeSec: 910 },
    { name: 'Simran Kour', district: 'Samba', exam: 'JKSSB Junior Assistant', score: 26, timeSec: 930 },
    { name: 'Zubair Dar', district: 'Kupwara', exam: 'JKP Sub-Inspector', score: 25.5, timeSec: 960 },
    { name: 'Priya Raina', district: 'Udhampur', exam: 'JKPSC CCE (KAS)', score: 25, timeSec: 990 },
    { name: 'Umar Lone', district: 'Bandipora', exam: 'JKSSB Constable', score: 24, timeSec: 1010 },
    { name: 'Neha Kumari', district: 'Reasi', exam: 'JKBOSE Class 12', score: 23, timeSec: 1040 },
    { name: 'Faizan Malik', district: 'Ganderbal', exam: 'JKSSB Naib Tehsildar', score: 26.5, timeSec: 880 },
    { name: 'Shazia Akhter', district: 'Shopian', exam: 'JKSSB Junior Assistant', score: 24.5, timeSec: 950 },
    { name: 'Adil Rather', district: 'Kulgam', exam: 'JKSSB Constable', score: 22.5, timeSec: 1020 },
  ];

  const adminUser: UserRecord = {
    id: 1,
    email: 'JUMEE89@GMAIL.COM',
    phone: '9906101048',
    name: 'Ahmad Junaid (Admin)',
    district: 'Srinagar',
    exam: 'JKPSC CCE (KAS)',
    role: 'admin',
    password: '12345',
    sessionToken: null,
    ownedTestIds: [1, 2, 3, 7, 8],
    ownedBundleIds: [1, 2, 3],
    mistakes: [],
    bookmarks: [],
    attempts: [],
    dailyStreak: 4,
    joinedAt: '2026-10-01',
    lastActiveDate: today,
  };

  const studentUsers: UserRecord[] = sampleStudents.map((s, idx) => {
    const slug = s.name.toLowerCase().replace(/[^a-z]+/g, '.');
    return {
      id: idx + 2,
      email: `${slug}@gmail.com`,
      phone: '9' + String(800000000 + idx * 7123456).slice(0, 9).padStart(9, '0'),
      name: s.name,
      district: s.district,
      exam: s.exam,
      role: 'student',
      password: 'student123',
      sessionToken: null,
      ownedTestIds: idx === 0 ? [2] : idx === 1 ? [1, 7] : [],
      ownedBundleIds: [],
      mistakes: idx === 0 ? [
        {
          id: 'm-seed-1',
          t: SAMPLE_QS[2].t,
          o: SAMPLE_QS[2].o,
          c: SAMPLE_QS[2].c,
          sel: 2,
          e: SAMPLE_QS[2].e,
          subj: SAMPLE_QS[2].subj,
          testTitle: 'JKSSB Junior Assistant Full Mock 01',
          examRef: SAMPLE_QS[2].examRef,
          addedAt: '12 Nov 2026',
        },
      ] : [],
      bookmarks: [],
      attempts: [
        {
          id: `att-seed-${idx}`,
          testId: 1,
          testTitle: 'JKSSB Junior Assistant Full Mock 01',
          score: s.score,
          maxScore: 32,
          correct: Math.floor(s.score / 4),
          wrong: idx % 3,
          skipped: 8 - Math.floor(s.score / 4) - (idx % 3),
          rank: idx + 1,
          totalParticipants: sampleStudents.length,
          districtRank: 1,
          districtTotal: 1,
          percentile: Math.round(((sampleStudents.length - idx) / sampleStudents.length) * 100),
          date: '12 Nov 2026',
        },
      ],
      dailyStreak: (idx % 6) + 1,
      joinedAt: '2026-11-02',
      lastActiveDate: idx < 9 ? today : '2026-11-10',
    };
  });

  const results: TestResultEntry[] = sampleStudents.map((s, idx) => ({
    id: `res-seed-1-${idx}`,
    testId: 1,
    userId: idx + 2,
    name: s.name,
    district: s.district,
    targetExam: s.exam,
    score: s.score,
    maxScore: 32,
    correct: Math.floor(s.score / 4),
    wrong: idx % 3,
    skipped: Math.max(0, 8 - Math.floor(s.score / 4) - (idx % 3)),
    timeSec: s.timeSec,
    subjectBreakdown: {
      'J&K General Knowledge': { correct: 2, total: 2 },
      History: { correct: idx % 2 === 0 ? 1 : 0, total: 1 },
      Geography: { correct: 1, total: 1 },
      English: { correct: 1, total: 1 },
      Math: { correct: idx < 6 ? 1 : 0, total: 1 },
      Computer: { correct: 1, total: 1 },
      'Indian Polity': { correct: 1, total: 1 },
    },
    date: '12 Nov 2026',
  }));

  // Also seed Mega Mock #4 results for more districts
  JK_DISTRICTS.slice(0, 12).forEach((dist, i) => {
    const stu = studentUsers[i % studentUsers.length];
    results.push({
      id: `res-seed-4-${i}`,
      testId: 4,
      userId: stu.id,
      name: stu.name,
      district: dist,
      targetExam: stu.exam,
      score: Math.max(12, 30 - i),
      maxScore: 32,
      correct: Math.max(3, 7 - Math.floor(i / 3)),
      wrong: i % 2,
      skipped: 0,
      timeSec: 640 + i * 25,
      subjectBreakdown: { 'J&K General Knowledge': { correct: 2, total: 2 } },
      date: '14 Nov 2026',
    });
  });

  const coupons: Coupon[] = [
    {
      id: 'cp-1',
      code: 'JKFREE100',
      type: 'free',
      value: 100,
      maxUses: 100,
      usedCount: 4,
      expiryDate: '2026-12-31',
      active: true,
    },
    {
      id: 'cp-2',
      code: 'KAS50',
      type: 'percent',
      value: 50,
      maxUses: 200,
      usedCount: 12,
      expiryDate: '2026-12-31',
      active: true,
    },
    {
      id: 'cp-3',
      code: 'SAVE30',
      type: 'flat',
      value: 30,
      maxUses: 500,
      usedCount: 18,
      expiryDate: '2026-12-31',
      active: true,
    },
  ];

  const payments: PaymentOrder[] = [
    {
      id: 'pay-1',
      orderNumber: 'EXP-8412',
      userId: 2,
      userName: 'Aarif Mir',
      userPhone: '9800000000',
      itemType: 'test',
      itemId: 2,
      itemTitle: 'JKP Constable Recruitment Mock 03',
      originalAmount: 79,
      discountAmount: 0,
      finalAmount: 79,
      utrNumber: '431829405112',
      paymentMethod: 'UPI',
      status: 'PAID',
      createdAt: '10 Nov 2026, 6:20 PM',
      verifiedAt: '10 Nov 2026, 6:24 PM',
    },
    {
      id: 'pay-2',
      orderNumber: 'EXP-8499',
      userId: 4,
      userName: 'Rohit Sharma',
      userPhone: '9814246912',
      itemType: 'bundle',
      itemId: 1,
      itemTitle: 'JKSSB All-in-One Target Bundle 2026',
      originalAmount: 199,
      discountAmount: 30,
      finalAmount: 169,
      couponCode: 'SAVE30',
      utrNumber: '431955018274',
      paymentMethod: 'UPI',
      status: 'PENDING_VERIFICATION',
      createdAt: '14 Nov 2026, 9:40 AM',
    },
  ];

  const dailyQuizzes: DailyQuiz[] = [
    {
      id: `dq-${today}`,
      date: today,
      title: 'Daily 10-Question J&K Current Affairs & GK',
      questions: DAILY_10_QS,
    },
  ];

  const updates: ExamUpdate[] = [
    {
      id: 'upd-1',
      type: 'exam_date',
      title: 'JKSSB Junior Assistant CBT Exam Schedule Announced',
      exam: 'JKSSB Junior Assistant',
      message: 'Tentative CBT examination window starts from 28 Nov 2026 across Srinagar & Jammu centres. Complete Mock 01 & PYQs now.',
      examDate: '2026-11-28',
      createdAt: '14 Nov 2026',
    },
    {
      id: 'upd-2',
      type: 'admit_card',
      title: 'JKP Constable Admit Card Download Portal Update',
      exam: 'JKSSB Constable',
      message: 'Candidates can download their e-admit cards 7 days prior to the examination date via JKSSB official portal.',
      examDate: '2026-12-06',
      createdAt: '13 Nov 2026',
    },
    {
      id: 'upd-3',
      type: 'alert',
      title: 'Sunday All-J&K Free Live Mega Mock Open!',
      exam: 'JKSSB Naib Tehsildar',
      message: 'Attempt the free All-J&K Mega Mock before 9 PM tonight to qualify for the District Toppers Hall of Fame.',
      createdAt: '14 Nov 2026',
    },
  ];

  const syllabi: SyllabusDoc[] = [
    {
      id: 'syl-1',
      exam: 'JKSSB Junior Assistant',
      title: 'JKSSB Junior Assistant Official CBT Syllabus (80 Marks)',
      summary: 'General English (20), General Awareness with special reference to J&K (20), Numerical & Reasoning Ability (20), Basic Concepts of Computers (20).',
      pdfUrl: makePdfDataUri('JKSSB Junior Assistant Syllabus', 'JKSSB Junior Assistant', [
        'General English & Comprehension - 20 Marks',
        'General Awareness with Special Reference to J&K UT - 20 Marks',
        'Numerical & Reasoning Ability - 20 Marks',
        'Basic Concepts of Computers & MS Office - 20 Marks',
      ]),
      fileName: 'JKSSB_Junior_Assistant_Syllabus.pdf',
      uploadedAt: '05 Nov 2026',
    },
    {
      id: 'syl-2',
      exam: 'JKPSC CCE (KAS)',
      title: 'JKPSC Combined Competitive Prelims (GS Paper I & II)',
      summary: 'Current Events, History of India & J&K, Indian & World Geography, Indian Polity, Economic & Social Development, Ecology & CSAT.',
      pdfUrl: makePdfDataUri('JKPSC CCE KAS Prelims Syllabus', 'JKPSC CCE (KAS)', [
        'Current Events of National & International Importance',
        'History of India, Indian National Movement & J&K Heritage',
        'Indian & World Geography + Physical Geography of J&K',
        'Indian Polity, Governance, Constitution & Public Policy',
      ]),
      fileName: 'JKPSC_KAS_Prelims_Syllabus.pdf',
      uploadedAt: '02 Nov 2026',
    },
    {
      id: 'syl-3',
      exam: 'JKSSB Constable',
      title: 'J&K Police Constable Written Exam Syllabus',
      summary: 'General Knowledge & J&K Special Paper, Elementary Mathematics, Analytical Aptitude & Reasoning.',
      pdfUrl: makePdfDataUri('JKP Constable Syllabus', 'JKSSB Constable', [
        'General Knowledge & Current Affairs (J&K Special)',
        'Elementary Mathematics & Mensuration',
        'Analytical Aptitude & Logical Reasoning',
        'General Science & Basic English',
      ]),
      fileName: 'JKP_Constable_Syllabus.pdf',
      uploadedAt: '01 Nov 2026',
    },
  ];

  const supportTickets: SupportTicket[] = [
    {
      id: 'tic-1',
      userId: 4,
      userName: 'Rohit Sharma',
      userPhone: '9814246912',
      userEmail: 'rohit.sharma@gmail.com',
      orderId: 'EXP-8499',
      subject: 'UPI UTR Submitted for JKSSB Bundle',
      message: 'Paid ₹169 via GPay using coupon SAVE30. Please verify UTR 431955018274 and unlock the bundle.',
      status: 'pending',
      createdAt: '14 Nov 2026, 9:42 AM',
    },
  ];

  const reportedQuestions: ReportedQuestion[] = [
    {
      id: 'rep-1',
      testId: 1,
      testTitle: 'JKSSB Junior Assistant Full Mock 01',
      questionId: 'q-105',
      questionText: 'In which year was the Jammu and Kashmir Reorganisation Act enacted by Parliament?',
      reporterId: 2,
      reporterName: 'Aarif Mir',
      reason: 'Please add exact effective date (31 October 2019) in explanation as well.',
      status: 'pending',
      createdAt: '13 Nov 2026, 4:15 PM',
    },
  ];

  const settings: AppSettings = {
    adminEmail: 'JUMEE89@GMAIL.COM',
    adminPhone: '9906101048',
    whatsappSupportNumber: '919906101048',
    whatsappSupportMessage: 'Hi ExamPro Team, I need help with my mock test account.',
    shareMessage: 'Prepare for JKSSB, JKPSC KAS & JKP exams with ExamPro! Free Daily J&K Quiz, District Ranks & Exam-Pattern Mocks:',
    shareAppUrl: 'https://exampro.jk.in',
    social: {
      wa: { on: true, url: 'https://wa.me/919906101048' },
      fb: { on: true, url: 'https://facebook.com/' },
      ig: { on: true, url: 'https://instagram.com/' },
      yt: { on: true, url: 'https://youtube.com/' },
      cp: { on: true },
    },
    upi: {
      upiId: 'exampro@upi',
      payeeName: 'ExamPro J&K',
      qrImageUrl: makeDefaultQrSvgDataUri('exampro@upi', 'ExamPro J&K'),
    },
  };

  return {
    tests,
    bundles,
    exams,
    subjects: [...DEFAULT_SUBJECTS],
    results,
    archivedResults: [],
    lastResultCycleKey: getDueResultCycleKey(new Date()),
    coupons,
    payments,
    dailyQuizzes,
    updates,
    syllabi,
    supportTickets,
    reportedQuestions,
    settings,
    users: [adminUser, ...studentUsers],
    visitorIds: ['seed-1'],
    totalVisitors: 1284,
  };
}

let cachedDb: DatabaseState | null = null;

export function getDb(): DatabaseState {
  if (cachedDb) return cachedDb;
  try {
    if (fs.existsSync(DB_PATH)) {
      const raw = fs.readFileSync(DB_PATH, 'utf8');
      cachedDb = JSON.parse(raw) as DatabaseState;
      if (!Array.isArray(cachedDb.archivedResults)) {
        cachedDb.archivedResults = [];
      }
      if (!cachedDb.lastResultCycleKey) {
        cachedDb.lastResultCycleKey = getDueResultCycleKey(new Date());
      }
      return cachedDb;
    }
  } catch (err) {
    console.error('Failed to load DB, recreating seed:', err);
  }
  cachedDb = buildInitialSeed();
  saveDb();
  return cachedDb;
}

export function saveDb(): void {
  if (!cachedDb) return;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_PATH, JSON.stringify(cachedDb, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to persist DB:', err);
  }
}

export function checkAndRunMonthlyResultRefresh(now: Date = new Date(), force = false): boolean {
  const db = getDb();
  const dueKey = getDueResultCycleKey(now);
  if (!force && db.lastResultCycleKey === dueKey) {
    return false;
  }

  if (db.results.length > 0) {
    const cycleLabel = now.toLocaleDateString('en-IN', {
      month: 'short',
      year: 'numeric',
    });
    db.archivedResults.unshift({
      cycleKey: dueKey,
      cycleLabel,
      archivedAt: now.toLocaleString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      }),
      totalAttempts: db.results.length,
      results: [...db.results],
    });
    if (db.archivedResults.length > 24) {
      db.archivedResults.length = 24;
    }
  }

  db.results = [];
  db.users.forEach((u) => {
    u.attempts = [];
  });
  db.lastResultCycleKey = dueKey;
  db.lastResultResetAt = now.toISOString();
  saveDb();
  return true;
}

export function sanitizeUser(u: UserRecord): UserProfile {
  const { password: _pw, ...safe } = u;
  return safe;
}

export function isAdminCredentials(email: string, phone: string, settings: AppSettings): boolean {
  const eMatch = email.trim().toLowerCase() === settings.adminEmail.trim().toLowerCase();
  const pMatch = Boolean(phone && phone.trim() === settings.adminPhone.trim());
  return eMatch || pMatch;
}

export function getPublicBootstrap(isAdmin: boolean): AppBootstrapData {
  const db = getDb();
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const todayActiveStudents = db.users.filter((u) => u.role === 'student' && u.lastActiveDate === today).length;
  const nextRefresh = getNextMonthEndRefreshDate(now);
  const resultCycle: ResultCycleInfo = {
    cycleKey: db.lastResultCycleKey,
    nextRefreshIso: nextRefresh.toISOString(),
    nextRefreshLabel: nextRefresh.toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    }),
    lastRefreshIso: db.lastResultResetAt,
    archivedCycles: isAdmin ? db.archivedResults : [],
  };

  return {
    tests: db.tests,
    bundles: db.bundles,
    exams: db.exams,
    subjects: db.subjects,
    results: db.results,
    coupons: db.coupons,
    payments: db.payments,
    dailyQuizzes: db.dailyQuizzes,
    updates: db.updates,
    syllabi: db.syllabi,
    supportTickets: db.supportTickets,
    reportedQuestions: db.reportedQuestions,
    settings: db.settings,
    traffic: {
      totalVisitors: db.totalVisitors,
      todayActiveStudents,
    },
    resultCycle,
    ...(isAdmin ? { students: db.users.filter((u) => u.role === 'student').map(sanitizeUser) } : {}),
  };
}
